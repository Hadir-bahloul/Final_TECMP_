#include "../include/BTSRevoDevice.h"
#include "../include/DeviceFactory.h"
#include "../include/Logging.h"
#include "TE-DriverBase/DriverBaseTypes.hpp"
#include "TE-Base/Types.hpp"
#include <TE-BTS-Driver/IOModuleDefinitions.hpp>
#include <TE-DriverBase/DriverBaseDLLExport.hpp>
#include <TE-DriverBase/DriverBaseInitData.hpp>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <random>
#include <chrono>

bool BTSRevoDevice::wasUserActivated[TOTAL_CHANNELS] = {};

// Constructor
BTSRevoDevice::BTSRevoDevice(TE::Base::u16 deviceType,TE::Base::u16 deviceId, const std::string& deviceIp)
    : TE::Driver::Devices(deviceType, deviceId, deviceIp),
      defaultChannelId(1),
      selectedChannelId(-1)
{
    std::fill_n(hasDagger, NUM_DAGGERS, false);
    std::fill_n(hasBlitz, NUM_BLITZES, false);
    

}
void validateChannelId(int channelId) 
{
    if (channelId  < 1 || channelId  > TOTAL_CHANNELS)
    {
        Logging::error("Invalid channel ID: {}" + std::to_string(channelId));
    }
}
void logChannelOperation(int channelId, const std::string &operation)
{
    std::string message = "Channel " + std::to_string(channelId) + " " + operation;
    Logging::info(message);
}

void BTSRevoDevice::activateChannel(int channelId)
{
    validateChannelId(channelId);
    channelMeasurements[channelId - 1].isActive = true;
    logChannelOperation(channelId, "activated");
}

void BTSRevoDevice::deactivateChannel(int channelId)
{
    validateChannelId(channelId);
    channelMeasurements[channelId - 1].isActive = false;
    logChannelOperation(channelId, "deactivated");
}

bool BTSRevoDevice::isChannelActive(int channelId) const
{
    validateChannelId(channelId);
    return channelMeasurements[channelId - 1].isActive;
}

Base::f32 BTSRevoDevice::measureVoltage(int channelId)
{
    validateChannelId(channelId);
    return channelMeasurements[channelId - 1].voltage;

}

float BTSRevoDevice::measureCurrent(int channelId)
{
    validateChannelId(channelId);
    return channelMeasurements[channelId - 1].current;
}

void BTSRevoDevice::OpenLoad(Base::u8 btsBoardNumber, Base::u8 channelNumber,  bool enable)
{
    validateChannelId(channelNumber);
    DeviceFactory::iosInterface->openCircuit(btsBoardNumber, channelNumber, enable);
}
void BTSRevoDevice::shortVBat(Base::u8 btsBoardNumber, Base::u8 channelNumber, bool value)
{
    validateChannelId(channelNumber);
    DeviceFactory::iosInterface->shortVBat(btsBoardNumber, channelNumber, value);
}

void BTSRevoDevice::shortGnd(Base::u8 btsBoardNumber, Base::u8 channelNumber, bool value)
{
    validateChannelId(channelNumber);
    DeviceFactory::iosInterface->shortGnd(btsBoardNumber, channelNumber, value);
}

void BTSRevoDevice::generatePWM(Base::u8 btsBoardNumber, Base::u8 channelNumber, bool enable, Base::u16 onTime, Base::u16 offTime)
{
    validateChannelId(channelNumber);
    DeviceFactory::iosInterface->generatePWM(btsBoardNumber, channelNumber, enable, onTime, offTime);
}

std::string BTSRevoDevice::getDeviceInfo() const
{
    return "BTS_Revo Device ID: " + std::to_string(deviceId) +
           " with " + std::to_string(TOTAL_CHANNELS) + " channels";
}

int BTSRevoDevice::getDeviceId() const
{
    return deviceId;
}

void BTSRevoDevice::UpdateChannelActivation()
{
    Blitz = false;
    Dagger = false;

    for (int i = 0; i < TOTAL_CHANNELS; i++)
    {
        isBlitzActive = false;
        isDaggerActive = false;
        for (int blitzIndex = 0; blitzIndex < NUM_BLITZES; blitzIndex++)
        {
            if (hasBlitz[blitzIndex] && i >= blitzIndex * CHANNELS_PER_BLITZ && i < (blitzIndex + 1) * CHANNELS_PER_BLITZ)
            {
                isBlitzActive = true;
                Blitz = true;
                break;
            }
        }

        for (int daggerIndex = 0; daggerIndex < NUM_DAGGERS; daggerIndex++)
        {
            if (hasDagger[daggerIndex] && i >= daggerIndex * 4 && i < (daggerIndex + 1) * 4)
            {
                isDaggerActive = true;
                Dagger = true;
                break;
            }
        }

        channelMeasurements[i].isActive = isBlitzActive || isDaggerActive || BTSRevoDevice::wasUserActivated[i];
        
    }
}

std::string BTSRevoDevice::getDeviceIP() const
{
    return (deviceIp);
}



