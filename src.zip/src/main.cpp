#include "../include/GUI.h"
#include "../include/Themes.h"
#include "../include/Logging.h"
#include <GLFW/glfw3.h>
#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <pcap.h>
#include <cstring>
#include <algorithm>
#include "backends/imgui_impl_glfw.h"
#include "backends/imgui_impl_opengl3.h"

// Global capture components
std::mutex dump_mutex;
pcap_dumper_t *global_dumper = nullptr;

bool find_tecmp_marker(const u_char* pkt, uint32_t len) {
    // Search for the complete 0x99 0xfe marker
    for (uint32_t i = 0; i < len - 1; i++) {
        if (pkt[i] == 0x99 && pkt[i+1] == 0xfe) {  // Both bytes must match
            return true;
        }
    }
    return false;
}

// Called for each captured packet
void packet_handler(u_char *dumpfile, const struct pcap_pkthdr *header, const u_char *packet) {
    if(find_tecmp_marker(packet, 20)){
        std::lock_guard<std::mutex> lock(dump_mutex);
        pcap_dump((u_char *)global_dumper, header, packet);

    }
}

// Capturing function per interface
void capture_on_interface(pcap_if_t *device) {
    char errbuf[PCAP_ERRBUF_SIZE];
    pcap_t *handle = pcap_open_live(device->name, 65536, 1, 1000, errbuf);
    if (!handle) {
        std::cerr << "[-] Failed to open interface " << device->name << ": " << errbuf << std::endl;
        return;
    }
    std::cout << "[*] Listening on: " << device->name << std::endl;
    pcap_loop(handle, -1, packet_handler, nullptr);
    pcap_close(handle);
}

// Launch all interfaces in background threads
void start_packet_capture() {
    
    char errbuf[PCAP_ERRBUF_SIZE];
    pcap_if_t *alldevs;

    if (pcap_findalldevs(&alldevs, errbuf) == -1) {
        std::cerr << "[-] Error finding devices: " << errbuf << std::endl;
        return;
    }

    // Setup global dumper file
    pcap_t *dead_handle = pcap_open_dead(DLT_EN10MB, 65535);
    global_dumper = pcap_dump_open(dead_handle, "filtered_tecmp_all.pcap");
    if (!global_dumper) {
        std::cerr << "[-] Failed to open output file.\n";
        return;
    }

    // Launch threads
    for (pcap_if_t *dev = alldevs; dev; dev = dev->next) {
        std::string dev_name = dev->name; // copy name so thread is safe
    std::thread([dev_name]() {
    char errbuf[PCAP_ERRBUF_SIZE];
    pcap_t *handle = pcap_open_live(dev_name.c_str(), 65536, 1, 1000, errbuf);
    if (!handle) {
        std::cerr << "[-] Failed to open interface " << dev_name << ": " << errbuf << std::endl;
        return;
    }
    std::cout << "[*] Listening on: " << dev_name << std::endl;
    pcap_loop(handle, -1, packet_handler, nullptr);
    pcap_close(handle);
}).detach();

    }

    std::cout << "[+] Packet capture started in background.\n";
}

int main() {
    // Initialize packet capture in background
    std::thread(start_packet_capture).detach();

    // Initialize GLFW
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW\n";
        return -1;
    }

    GLFWwindow* window = glfwCreateWindow(1280, 720, "TECMP HW CONTROLLER GUI", nullptr, nullptr);
    if (!window) {
        std::cerr << "Failed to create GLFW window\n";
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1); // Enable vsync

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;

    Themes::SetDarkTheme();

    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 130");

    GUI::Initialize();
    Logging::init("MyLogger", "logs.txt");

    // Main loop
    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        GUI::Render();

        ImGui::Render();
        int display_w, display_h;
        glfwGetFramebufferSize(window, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);
        glClearColor(0.45f, 0.55f, 0.60f, 1.00f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
    }

    // Cleanup
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(window);
    glfwTerminate();

    // Optional: clean up pcap dump file
    if (global_dumper) {
    pcap_dump_flush(global_dumper); // <- flush manually
    pcap_dump_close(global_dumper);
}

    return 0;
}
