#include "../include/GUI.h"
#include "../include/legacygui.h"
#include "../include/Logging.h"
#include "../include/DeviceFactory.h"
#include "../include/BTSRevoGUI.h"
#include "../include/Themes.h"
#include "../include/GenericScriptGUI.h"
#include <yaml-cpp/yaml.h>
#include <iostream>
#include <GLFW/glfw3.h>
#include <cstdlib>
#include <algorithm>
#include <fstream>
#include <filesystem>
#include <windows.h>
#include <commdlg.h>
#include "GUI.h"
namespace fs = std::filesystem;

#define _CRT_SECURE_NO_WARNINGS
std::vector<std::shared_ptr<BTSRevoDevice>> GUI::btsDevices;
std::vector<std::shared_ptr<CaptureModuleDevice>> GUI::captureModules;
std::string GUI::saveDirectory;
std::string GUI::yaml_file;
std::string GUI::Conf_file;

void GUI::SetSaveDirectory(const std::string& directory)
{
	saveDirectory = directory;
}

std::string GetExecutablePath()
{
#ifdef _WIN32
	char path[MAX_PATH];
	GetModuleFileNameA(NULL, path, MAX_PATH);
	return std::filesystem::path(path).parent_path().string();
#else
	return "";
#endif
}

void GUI::Initialize()
{
	saveDirectory = GetExecutablePath();
	GLFWwindow* window = glfwGetCurrentContext();
	glfwSetWindowCloseCallback(window, [](GLFWwindow* window)
		{
			glfwSetWindowShouldClose(window, GLFW_TRUE); });
}

void GUI::ImportConf()
{
	OPENFILENAMEA ofn;
	CHAR szFile[260] = { 0 };
	CHAR currentDir[256] = { 0 };

	// Initialize OPENFILENAME
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = GetActiveWindow();
	ofn.lpstrFile = szFile;
	ofn.nMaxFile = sizeof(szFile);
	ofn.lpstrFilter = "YAML Files (*.yaml;*.yml)\0*.YAML;*.YML\0All Files (*.*)\0*.*\0";
	ofn.nFilterIndex = 1;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrInitialDir = currentDir;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

	if (GetOpenFileNameA(&ofn) == TRUE)
	{
		std::ifstream file(ofn.lpstrFile);
		if (file.is_open())
		{
			// Read the entire file into Conf_file
			GUI::Conf_file.assign(
				(std::istreambuf_iterator<char>(file)),
				std::istreambuf_iterator<char>());

			// Validate the content
			if (GUI::Conf_file.empty())
			{
				Logging::error("BTS Conf file is empty: {}", ofn.lpstrFile);
				return;
			}

			try
			{
				YAML::Node root = YAML::Load(GUI::Conf_file);

				// Additional validation for BTS-Revo structure
				if (!root["BTS-Revo"] && !root["bts-revo"])
				{
					Logging::error("Invalid BTS-Revo configuration - missing BTS-Revo section");
					GUI::Conf_file.clear();
					return;
				}

				std::filesystem::path pathObj(ofn.lpstrFile);
				Logging::info("Successfully loaded BTS Revo Conf file: {}", ofn.lpstrFile);
			}
			catch (const YAML::Exception& e)
			{
				GUI::Conf_file.clear();
				Logging::error("YAML parsing error in file '{}': {}", ofn.lpstrFile, e.what());
			}
		}
		else
		{
			GUI::Conf_file.clear();
			Logging::error("Failed to open BTS Revo CONF file: {}", ofn.lpstrFile);
		}
	}
}

void GUI::ShowImportPopup()
{
	OPENFILENAMEA ofn;
	CHAR szFile[260] = { 0 };
	CHAR currentDir[256] = { 0 };

	// Initialize OPENFILENAME
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = GetActiveWindow(); // Parent window
	ofn.lpstrFile = szFile;
	ofn.nMaxFile = sizeof(szFile);
	ofn.lpstrFilter = "YAML Files (*.yaml;*.yml)\0*.YAML;*.YML\0All Files (*.*)\0*.*\0";
	ofn.nFilterIndex = 1;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrInitialDir = currentDir;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

	if (GetOpenFileNameA(&ofn) == TRUE)
	{
		std::ifstream file(ofn.lpstrFile);
		if (file.is_open())
		{
			// Read the entire file into a string
			std::string fileContent(
				(std::istreambuf_iterator<char>(file)),
				std::istreambuf_iterator<char>());

			// If the file is empty, clear and log an error
			if (fileContent.empty())
			{
				GUI::yaml_file.clear();
				Logging::error("YAML file is empty: {}", ofn.lpstrFile);
				return;
			}

			try
			{
				// Parse the YAML
				YAML::Node root = YAML::Load(fileContent);

				// If the YAML is empty or invalid, root.IsNull() will be true
				if (root.IsNull())
				{
					GUI::yaml_file.clear();
					Logging::error("Invalid or empty YAML structure in file: {}", ofn.lpstrFile);
					return;
				}

				// Extract the "BTS-Revo" section from Mappings if it exists
				if ((root["Mappings"] && root["Mappings"]["BTS-Revo"]) || (root["BTS-Revo"]))
				{
					// Get the BTS-Revo node
					YAML::Node btsRevoNode;
					if (root["Mappings"] && root["Mappings"]["BTS-Revo"]) {
						btsRevoNode = root["Mappings"]["BTS-Revo"];
					}
					else {
						btsRevoNode = root["BTS-Revo"];
					}

					// Create a string with the desired format
					std::string extractedYaml = "BTS-Revo:\n  Boards:\n";

					// Convert the Boards content to string
					if (btsRevoNode["Boards"])
					{
						YAML::Emitter emitter;
						emitter << btsRevoNode["Boards"];
						std::string boardsContent = emitter.c_str();

						// Remove the "Boards:" line if it exists in the emitted content
						size_t boardsPos = boardsContent.find("Boards:");
						if (boardsPos != std::string::npos)
						{
							boardsContent = boardsContent.substr(boardsPos + 7); // Skip "Boards:"
						}

						// Add indentation to all lines
						std::stringstream ss(boardsContent);
						std::string line;
						while (std::getline(ss, line))
						{
							extractedYaml += "    " + line + "\n";
						}
					}

					GUI::yaml_file = extractedYaml;
				}
				else
				{
					GUI::yaml_file.clear();
					Logging::error("No 'BTS-Revo' section found in YAML file under Mappings: {}", ofn.lpstrFile);
					return;
				}

				// Update window title
				std::filesystem::path pathObj(ofn.lpstrFile);
				Logging::info("Successfully loaded YAML file: {} ", ofn.lpstrFile);
			}
			catch (const YAML::Exception& e)
			{
				GUI::yaml_file.clear();
				Logging::error("YAML Parsing Error in file '{}': {}", ofn.lpstrFile, e.what());
			}
		}
		else
		{
			GUI::yaml_file.clear(); // Clear if file failed to open
			Logging::error("Failed to open YAML file: {}", ofn.lpstrFile);
		}
	}
}

void GUI::Render()
{
	static bool isDarkTheme = true;
	static bool discoveryPhase = true;
	static int selectedBTSDeviceIndex = -1;
	static int selectedCaptureModuleIndex = -1;
	static bool isBTSRevoPage = false;
	static bool isScriptIDEPage = false;
	static bool showHelpPopup = false;
	static bool isDirectorySelected = false;
	static bool showConfigPage = false;
	static std::string lastDiscoveryTime = "Never";
	static bool leftPanelCollapsed = false;
	static float leftPanelWidth = 300.0f;
	static bool isResizing = false;
	// Theme colors
	ImVec4 errorColor = isDarkTheme ? ImVec4(1.0f, 0.0f, 0.0f, 1.0f) : ImVec4(0.8f, 0.0f, 0.0f, 1.0f);
	ImVec4 successColor = isDarkTheme ? ImVec4(0.0f, 1.0f, 0.0f, 1.0f) : ImVec4(0.0f, 0.7f, 0.0f, 1.0f);

	if (isDarkTheme) {
		Themes::SetDarkTheme();
	}
	else {
		Themes::SetLightTheme();
	}
	// Main menu bar
	if (ImGui::BeginMainMenuBar())
	{
		ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(16.0f, 12.0f));
		ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(20.0f, 20.0f));
		if (ImGui::BeginMenu("File"))
		{
			if (ImGui::MenuItem("Generic Script"))
			{
				isScriptIDEPage = true;
				isBTSRevoPage = false;
				showConfigPage = false;
			}
			if (ImGui::MenuItem("Exit"))
			{
				glfwSetWindowShouldClose(glfwGetCurrentContext(), true);
			}
			ImGui::EndMenu();
		}

		if (ImGui::BeginMenu("Edit"))
		{
			if (ImGui::MenuItem("Clear All Logs"))
			{
				Logging::clean();
			}
			ImGui::EndMenu();
		}

		if (ImGui::BeginMenu("View"))
		{
			if (ImGui::MenuItem(isDarkTheme ? "Switch to Light Theme" : "Switch to Dark Theme"))
			{
				isDarkTheme = !isDarkTheme;
				if (isDarkTheme)
				{
					Themes::SetDarkTheme();
				}
				else
				{
					Themes::SetLightTheme();
				}
			}
			ImGui::EndMenu();
		}

		if (ImGui::BeginMenu("Help"))
		{
			if (ImGui::MenuItem("About"))
			{
				showHelpPopup = true;
			}
			ImGui::EndMenu();
		}

		ImGui::PopStyleVar(2);
		ImGui::EndMainMenuBar();
	}

	// Title bar
	ImGui::SetNextWindowPos(ImVec2(0, ImGui::GetFrameHeight()));
	ImGui::SetNextWindowSize(ImVec2(ImGui::GetIO().DisplaySize.x, 43));
	ImGui::Begin("Band", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar);
	{
		ImGui::SetWindowFontScale(1.9f);
		ImGui::SetCursorPosX((ImGui::GetWindowWidth() - ImGui::CalcTextSize("Tecmp Hardware Controller").x) * 0.5f);
		ImGui::Button("Tecmp Hardware Controller", ImVec2(400, 34));
		ImGui::SameLine(ImGui::GetWindowWidth() - 150);
		ImGui::SetWindowFontScale(1.2f);
		ImGui::SetCursorPosY(ImGui::GetCursorPosY());
		if (ImGui::Button("light", ImVec2(60, 25)))
		{
			isDarkTheme = false;
			Themes::SetLightTheme();
		}

		ImGui::SameLine();
		if (ImGui::Button("dark", ImVec2(60, 25)))
		{
			isDarkTheme = true;
			Themes::SetDarkTheme();
		}
	}
	ImGui::End();

	// Button bar
	ImGui::SetNextWindowPos(ImVec2(0, ImGui::GetFrameHeight() + 40));
	ImGui::SetNextWindowSize(ImVec2(ImGui::GetIO().DisplaySize.x, 46));
	ImGui::Begin("Button Bar", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar);
	{
		ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 0.0f);
		ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8.0f, 4.0f));
		ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0.0f, 0.0f));

		if (ImGui::Button("GENERIC SCRIPT", ImVec2(150, 40)))
		{
			isScriptIDEPage = true;
			isBTSRevoPage = false;
			showConfigPage = false;
			selectedBTSDeviceIndex = -1;
			selectedCaptureModuleIndex = -1;
		}

		ImGui::SameLine();
		if (ImGui::Button("DEVICES", ImVec2(150, 40)))
		{
			isScriptIDEPage = false;
			showConfigPage = false;
		}

		ImGui::SameLine();
		if (ImGui::Button("CONFIGURATION", ImVec2(150, 40)))
		{
			isScriptIDEPage = false;
			isBTSRevoPage = false;
			showConfigPage = true;
			selectedBTSDeviceIndex = -1;
			selectedCaptureModuleIndex = -1;
		}

		ImGui::PopStyleVar(3);
	}
	ImGui::End();

	// Help popup
	if (showHelpPopup)
	{
		ImGui::OpenPopup("Help");
		showHelpPopup = false;
	}
	if (ImGui::BeginPopupModal("Help", nullptr, ImGuiWindowFlags_AlwaysAutoResize))
	{
		ImGui::Text("HW_Control UI - Version 1.0.0");
		ImGui::Separator();
		ImGui::Text("This application is designed to control and monitor BTS_Revo devices and Capture Modules.");
		ImGui::Text("For more information, please refer to the documentation or contact support.");
		ImGui::NewLine();
		if (ImGui::Button("Close"))
		{
			ImGui::CloseCurrentPopup();
		}
		ImGui::EndPopup();
	}
	// Main window
	ImGui::SetNextWindowPos(ImVec2(0, ImGui::GetFrameHeight() + 85));
	ImGui::SetNextWindowSize(ImVec2(ImGui::GetIO().DisplaySize.x, ImGui::GetIO().DisplaySize.y - ImGui::GetFrameHeight() - 80));
	ImGui::Begin("Main Window", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove);

	// Left panel
	ImGui::BeginChild("Left Panel", ImVec2(leftPanelCollapsed ? 30.0f : leftPanelWidth, 0), true,
		ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
	{
		// Collapse/expand button
		ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(2, 2));
		if (ImGui::ArrowButton("##CollapseLeftPanel", leftPanelCollapsed ? ImGuiDir_Right : ImGuiDir_Left))
		{
			leftPanelCollapsed = !leftPanelCollapsed;
		}
		ImGui::PopStyleVar();

		if (leftPanelCollapsed)
		{
			ImGui::EndChild();
			ImGui::SameLine();
			ImGui::BeginChild("Middle Panel", ImVec2(0, ImGui::GetContentRegionAvail().y), true);
			goto render_middle_panel;
		}

		ImGui::SetWindowFontScale(1.0f);
		if (discoveryPhase)
		{
			ImGui::Text("Press 'Discover Devices' to find connected hardware");
			ImGui::NewLine();

			ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));

			if (ImGui::Button("Discover Devices", ImVec2(150, 30)))
			{

				btsDevices = DeviceFactory::DiscoverBTSRevoDevices();
				captureModules = DeviceFactory::DiscoverCaptureModuleDevices();

				for (auto& device : captureModules)
				{
					SetSaveDirectory(saveDirectory);
				}

				discoveryPhase = false;
				time_t now = time(0);
				char buffer[26];
				ctime_s(buffer, sizeof(buffer), &now);
				lastDiscoveryTime = buffer;
				lastDiscoveryTime.pop_back();
			}
			ImGui::PopStyleColor();
		}
		else
		{
			ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
			if (ImGui::Button("Discover Devices", ImVec2(150, 30)))
			{
				btsDevices = DeviceFactory::DiscoverBTSRevoDevices();
				captureModules = DeviceFactory::DiscoverCaptureModuleDevices();

				for (auto& device : captureModules)
				{
					SetSaveDirectory(saveDirectory);
				}

				time_t now = time(0);
				char buffer[26];
				ctime_s(buffer, sizeof(buffer), &now);
				lastDiscoveryTime = buffer;
				lastDiscoveryTime.pop_back();
			}
			ImGui::TextColored(successColor, "Last discovery: %s", lastDiscoveryTime.c_str());
			ImGui::PopStyleColor();
		}

		// BTSRevo Devices Section
		ImGui::NewLine();
		static bool btsSectionOpen = true;
		ImGui::SetWindowFontScale(1.3f);
		bool btsHeaderClicked = ImGui::CollapsingHeader("BTSRevo Devices", ImGuiTreeNodeFlags_DefaultOpen);
		if (btsHeaderClicked)
		{
			ImGui::SetWindowFontScale(1.0f);
			ImGui::Separator();

			// Compact Filter Section
			ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8, 4));
			ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(4, 4));

			ImGui::AlignTextToFramePadding();
			ImGui::Text("Filter:");
			ImGui::SameLine();

			ImGui::PushItemWidth(120);
			ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 3.0f);

			static char btsDeviceIdInput[32] = "";
			bool filterApplied = btsDeviceIdInput[0] != '\0';
			bool enterPressed = ImGui::InputTextWithHint("##BTSDeviceID", "ID...", btsDeviceIdInput, IM_ARRAYSIZE(btsDeviceIdInput),
				ImGuiInputTextFlags_EnterReturnsTrue | ImGuiInputTextFlags_CharsDecimal);

			if (enterPressed)
			{
				int enteredId = atoi(btsDeviceIdInput);
				if (enteredId >= 160 && enteredId <= 168)
				{
					selectedBTSDeviceIndex = enteredId - 160;
					selectedCaptureModuleIndex = -1;
					isBTSRevoPage = true;
					isScriptIDEPage = false;
					showConfigPage = false;
				}
				else
				{
					memset(btsDeviceIdInput, 0, sizeof(btsDeviceIdInput));
					ImGui::TextColored(errorColor, "Invalid ID (1-%d)", btsDevices.size());
				}
			}

			if (filterApplied)
			{
				ImGui::SameLine();
				ImGui::PushID("BTSFilterClear");
				if (ImGui::SmallButton("X"))
				{
					memset(btsDeviceIdInput, 0, sizeof(btsDeviceIdInput));
				}
				ImGui::PopID();
				if (ImGui::IsItemHovered())
					ImGui::SetTooltip("Clear filter");
			}

			ImGui::PopStyleVar(3);
			ImGui::PopItemWidth();

			// Device List - Only show filtered devices
			for (int i = 0; i < btsDevices.size(); i++)
			{
				std::string idStr = std::to_string(btsDevices[i]->getDeviceId());
				// Skip devices that don't match the filter
				if (filterApplied && idStr.find(btsDeviceIdInput) == std::string::npos)
				{
					continue;
				}

				bool isSelected = (selectedBTSDeviceIndex == i);
				if (isSelected)
				{
					ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8.0f, 8.0f));
					ImGui::SetWindowFontScale(1.1f);
				}

				if (ImGui::Selectable(("BTS_Revo " + idStr).c_str(), isSelected))
				{
					selectedBTSDeviceIndex = i;
					selectedCaptureModuleIndex = -1;
					isBTSRevoPage = true;
					isScriptIDEPage = false;
					showConfigPage = false;
				}

				if (ImGui::IsItemHovered())
				{
					ImGui::SetTooltip("IP: %s", btsDevices[i]->getDeviceIP().c_str());
				}

				if (isSelected)
				{
					ImGui::SetWindowFontScale(1.0f);
					ImGui::PopStyleVar();
				}
			}
		}
		// Capture Modules Section
		ImGui::NewLine();
		static bool cmSectionOpen = true;
		ImGui::SetWindowFontScale(1.3f);
		bool cmHeaderClicked = ImGui::CollapsingHeader("Capture Modules", ImGuiTreeNodeFlags_DefaultOpen);
		if (cmHeaderClicked)
		{
			ImGui::SetWindowFontScale(1.0f);
			ImGui::Separator();
			// Compact Filter Section
			ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8, 4));
			ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(4, 4));

			ImGui::AlignTextToFramePadding();
			ImGui::Text("Filter:");
			ImGui::SameLine();

			ImGui::PushItemWidth(120);
			ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 3.0f);

			static char captureModuleIdInput[32] = "";
			if (ImGui::InputTextWithHint("##CaptureModuleID", "ID...", captureModuleIdInput, IM_ARRAYSIZE(captureModuleIdInput),
				ImGuiInputTextFlags_EnterReturnsTrue | ImGuiInputTextFlags_CharsDecimal))
			{
				int linDevices = 0;
				for (auto device : captureModules) {
					std::string type = device->GetType();
					if (type == "LIN") {
				      linDevices++;
					}
				}

				int enteredId = atoi(captureModuleIdInput);
				if (enteredId >= 48 && enteredId <= 64)
				{

					selectedCaptureModuleIndex = enteredId - 48;
				}
				else {
					selectedCaptureModuleIndex = enteredId - 64 + linDevices;

				}

				selectedBTSDeviceIndex = -1;
				isBTSRevoPage = false;
				isScriptIDEPage = false;
				showConfigPage = false;

			}

			if (captureModuleIdInput[0] != '\0')
			{
				ImGui::SameLine();
				ImGui::PushID("CMFilterClear");
				if (ImGui::SmallButton("X"))
				{
					memset(captureModuleIdInput, 0, sizeof(captureModuleIdInput));
				}
				ImGui::PopID();
				if (ImGui::IsItemHovered())
					ImGui::SetTooltip("Clear filter");
			}

			ImGui::PopStyleVar(3);
			ImGui::PopItemWidth();

			// Device List
			for (int i = 0; i < captureModules.size(); i++)
			{
				if (captureModuleIdInput[0] != '\0') // If filter is active
				{
					std::string currentId = std::to_string(captureModules[i]->getDeviceId());
					std::string currentType = captureModules[i]->GetType();

					// Check if filter matches either ID or type (case insensitive)
					std::string filterLower = captureModuleIdInput;
					std::transform(filterLower.begin(), filterLower.end(), filterLower.begin(), ::tolower);

					std::string idLower = currentId;
					std::transform(idLower.begin(), idLower.end(), idLower.begin(), ::tolower);

					std::string typeLower = currentType;
					std::transform(typeLower.begin(), typeLower.end(), typeLower.begin(), ::tolower);

					if (idLower.find(filterLower) == std::string::npos &&
						typeLower.find(filterLower) == std::string::npos)
					{
						continue; // Skip this device if it doesn't match
					}
				}

				bool isSelected = (selectedCaptureModuleIndex == i);
				if (isSelected)
				{
					ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8.0f, 8.0f));
					ImGui::SetWindowFontScale(1.1f);
				}

				std::string typeStr = captureModules[i]->GetType();
				std::string idStr = std::to_string(captureModules[i]->getDeviceId());

				if (ImGui::Selectable(("Capture Module " + idStr + " (" + typeStr + ")").c_str(), isSelected))
				{
					selectedCaptureModuleIndex = i;
					selectedBTSDeviceIndex = -1;
					isBTSRevoPage = false;
					isScriptIDEPage = false;
					showConfigPage = false;
				}
				if (ImGui::IsItemHovered())
				{
					ImGui::SetTooltip("IP: %s", captureModules[i]->getDeviceIP().c_str());
				}

				if (isSelected)
				{
					ImGui::SetWindowFontScale(1.0f);
					ImGui::PopStyleVar();
				}
			}
		}

		ImGui::SetWindowFontScale(1.0f);
	}
	ImGui::EndChild();
	// Draggable separator
	ImGui::SameLine(0, 4.0f);
	ImGui::InvisibleButton("##Splitter", ImVec2(8.0f, ImGui::GetContentRegionAvail().y));
	if (ImGui::IsItemActive())
	{
		if (!isResizing)
		{
			isResizing = true;
		}
		leftPanelWidth += ImGui::GetIO().MouseDelta.x;
		leftPanelWidth = std::clamp(leftPanelWidth, 150.0f, 500.0f);
	}
	else if (isResizing && !ImGui::IsItemActive())
	{
		isResizing = false;
	}
	if (ImGui::IsItemHovered())
	{
		ImGui::SetMouseCursor(ImGuiMouseCursor_ResizeEW);
	}
	ImGui::SameLine();

	// Middle panel
	ImGui::BeginChild("Middle Panel", ImVec2(0, ImGui::GetContentRegionAvail().y), true);

render_middle_panel:
	{
		if (!discoveryPhase)
		{
			if (isBTSRevoPage && selectedBTSDeviceIndex >= 0 && selectedBTSDeviceIndex < btsDevices.size())
			{
				BTSRevoGUI::RenderControlPanel(*btsDevices[selectedBTSDeviceIndex], isDarkTheme, saveDirectory);
			}
			else if (!isBTSRevoPage && selectedCaptureModuleIndex >= 0 && selectedCaptureModuleIndex < captureModules.size())
			{

				LegacyGUI::RenderCaptureModuleControl(captureModules[selectedCaptureModuleIndex], captureModules[selectedCaptureModuleIndex]->deviceId, saveDirectory, isDarkTheme);
			}
			else if (isScriptIDEPage)
			{
				GenericScriptGUI::Render(btsDevices, captureModules, saveDirectory, isDarkTheme);
			}
			else if (showConfigPage)
			{
				if (!isDirectorySelected)
				{
					ImGui::Text("Please enter the directory path to save captured data:");

					static char directoryPath[256] = "";
					ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.95f, 0.95f, 0.3f, 1.0f));
					if (ImGui::InputText("##DirectoryPath", directoryPath, IM_ARRAYSIZE(directoryPath), ImGuiInputTextFlags_EnterReturnsTrue))
					{
						if (strlen(directoryPath) > 0)
						{
							saveDirectory = directoryPath;
							isDirectorySelected = true;
							for (auto& device : captureModules)
							{
								SetSaveDirectory(saveDirectory);
							}
						}
						else
						{
							ImGui::TextColored(errorColor, "Please enter a valid directory path.");
						}
					}
					ImGui::PopStyleColor();

					if (ImGui::Button("Confirm", ImVec2(120, 0)))
					{
						if (strlen(directoryPath) > 0)
						{
							saveDirectory = directoryPath;
							isDirectorySelected = true;
							for (auto& device : captureModules)
							{
								SetSaveDirectory(saveDirectory);
							}
						}
						else
						{
							ImGui::TextColored(errorColor, "Please enter a valid directory path.");
						}
					}

				}
				else
				{
					ImGui::Text("Current Save Directory: %s", saveDirectory.c_str());
					Logging::info("save dir {}", saveDirectory.c_str());
					static char newDirectoryPath[256] = "";

					ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.95f, 0.95f, 0.3f, 1.0f));
					if (ImGui::InputText("##NewDirectoryPath", newDirectoryPath, IM_ARRAYSIZE(newDirectoryPath), ImGuiInputTextFlags_EnterReturnsTrue))
					{
						if (strlen(newDirectoryPath) > 0)
						{
							saveDirectory = newDirectoryPath;
							isDirectorySelected = true;
							for (auto& device : captureModules)
							{
								SetSaveDirectory(saveDirectory);
							}
							memset(newDirectoryPath, 0, sizeof(newDirectoryPath));
						}
						else
						{
							ImGui::TextColored(errorColor, "Please enter a valid directory path.");
						}
					}
					ImGui::PopStyleColor();

					if (ImGui::Button("Change Directory", ImVec2(180, 30)) || ImGui::IsKeyPressed(ImGuiKey_Enter))
					{
						std::cout << "[DEBUG] Button clicked!" << std::endl;
						std::cout << "[DEBUG] Number of BTS devices: " << btsDevices.size() << std::endl;
						for (auto& btsDevice : btsDevices)
						{
						}
						for (auto& device : captureModules)
						{
						}

						if (strlen(newDirectoryPath) > 0)
						{
							saveDirectory = newDirectoryPath;
							isDirectorySelected = true;
							memset(newDirectoryPath, 0, sizeof(newDirectoryPath));
						}
						else
						{
							ImGui::TextColored(errorColor, "Please enter a valid directory path.");
						}
					}
				}
				if (ImGui::Button("import BTS_Revo yaml file"))
				{
					GUI::ShowImportPopup();
				}
			}
			else
			{
				ImGui::Text("Please select a device from the left panel or use the navigation buttons.");
			}
		}
	}
	ImGui::EndChild();

	ImGui::End();
}