#include "../include/CANCaptureModuleDevice.h"
#include "../include/CaptureModuleDevice.h"
#include <TE-DriverBase/DriverBaseInitData.hpp>
#include "../include/Logging.h"

CANCaptureModuleDevice::CANCaptureModuleDevice(TE::Base::u16 index)
    : CaptureModuleDevice(static_cast<TE::Base::u16>(2), index,"10.104.3." + std::to_string(index))
{
}

std::string CANCaptureModuleDevice::GetType() const {  
    return "CAN";
}
