#include "../include/CaptureModuleDevice.h"
#include "../include/Logging.h"
#include "../include/DeviceFactory.h"
#include <TE-DriverBase/DriverBaseInitData.hpp>
#include "imgui.h"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iomanip>
#include <sstream>
#include <iostream>
#include <fstream>

#define _CRT_SECURE_NO_WARNINGS
// Maximum number of unique messages to store
const size_t MAX_UNIQUE_MESSAGES = 1000;

CaptureModuleDevice::CaptureModuleDevice(TE::Base::u16 deviceType, TE::Base::u16 deviceId, const std::string& deviceIp)
   :  TE::Driver::Devices(deviceType, deviceId, deviceIp),
      isConnected(false)
{
    Logging::info("Device {} ({}) initialized successfully", 
                 deviceId, deviceType);
}

CaptureModuleDevice::~CaptureModuleDevice()
{
    if (isCapturing)
    {
        isCapturing = false;
        if (captureThread.joinable())
        {
            captureThread.join();
        }
    }
}
void CaptureModuleDevice::sendCanMessage(TE::Base::u16 deviceId, int channelNum, uint32_t messageId, bool isExtendedId, TE::Base::u8 dataLength, const std::vector<TE::Base::u8>& dataVector)
{
    DeviceFactory::_tecmp_driver_->sendCanMessage(
        deviceId,
        channelNum,
        messageId,
        isExtendedId ? TE::Driver::CanIDType::EXTENDED_ID
        : TE::Driver::CanIDType::STANDARD_ID,
        TE::Driver::CanFrameType::DATA_FRAME,
        static_cast<TE::Base::u8>(dataLength),
        dataVector,
        0
    );
}
void CaptureModuleDevice::sendLinMessage(TE::Base::u16 deviceId, int channelNum, uint32_t messageId , const std::vector<TE::Base::u8>& dataVector)
{
     DeviceFactory::_tecmp_driver_->sendLinMessage(
     deviceId,
     channelNum,
     messageId,
     dataVector
 );

}