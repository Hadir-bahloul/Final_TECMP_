#include "../include/GenericScriptGUI.h"
#include "../include/Logging.h"
#include "../include/Themes.h"
#include "../include/DeviceFactory.h"
#include "../include/GenericScriptBackend.h"
#include <vector>
#include <string>
#include <memory>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>
#include <iostream>
#include <fstream>
#include <filesystem>
#include <algorithm>
#include <imgui.h>
#include <unordered_map>
#include <filesystem>
#include <Windows.h>
#include <commdlg.h>
#include <future>

namespace fs = std::filesystem;

std::string GenericScriptGUI::tempScriptDirectory;
std::unordered_map<std::string, std::string> GenericScriptGUI::scriptToTempFileMap;

// Struct to hold each script window's state
struct ScriptWindow
{
	std::string name;
	char buffer[1024] = { 0 };
	bool isOpen = true;
	std::string tempFilePath; // Path to temporary file

	ScriptWindow(const std::string& defaultName)
	{
		static int counter = 1;
		name = defaultName + " " + std::to_string(counter++);
	}
};

const char* btsRevoBaseFunctions[] = {
	"OpenLoad(int btsRevoId, int channelId, bool enable)",
	"ShortVbat(int btsRevoId, int channelId, bool enable)",
	"ShortGND(int btsRevoId, int channelId, bool enable)",
	"PWMGeneration(int btsRevoId, int channelId, float frequency, float dutyCycle)",
	"LowCurrentGeneration(int btsRevoId, int channelId, float currentInMa)",
	"VoltageMeasurement(int btsRevoId, int channelId)",
	"CurrentMeasurementLowCurrent(int btsRevoId, int channelId)",
	"PWMMeasurement(int btsRevoId, int channelId)",
	"GetLastReceivedIOMsg(int btsRevoId, int channelId)" };

const char* btsRevoBlitzFunctions[] = {
	"CurrentMeasurementHighCurrent(int btsRevoId, int channelId, float maxCurrent)",
	"QuiescentCurrentMeasurement(int btsRevoId, int channelId, float maxCurrent)",
	"ShortToGNDHighCurrent(int btsRevoId, int channelId, float maxCurrent)" };

const char* btsRevoDaggerFunctions[] = {
	"LoadSimulationHighCurrent(int btsRevoId, int channelId, float loadResistance)" };
const char* captureModuleFunctions[] = {
	"SendCANFrame(int candeviceID, int canChannel, bool isExtendedId, int canMsgId, int canDataLength, std::vector<Base::u8> canPayload)",
	"SendLINFrame(int lindeviceID, int linPort, int frameId, const std::vector<Base::u8> payload))",
	"GetLastReceivedCANMsg(int canmoduleId)",
	"GetLastReceivedLINMsg(int linmoduleId)" };

bool IsBaseFunction(const std::string& functionName)
{
	for (const auto& func : btsRevoBaseFunctions)
	{
		if (functionName.find(func) == 0)
		{ // Check if functionName starts with func
			return true;
		}
	}
	return false;
}

bool IsBlitzFunction(const std::string& functionName)
{
	for (const auto& func : btsRevoBlitzFunctions)
	{
		if (functionName.find(func) == 0)
		{
			return true;
		}
	}
	return false;
}

bool IsDaggerFunction(const std::string& functionName)
{
	for (const auto& func : btsRevoDaggerFunctions)
	{
		if (functionName.find(func) == 0)
		{
			return true;
		}
	}
	return false;
}

GenericScriptGUI::GenericScriptGUI()
{
	try {
		fs::path tempPath = fs::temp_directory_path() / "Scripts";
		tempScriptDirectory = tempPath.string();
		if (tempScriptDirectory.back() != fs::path::preferred_separator) {
			tempScriptDirectory += fs::path::preferred_separator;
		}

		Logging::info("temp directory set to {}", tempScriptDirectory);

		// Create directory if it doesn't exist
		if (!fs::exists(tempPath)) {
			if (fs::create_directories(tempPath)) {
				Logging::info("Created temporary script directory: {}", tempScriptDirectory);
			}
			else {
				Logging::error("Failed to create temporary script directory: {}", tempScriptDirectory);
			}
		}
	}
	catch (const std::exception& e) {
		Logging::error("Exception while creating temp script directory: {}", e.what());
	}
}
GenericScriptGUI::~GenericScriptGUI()
{
}

void GenericScriptGUI::SaveToTempFile(const std::string& script, const std::string& windowName)
{
	// Create a sanitized filename from the window name
	std::string sanitizedName = windowName;
	std::replace(sanitizedName.begin(), sanitizedName.end(), ' ', '_');
	std::replace(sanitizedName.begin(), sanitizedName.end(), '/', '_');
	std::replace(sanitizedName.begin(), sanitizedName.end(), '\\', '_');

	// Use filesystem::path for proper path construction
	fs::path tempPath = fs::temp_directory_path() / "Scripts";
	tempPath /= "temp_" + sanitizedName + ".txt";

	Logging::debug("Saving temp script to: {}", tempPath.string());

	// Create directory if it doesn't exist
	try {
		if (!fs::exists(tempPath.parent_path())) {
			fs::create_directories(tempPath.parent_path());
		}

		// Save the script to temp file
		std::ofstream outFile(tempPath);
		if (outFile.is_open()) {
			outFile << script;
			outFile.close();

			// Update the map
			scriptToTempFileMap[windowName] = tempPath.string();
			Logging::debug("Saved temp script for: {}", windowName);
		}
		else {
			Logging::error("Failed to open file for writing: {}", tempPath.string());
		}
	}
	catch (const std::exception& e) {
		Logging::error("Exception while saving temp script: {}", e.what());
	}
}

void GenericScriptGUI::RunScript(const std::string& script, const std::string& saveDirectory)
{
	static std::future<void> asyncTask;
	if (asyncTask.valid() && asyncTask.wait_for(std::chrono::seconds(0)) == std::future_status::ready) {
		asyncTask.get(); // Clean up previous task if done
	}
	asyncTask = std::async(std::launch::async, [=]() {
		try {
			bool allSuccess = true;
			bool anyExecution = false;

			std::istringstream scriptStream(script);
			std::string line;

			while (std::getline(scriptStream, line))
			{
				// Trim whitespace
				line.erase(0, line.find_first_not_of(" \t"));
				line.erase(line.find_last_not_of(" \t") + 1);

				// Skip empty or comment lines
				if (line.empty() || line.find("//") == 0) {
					Logging::debug("Skipping empty/comment line: {}", line);
					continue;
				}

				// Remove trailing semicolon
				if (line.back() == ';') line.pop_back();

				// Detect `for` loop with opening brace
				if (line.rfind("for", 0) == 0 && line.find('{') != std::string::npos)
				{
					Logging::info("Found for loop: {}", line);

					size_t parenStart = line.find('(');
					size_t parenEnd = line.find(')');
					if (parenStart == std::string::npos || parenEnd == std::string::npos) {
						Logging::error("Malformed for loop - missing parentheses");
						continue;
					}

					std::string loopParts = line.substr(parenStart + 1, parenEnd - parenStart - 1);
					Logging::debug("Raw loop parts: {}", loopParts);

					// Split into init/condition/increment
					std::vector<std::string> parts;
					size_t last = 0;
					size_t next = 0;
					while ((next = loopParts.find(';', last)) != std::string::npos) {
						std::string part = loopParts.substr(last, next - last);
						part.erase(0, part.find_first_not_of(" \t"));
						part.erase(part.find_last_not_of(" \t") + 1);
						if (!part.empty()) parts.push_back(part);
						last = next + 1;
					}
					// Add last part
					std::string lastPart = loopParts.substr(last);
					lastPart.erase(0, lastPart.find_first_not_of(" \t"));
					lastPart.erase(lastPart.find_last_not_of(" \t") + 1);
					if (!lastPart.empty()) parts.push_back(lastPart);

					if (parts.size() < 3) {
						Logging::error("Invalid for loop structure - expected 3 parts");
						continue;
					}

					std::string init = parts[0];
					std::string condition = parts[1];
					std::string increment = parts[2];

					Logging::info("Parsed parts - init:'{}' cond:'{}' incr:'{}'",
						init, condition, increment);

					std::unordered_map<std::string, int> variables;
					std::string varName;
					int start = 0;

					// Parse initialization
					try {
						size_t eqPos = init.find('=');
						if (eqPos != std::string::npos) {
							std::string left = init.substr(0, eqPos);
							left.erase(0, left.find_first_not_of(" \t"));
							left.erase(left.find_last_not_of(" \t") + 1);

							// Extract variable name (handle both "int i" and "i" cases)
							size_t lastSpace = left.find_last_of(" \t");
							varName = (lastSpace != std::string::npos) ?
								left.substr(lastSpace + 1) : left;

							varName.erase(0, varName.find_first_not_of(" \t"));
							varName.erase(varName.find_last_not_of(" \t") + 1);

							std::string right = init.substr(eqPos + 1);
							right.erase(0, right.find_first_not_of(" \t"));
							right.erase(right.find_last_not_of(" \t") + 1);

							start = std::stoi(right);
							variables[varName] = start;
						}
					}
					catch (...) {
						Logging::error("Failed to parse loop initialization");
						continue;
					}

					if (varName.empty()) {
						Logging::error("No loop variable found");
						continue;
					}

					// Extract loop body
					std::vector<std::string> loopBody;
					while (std::getline(scriptStream, line))
					{
						line.erase(0, line.find_first_not_of(" \t"));
						line.erase(line.find_last_not_of(" \t") + 1);

						if (line == "}") break;
						if (line.empty() || line.find("//") == 0) continue;

						if (line.back() == ';') line.pop_back();
						loopBody.push_back(line);
						Logging::info("loop line added: {}", line);
					}

					// Parse condition
					char compOp = 0;
					int endVal = 0;
					bool inclusive = false;

					try {
						// Remove all whitespace from condition for easier parsing
						condition.erase(std::remove_if(condition.begin(), condition.end(), ::isspace),
							condition.end());

						size_t condPos = condition.find_first_of("<>=");
						if (condPos != std::string::npos) {
							compOp = condition[condPos];
							inclusive = (condPos + 1 < condition.size() && condition[condPos + 1] == '=');

							std::string valStr = condition.substr(condPos + (inclusive ? 2 : 1));
							endVal = std::stoi(valStr);

							Logging::debug("Condition parsed: var={} op={} incl={} end={}",
								varName, compOp, inclusive, endVal);
						}
					}
					catch (...) {
						Logging::error("Failed to parse loop condition");
						continue;
					}

					// Parse increment
					int step = 1;
					try {
						increment.erase(std::remove_if(increment.begin(), increment.end(), ::isspace),
							increment.end());

						if (increment.find("++") != std::string::npos) {
							step = 1;
						}
						else if (increment.find("+=") != std::string::npos) {
							step = std::stoi(increment.substr(increment.find("+=") + 2));
						}
						else if (increment.find('+') != std::string::npos) {
							size_t plusPos = increment.find('+');
							step = std::stoi(increment.substr(plusPos + 1));
						}
					}
					catch (...) {
						Logging::error("Failed to parse loop increment");
						continue;
					}

					// Execute loop
					Logging::info("Starting loop execution: {} from {} to {} (step {})",
						varName, start, endVal, step);

					for (int i = start; ; i += step)
					{
						// Check termination condition
						bool shouldContinue;
						switch (compOp) {
						case '<':
							shouldContinue = inclusive ? (i <= endVal) : (i < endVal);
							break;
						case '>':
							shouldContinue = inclusive ? (i >= endVal) : (i > endVal);
							break;
						default:
							shouldContinue = false;
						}

						if (!shouldContinue) break;

						variables[varName] = i;
						Logging::debug("Loop iteration: {} = {}", varName, i);

						for (const auto& bodyLine : loopBody)
						{
							try {
								size_t parenPos = bodyLine.find('(');
								if (parenPos != std::string::npos)
								{
									std::string funcName = bodyLine.substr(0, parenPos);
									funcName.erase(0, funcName.find_first_not_of(" \t"));
									funcName.erase(funcName.find_last_not_of(" \t") + 1);

									std::string params = bodyLine.substr(parenPos + 1);
									params = params.substr(0, params.find(')'));

									// Replace variables in params
									for (const auto& var : variables) {
										size_t varPos = params.find(var.first);
										while (varPos != std::string::npos) {
											params.replace(varPos, var.first.length(), std::to_string(var.second));
											varPos = params.find(var.first, varPos + 1);
										}
									}

									Logging::info("Executing: {}({})", funcName, params);
									GenericScriptBackend::executeFunction(funcName, params);
									anyExecution = true;
								}
							}
							catch (const std::exception& e) {
								Logging::error("Execution failed: {}", e.what());
								allSuccess = false;
							}
						}

						std::this_thread::sleep_for(std::chrono::milliseconds(100));
					}

					continue; // Skip normal processing for loops
				}

				// Function call outside loop
				size_t parenPos = line.find('(');
				if (parenPos != std::string::npos)
				{
					size_t funcStart = line.find_last_of(" \t", parenPos);
					funcStart = (funcStart == std::string::npos) ? 0 : funcStart + 1;
					std::string funcName = line.substr(funcStart, parenPos - funcStart);
					Logging::info("func name {}", funcName);
					size_t paramEnd = line.find(')', parenPos);
					if (paramEnd != std::string::npos)
					{
						std::string params = line.substr(parenPos + 1, paramEnd - parenPos - 1);

						try {
							GenericScriptBackend::executeFunction(funcName, params);
							Logging::info("Executed: {}({})", funcName, params);
							anyExecution = true;
						}
						catch (const std::exception& e) {
							Logging::error("Failed: {}({}) - {}", funcName, params, e.what());
							allSuccess = false;
						}
					}
				}
			}

			// Post-execution feedback
			if (!anyExecution)
			{
				Logging::warn("No executable commands found");
			}
			else if (allSuccess)
			{
				Logging::info("All functions executed successfully");
			}
			else
			{
				Logging::warn("Some functions failed");
			}
		}
		catch (const std::exception& e) {
			Logging::error("Exception during script execution: {}", e.what());
		}
		catch (...) {
			Logging::error("Unknown exception occurred during script execution.");
		}});
}

void GenericScriptGUI::LoadTempScripts(std::vector<ScriptWindow>& scriptWindows)
{
	try
	{
		// Ensure temp directory is initialized
		if (tempScriptDirectory.empty())
		{
			tempScriptDirectory = (std::filesystem::temp_directory_path() / "Scripts").string() + "/";
			Logging::warn("tecmp script directory just saved  {}", tempScriptDirectory);
		}

		// Create directory if it doesn't exist
		if (!std::filesystem::exists(tempScriptDirectory))
		{
			if (!std::filesystem::create_directories(tempScriptDirectory))
			{
				Logging::error("Failed to create temporary script directory: {}", tempScriptDirectory);
				return;
			}
		}

		// Iterate through all files in the temp directory
		for (const auto& entry : std::filesystem::directory_iterator(tempScriptDirectory))
		{
			Logging::info("fetching scripts..");
			if (entry.is_regular_file() && entry.path().extension() == ".txt")
			{
				std::string filename = entry.path().filename().string();

				// Check if it's one of our temp files
				if (filename.rfind("temp_", 0) == 0)
				{ // Starts with "temp_"
					// Extract the original window name (remove "temp_" prefix and ".txt" suffix)
					std::string windowName = filename.substr(5, filename.size() - 9);

					// Replace underscores with spaces to reverse the sanitization
					std::replace(windowName.begin(), windowName.end(), '_', ' ');

					// Check if we already have a window with this name
					bool windowExists = false;
					for (const auto& window : scriptWindows)
					{
						if (window.name == windowName)
						{
							windowExists = true;
							break;
						}
					}

					if (!windowExists)
					{
						// Create new script window
						ScriptWindow newWindow(windowName);
						newWindow.tempFilePath = entry.path().string();
						Logging::info("script window created");
						// Load the script content
						std::ifstream inFile(entry.path());
						if (inFile.is_open())
						{
							std::string content((std::istreambuf_iterator<char>(inFile)),
								std::istreambuf_iterator<char>());

							// Ensure we don't overflow the buffer
							size_t copySize = std::min(content.size(), sizeof(newWindow.buffer) - 1);
							strncpy_s(newWindow.buffer, content.c_str(), copySize);
							newWindow.buffer[copySize] = '\0';

							inFile.close();

							// Add to our script windows
							scriptWindows.push_back(newWindow);

							// Update the map
							scriptToTempFileMap[windowName] = entry.path().string();

							Logging::info("Loaded temporary script: {}", windowName);
						}
					}
				}
			}
		}

		// If no windows were loaded, add a default one
		if (scriptWindows.empty())
		{
			scriptWindows.emplace_back("Script");
			Logging::info("No valid temporary scripts found, created default script window");
		}
	}
	catch (const std::filesystem::filesystem_error& e)
	{
		Logging::error("Filesystem error loading temporary scripts: {}", e.what());
		if (scriptWindows.empty())
		{
			scriptWindows.emplace_back("Script");
		}
	}
	catch (const std::exception& e)
	{
		Logging::error("Error loading temporary scripts: {}", e.what());
		if (scriptWindows.empty())
		{
			scriptWindows.emplace_back("Script");
		}
	}
}

void GenericScriptGUI::ShowImportPopup(bool& showPopup, ScriptWindow& currentWindow)
{
	if (showPopup)
	{
		showPopup = false; // Reset the flag immediately

		OPENFILENAMEA ofn;
		CHAR szFile[260] = { 0 };
		CHAR currentDir[256] = { 0 };

		// Initialize OPENFILENAME
		ZeroMemory(&ofn, sizeof(ofn));
		ofn.lStructSize = sizeof(ofn);
		ofn.hwndOwner = GetActiveWindow(); // Parent window
		ofn.lpstrFile = szFile;
		ofn.nMaxFile = sizeof(szFile);
		ofn.lpstrFilter = "Text Files (*.txt)\0*.TXT\0All Files (*.*)\0*.*\0";
		ofn.nFilterIndex = 1;
		ofn.lpstrFileTitle = NULL;
		ofn.nMaxFileTitle = 0;
		ofn.lpstrInitialDir = currentDir;
		ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

		if (GetOpenFileNameA(&ofn) == TRUE)
		{
			std::ifstream file(ofn.lpstrFile);
			if (file.is_open())
			{
				// Clear existing buffer
				memset(currentWindow.buffer, 0, sizeof(currentWindow.buffer));

				// Read file contents
				std::string content(
					(std::istreambuf_iterator<char>(file)),
					std::istreambuf_iterator<char>());

				// Copy to buffer with bounds checking
				size_t copySize = std::min(content.size(), sizeof(currentWindow.buffer) - 1);
				strncpy_s(currentWindow.buffer, content.c_str(), copySize);
				currentWindow.buffer[copySize] = '\0';

				// Update window title
				std::filesystem::path pathObj(ofn.lpstrFile);
				currentWindow.name = pathObj.stem().string();

				Logging::info("Successfully loaded: {}", ofn.lpstrFile);
			}
			else
			{
				Logging::error("Failed to open file: {}", ofn.lpstrFile);
			}
		}
	}
}
void GenericScriptGUI::Render(std::vector<std::shared_ptr<BTSRevoDevice>>& btsDevices,
	std::vector<std::shared_ptr<CaptureModuleDevice>>& captureModules,
	const std::string& saveDirectory,
	bool& isDarkTheme)
{
	static std::vector<ScriptWindow> scriptWindows;
	static int currentWindowIndex = 0;
	static bool showSavePopup = false;
	static char saveNameBuffer[256] = { 0 };
	static bool showImportPopup = false;
	static char editBuffer[4096] = { 0 };
	static std::string droppedFunction;
	static bool showParameterPopup = false;
	static std::vector<std::pair<std::string, std::string>> parameterInputs;
	static bool inputError = false;
	static std::string errorMessage;
	static std::vector<std::string> parameterTypes;
	static size_t editFunctionPos = std::string::npos;
	static char editFunctionBuffer[1024] = { 0 };
	static char loopVarName[32] = "i";
	static char loopStart[32] = "0";
	static char loopEnd[32] = "10";
	static char loopStep[32] = "1";
	static bool showForLoopPopup = false;

	if (scriptWindows.empty())
	{
		scriptWindows.emplace_back("Script");
	}

	// Theme colors
	ImVec4 cyanColor = isDarkTheme ? ImVec4(0.0f, 0.8f, 1.0f, 1.0f) : ImVec4(0.0f, 0.0f, 0.55f, 1.0f);
	ImVec4 errorColor = isDarkTheme ? ImVec4(1.0f, 0.0f, 0.0f, 1.0f) : ImVec4(0.8f, 0.0f, 0.0f, 1.0f);
	ImVec4 successColor = isDarkTheme ? ImVec4(0.0f, 1.0f, 0.0f, 1.0f) : ImVec4(0.0f, 0.5f, 0.0f, 1.0f);
	ImVec4 functionButtonColor = isDarkTheme ? ImVec4(0.3f, 0.3f, 0.6f, 1.0f) : ImVec4(0.1f, 0.1f, 0.9f, 1.0f);
	ImVec4 removeButtonColor = isDarkTheme ? ImVec4(0.6f, 0.2f, 0.2f, 1.0f) : ImVec4(0.9f, 0.4f, 0.4f, 1.0f);
	ImVec4 addButtonColor = isDarkTheme ? ImVec4(0.2f, 0.6f, 0.2f, 1.0f) : ImVec4(0.4f, 0.8f, 0.4f, 1.0f);
	ImVec4 loopBgColor = isDarkTheme ? ImVec4(0.08f, 0.08f, 0.12f, 1.0f) : ImVec4(0.92f, 0.92f, 0.96f, 1.0f);
	ImVec4 loopBorderColor = isDarkTheme ? ImVec4(0.3f, 0.3f, 0.7f, 1.0f) : ImVec4(0.4f, 0.4f, 0.8f, 1.0f);
	ImVec4 loopHeaderColor = isDarkTheme ? ImVec4(0.15f, 0.15f, 0.25f, 1.0f) : ImVec4(0.85f, 0.85f, 0.95f, 1.0f);
	ImVec4 removeButtonHoveredColor = isDarkTheme ? ImVec4(1.0f, 0.3f, 0.3f, 1.0f) : ImVec4(1.0f, 0.4f, 0.4f, 1.0f);

	// Window management
	ImGui::BeginGroup();
	{
		ImGui::SetWindowFontScale(1.7f);
		ImGui::TextColored(cyanColor, "Script Windows:");
		ImGui::SetWindowFontScale(1.0f);
	}
	ImGui::EndGroup();

	// Track if we need to show the warning
	static bool showLastWindowWarning = false;

	if (!scriptWindows.empty())
	{
		ImGui::BeginChild("Tabs", ImVec2(0, 30), true);
		for (size_t i = 0; i < scriptWindows.size(); i++)
		{
			bool isSelected = (currentWindowIndex == i);

			// Tab button
			ImGui::PushID(static_cast<int>(i + scriptWindows.size()));
			{
				if (ImGui::Button(scriptWindows[i].name.c_str()))
				{
					currentWindowIndex = static_cast<int>(i);
				}
			}
			ImGui::PopID();

			// Close button for each tab
			ImGui::SameLine(0, 2);
			ImGui::PushID(static_cast<int>(i));
			{
				ImGui::PushStyleColor(ImGuiCol_Button, removeButtonColor);
				ImGui::PushStyleColor(ImGuiCol_ButtonHovered, removeButtonHoveredColor);
				ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));

				if (ImGui::Button("×", ImVec2(20, 0)))
				{
					if (scriptWindows.size() > 1)
					{
						scriptWindows.erase(scriptWindows.begin() + i);
						if (currentWindowIndex >= scriptWindows.size())
						{
							currentWindowIndex = static_cast<int>(scriptWindows.size() - 1);
						}
						ImGui::PopStyleColor(3);
						ImGui::PopID();
						break; // Exit loop since we modified the vector
					}
					else
					{
						Logging::debug("You cannot close the last script window!");
						showLastWindowWarning = true;
					}
				}
				ImGui::PopStyleColor(3);
			}
			ImGui::PopID();

			// Add button after the last tab
			if (i == scriptWindows.size() - 1)
			{
				ImGui::SameLine(0, 4);
				ImGui::PushID("add_button");
				ImGui::PushStyleColor(ImGuiCol_Button, addButtonColor);
				if (ImGui::Button("+", ImVec2(20, 0)))
				{
					scriptWindows.emplace_back("Script");
					currentWindowIndex = static_cast<int>(scriptWindows.size() - 1);
				}
				ImGui::PopStyleColor();
				ImGui::PopID();
			}

			if (i < scriptWindows.size() - 1)
			{
				ImGui::SameLine();
			}
		}
		ImGui::EndChild();
	}

	// Show warning popup 
	if (showLastWindowWarning)
	{
		ImGui::OpenPopup("Last Window Warning");
		if (ImGui::BeginPopupModal("Last Window Warning", nullptr, ImGuiWindowFlags_AlwaysAutoResize))
		{
			ImGui::Text("You cannot close the last script window!");
			if (ImGui::Button("OK", ImVec2(120, 0)))
			{
				showLastWindowWarning = false;
				ImGui::CloseCurrentPopup();
			}
			ImGui::EndPopup();
		}
	}
	ScriptWindow& currentWindow = scriptWindows[currentWindowIndex];
	static std::string lastScriptContent;
	std::string currentContent = currentWindow.buffer;
	if (currentContent != lastScriptContent)
	{
		SaveToTempFile(currentContent, currentWindow.name);
		lastScriptContent = currentContent;
	}
	if (showImportPopup)
	{
		ShowImportPopup(showImportPopup, currentWindow);
	}

	ImGui::Columns(2, "IDE Columns", true);

	// Left Column: Script Editor
	ImGui::BeginChild("Left Column", ImVec2(0, 0), true);
	{
		ImGui::SetWindowFontScale(1.5f);
		ImGui::Text("Editing: %s", currentWindow.name.c_str());
		ImGui::SetWindowFontScale(1.0f);
		ImGui::BeginChild("ScriptEditorEditMode", ImVec2(-1, 400), true);
		{
			std::string scriptContent = currentWindow.buffer;
			size_t pos = 0;
			int loopDepth = 0;

			// Forward declare renderLoopBlock since it's recursive
			std::function<void(const std::string&, const std::string&, int, size_t)> renderLoopBlock;

			// Function to handle dropping a function into a specific position
			static struct
			{
				bool show = false;
				std::string function;
				size_t insertPos;
				std::vector<std::pair<std::string, std::string>> parameters;
				std::vector<std::string> paramTypes;
				std::vector<bool> boolValues;
			} paramPopupState;

			// Replace your handleFunctionDrop with this version
			auto handleFunctionDrop = [&](const std::string& function, size_t insertPos) -> bool
				{
					// Only show popup for functions with parameters
					if (function.find('(') == std::string::npos)
					{
						// Simple function without parameters - insert directly
						std::string toInsert = function;
						if (toInsert.back() != ';')
							toInsert += ";";
						toInsert += "\n";

						std::string scriptContent = currentWindow.buffer;
						size_t remainingSpace = sizeof(currentWindow.buffer) - scriptContent.length() - 1;

						if (toInsert.length() < remainingSpace)
						{
							scriptContent.insert(insertPos, toInsert);
							strncpy_s(currentWindow.buffer, scriptContent.c_str(), sizeof(currentWindow.buffer));
							return true;
						}
						return false;
					}

					// Initialize popup state
					paramPopupState.show = true;
					paramPopupState.function = function;
					paramPopupState.insertPos = insertPos;
					paramPopupState.parameters.clear();
					paramPopupState.paramTypes.clear();
					paramPopupState.boolValues.clear();

					// Parse parameters
					size_t paramStart = function.find('(');
					size_t paramEnd = function.find(')');
					if (paramStart != std::string::npos && paramEnd != std::string::npos)
					{
						std::string params = function.substr(paramStart + 1, paramEnd - paramStart - 1);
						size_t pos = 0;
						while ((pos = params.find(',')) != std::string::npos)
						{
							std::string param = params.substr(0, pos);
							size_t spacePos = param.find_last_of(' ');
							if (spacePos != std::string::npos)
							{
								paramPopupState.paramTypes.push_back(param.substr(0, spacePos));
								std::string paramName = param.substr(spacePos + 1);
								paramPopupState.parameters.push_back({ paramName, "" });
								paramPopupState.boolValues.push_back(false);
							}
							params.erase(0, pos + 1);
						}
						if (!params.empty())
						{
							size_t spacePos = params.find_last_of(' ');
							if (spacePos != std::string::npos)
							{
								paramPopupState.paramTypes.push_back(params.substr(0, spacePos));
								std::string paramName = params.substr(spacePos + 1);
								paramPopupState.parameters.push_back({ paramName, "" });
								paramPopupState.boolValues.push_back(false);
							}
						}
					}

					return true;
				};

			if (paramPopupState.show)
			{
				ImGui::OpenPopup("Function Parameters");

				paramPopupState.show = false; // Reset immediately after opening
			}

			// The popup rendering 
			if (ImGui::BeginPopupModal("Function Parameters", nullptr, ImGuiWindowFlags_AlwaysAutoResize))
			{

				try
				{
                    
			    int selectedCanDeviceId = -1;
			    int selectedLinDeviceId = -1;
					ImGui::Text("Configure parameters for: %s", paramPopupState.function.c_str());
					ImGui::Separator();

					bool allValid = true;
					std::string validationError;

					// Validate parameter vectors are the same size
					if (paramPopupState.parameters.size() != paramPopupState.paramTypes.size())
					{
						allValid = false;
						validationError = "Internal error: Parameter count mismatch";
					}
					else
					{
						// Render parameter inputs
						for (size_t i = 0; i < paramPopupState.parameters.size() && i < paramPopupState.paramTypes.size(); i++)
						{
							auto& [name, value] = paramPopupState.parameters[i];
							ImGui::Text("%s:", name.c_str());
							if (paramPopupState.paramTypes[i] == " bool")
							{
								value = "false";
							}
							if (paramPopupState.paramTypes[i] == " bool")
							{
								bool checked = (value == "true");
								if (ImGui::Checkbox(("##param_" + std::to_string(i)).c_str(), &checked))
								{
									value = checked ? "true" : "false";
								}
							}
							else if (name == "channelId")
							{
								int channel = -1;
								if (!value.empty())
								{
									try
									{
										channel = std::stoi(value);
									}
									catch (...)
									{
										channel = -1;
									}
								}

								if (ImGui::InputInt(("##param_" + std::to_string(i)).c_str(), &channel, 1, 10, ImGuiInputTextFlags_CharsDecimal))
								{
									// Clamp value between 1 and 24
									channel = std::clamp(channel, 1, 24);
									value = std::to_string(channel);
								}

								// Validate
								if (value.empty())
								{
									allValid = false;
									validationError = "Channel ID is required";
								}
								else
								{
									try
									{
										int ch = std::stoi(value);
										if (ch < 1 || ch > 24)
										{
											allValid = false;
											validationError = "Channel ID must be between 1-24";
										}
									}
									catch (...)
									{
										allValid = false;
										validationError = "Invalid Channel ID format";
									}
								}
							}



							// btsRevoId parameters - dropdown with available devices
							else if (name == "btsRevoId")
							{
								// Get available device IDs
								std::vector<int> availableIds;
								for (const auto& device : btsDevices)
								{
									availableIds.push_back(device->getDeviceId());
								}

								// Current selected ID
								int currentId = -1;
								if (!value.empty())
								{
									try
									{
										currentId = std::stoi(value);
									}
									catch (...)
									{
										currentId = -1;
									}
								}

								// Combo box for device selection
								if (ImGui::BeginCombo(("##param_" + std::to_string(i)).c_str(),
									currentId == -1 ? "Select Device" : std::to_string(currentId).c_str()))
								{
									for (int id : availableIds)
									{
										bool isSelected = (id == currentId);
										if (ImGui::Selectable(std::to_string(id).c_str(), isSelected))
										{
											value = std::to_string(id);
										}
										if (isSelected)
										{
											ImGui::SetItemDefaultFocus();
										}
									}
									ImGui::EndCombo();
								}

								// Validate
								if (value.empty())
								{
									allValid = false;
									validationError = "BTS Revo ID is required";
								}
								else
								{
									try
									{
										int id = std::stoi(value);
										bool valid = false;
										for (const auto& device : btsDevices)
										{
											// inside loop
											if (device->getDeviceId() == id)
											{
												// Check if this is a Blitz function but device doesn't have Blitz capability
												if (IsBlitzFunction(paramPopupState.function.c_str()))
												{

													valid = device->Blitz; // Only valid if device has Blitz
												}
												// Check if this is a Dagger function but device doesn't have Dagger capability
												else if (IsDaggerFunction(paramPopupState.function.c_str()))
												{
													valid = device->Dagger; // Only valid if device has Dagger
												}
												else
												{
													// Base functions are always valid
													valid = true;
												}
												if (!valid)
												{
													allValid = false;
													validationError = "Invalid BTS Revo ID";
												}
											}
										}
									}
									catch (...)
									{
										allValid = false;
										validationError = "Invalid BTS Revo ID format";
									}
								}
							}
                            					else if (name == "candeviceID" || name == "canmoduleId")
					{
						// Get available LIN device IDs
						std::vector<int> availableIds;
						for (const auto& device : captureModules)
						{
							if (device->GetType() == "CAN")
							{
								availableIds.push_back(device->getDeviceId());
							}
						}

						// Get current selected ID from value
						int currentId = value.empty() ? -1 : std::stoi(value);

						// Show combo box if there are LIN IDs available
						if (!availableIds.empty())
						{
							if (ImGui::BeginCombo(("##param_" + std::to_string(i)).c_str(),
								currentId == -1 ? "Select CAN Device" : std::to_string(currentId).c_str()))
							{
								for (int id : availableIds)
								{
									bool isSelected = (id == currentId);
									if (ImGui::Selectable(std::to_string(id).c_str(), isSelected))
									{
										value = std::to_string(id);
										currentId = id;
									}
									if (isSelected)
									{
										ImGui::SetItemDefaultFocus();
									}
								}
								ImGui::EndCombo();
							}
						}
						else
						{
							ImGui::TextColored(ImVec4(1, 0, 0, 1), "No CAN devices available.");
							allValid = false;
							validationError = "No CAN devices found.";
						}

						// Validate the selected value
						if (value.empty())
						{
							allValid = false;
							validationError = "CAN Device ID is required.";
						}
						else
						{
							try
							{
								int id = std::stoi(value);
								bool valid = false;
								for (const auto& device : captureModules)
								{
									if (device->GetType() == "CAN" && device->getDeviceId() == id)
									{
										valid = true;
										break;
									}
								}
								if (!valid)
								{
									allValid = false;
									validationError = "Selected CAN Device ID is not available.";
								}
								else
								{
									//Valid ID, assign it to an external variable
									selectedCanDeviceId = id;
								}
							}
							catch (...)
							{
								allValid = false;
								validationError = "Invalid CaN Device ID format.";
							}
						}
					}




					else if (name == "lindeviceID" || name == "linmoduleId")
					{
						// Get available LIN device IDs
						std::vector<int> availableIds;
						for (const auto& device : captureModules)
						{
							if (device->GetType() == "LIN")
							{
								availableIds.push_back(device->getDeviceId());
							}
						}

						// Get current selected ID from value
						int currentId = value.empty() ? -1 : std::stoi(value);

						// Show combo box if there are LIN IDs available
						if (!availableIds.empty())
						{
							if (ImGui::BeginCombo(("##param_" + std::to_string(i)).c_str(),
								currentId == -1 ? "Select LIN Device" : std::to_string(currentId).c_str()))
							{
								for (int id : availableIds)
								{
									bool isSelected = (id == currentId);
									if (ImGui::Selectable(std::to_string(id).c_str(), isSelected))
									{
										value = std::to_string(id);
										currentId = id;
									}
									if (isSelected)
									{
										ImGui::SetItemDefaultFocus();
									}
								}
								ImGui::EndCombo();
							}
						}
						else
						{
							ImGui::TextColored(ImVec4(1, 0, 0, 1), "No LIN devices available.");
							allValid = false;
							validationError = "No LIN devices found.";
						}

						// Validate the selected value
						if (value.empty())
						{
							allValid = false;
							validationError = "LIN Device ID is required.";
						}
						else
						{
							try
							{
								int id = std::stoi(value);
								bool valid = false;
								for (const auto& device : captureModules)
								{
									if (device->GetType() == "LIN" && device->getDeviceId() == id)
									{
										valid = true;
										break;
									}
								}
								if (!valid)
								{
									allValid = false;
									validationError = "Selected LIN Device ID is not available.";
								}
								else
								{
									// Valid ID, assign it to an external variable
									selectedLinDeviceId = id;
								}
							}
							catch (...)
							{
								allValid = false;
								validationError = "Invalid LIN Device ID format.";
							}
						}
					}
                    else if ((name == "canChannel" && selectedCanDeviceId != -1) || (name == "linPort" && selectedLinDeviceId != -1))
					{
						std::vector<std::string> availableChannels;
						bool isCAN = (name == "canChannel");

						// Find channels for the selected device
						for (const auto& device : captureModules)
						{
							if (isCAN && device->GetType() == "CAN" && device->getDeviceId() == selectedCanDeviceId)
							{
								availableChannels = device->GetCanChannels(); // std::vector<std::string>
								break;
							}
							else if (!isCAN && device->GetType() == "LIN" && device->getDeviceId() == selectedLinDeviceId)
							{
								availableChannels = device->GetLinChannels(); // std::vector<std::string>
								break;
							}
						}

						std::string currentChannel = value;

						if (!availableChannels.empty())
						{
							const char* label = isCAN ? "##can_channel" : "##lin_port";
							const char* placeholder = isCAN ? "Select CAN Channel" : "Select LIN Port";

							// Show combo box for channel/port selection
							if (ImGui::BeginCombo(label, currentChannel.empty() ? placeholder : currentChannel.c_str()))
							{
								for (const std::string& channel : availableChannels)
								{
									if (channel == "0") continue; // Skip channels equal to "0"

									bool isSelected = (channel == currentChannel);
									if (ImGui::Selectable(channel.c_str(), isSelected))
									{
										value = channel;
										currentChannel = channel;
									}
									if (isSelected)
									{
										ImGui::SetItemDefaultFocus();
									}
								}
								ImGui::EndCombo();
							}
						}
						else
						{
							ImGui::TextColored(ImVec4(1, 0, 0, 1),
								isCAN ? "No CAN channels available for this device."
								: "No LIN ports available for this device.");
							allValid = false;
							validationError = isCAN
								? "No CAN channels found."
								: "No LIN ports found.";
						}

						// Validation
						if (value.empty())
						{
							allValid = false;
							validationError = isCAN
								? "CAN channel is required."
								: "LIN port is required.";
						}
						else if (value == "0" || std::find(availableChannels.begin(), availableChannels.end(), value) == availableChannels.end())
						{
							allValid = false;
							validationError = isCAN
								? "Selected CAN channel is not available."
								: "Selected LIN port is not available.";
						}
					}


							// Other numeric parameters
						else if (paramPopupState.paramTypes[i] == "int" || paramPopupState.paramTypes[i] == "float")
						{
								char buffer[256] = { 0 };
								if (!value.empty())
								{
									strncpy_s(buffer, value.c_str(), sizeof(buffer) - 1);
									buffer[sizeof(buffer) - 1] = '\0';
								}

								ImGuiInputTextFlags flags = (paramPopupState.paramTypes[i] == "int")
									? ImGuiInputTextFlags_CharsDecimal
									: ImGuiInputTextFlags_CharsScientific;

								if (ImGui::InputText(("##param_" + std::to_string(i)).c_str(),
									buffer, sizeof(buffer), flags))
								{
									value = buffer;
								}

								// Validate
								if (value.empty())
								{
									allValid = false;
									validationError = name + " is required";
								}
								else
								{
									try
									{
										if (paramPopupState.paramTypes[i] == "int")
										{
											(void)std::stoi(value);
										}
										else
										{
											(void)std::stof(value);
										}
									}
									catch (...)
									{
										allValid = false;
										validationError = "Invalid " + paramPopupState.paramTypes[i] + " value for " + name;
									}
								}
							}
							// Other parameters
							else
							{
								char buffer[256] = { 0 };
								if (!value.empty())
								{
									strncpy_s(buffer, value.c_str(), sizeof(buffer) - 1);
									buffer[sizeof(buffer) - 1] = '\0';
								}

								if (ImGui::InputText(("##param_" + std::to_string(i)).c_str(),
									buffer, sizeof(buffer)))
								{
									value = buffer;
								}

								if (value.empty())
								{
									allValid = false;
									validationError = name + " is required";
								}
							}
						}
					}

					// Show validation error if any
					if (!allValid)
					{
						ImGui::TextColored(ImVec4(1, 0, 0, 1), "%s", validationError.c_str());
					}

					// OK/Cancel buttons
					if (!allValid)
					{
						ImGui::BeginDisabled();
					}

					bool inputError = false;
					// Action buttons
					if (ImGui::Button("OK", ImVec2(120, 0)) && !inputError)
					{
						try
						{
							// Construct the final function call
							std::string finalFunc = paramPopupState.function.substr(0, paramPopupState.function.find('(') + 1);
							for (size_t i = 0; i < paramPopupState.parameters.size(); i++)
							{
								if (i > 0)
									finalFunc += ", ";
								finalFunc += paramPopupState.parameters[i].second;
							}
							finalFunc += ")";

							// Insert into script
							std::string scriptContent = currentWindow.buffer;
							size_t remainingSpace = sizeof(currentWindow.buffer) - scriptContent.length() - 1;
							std::string toInsert = finalFunc + ";\n";

							if (toInsert.length() < remainingSpace)
							{
								scriptContent.insert(paramPopupState.insertPos, toInsert);
								strncpy_s(currentWindow.buffer, scriptContent.c_str(), sizeof(currentWindow.buffer));
								currentWindow.buffer[sizeof(currentWindow.buffer) - 1] = '\0';
							}
							else
							{
								validationError = "Not enough space in script buffer";
								allValid = false;
							}
							ImGui::CloseCurrentPopup();
						}
						catch (const std::exception& e)
						{
							validationError = "Error creating function: " + std::string(e.what());
							allValid = false;
						}
					}

					if (!allValid)
					{
						ImGui::EndDisabled();
					}

					ImGui::SameLine();
					if (ImGui::Button("Cancel", ImVec2(120, 0)))
					{
						ImGui::CloseCurrentPopup();
					}
				}
				catch (const std::exception& e)
				{
					ImGui::TextColored(ImVec4(1, 0, 0, 1), "Critical error: %s", e.what());
					if (ImGui::Button("Close", ImVec2(120, 0)))
					{
						ImGui::CloseCurrentPopup();
					}
				}
				ImGui::EndPopup();
			}


			auto renderFunctionButton = [&](const std::string& funcCall, size_t funcPos)
				{
					ImGui::BeginGroup();

					std::string idStr = "func_" + std::to_string(funcPos);

					// Check if this is a loop block
					bool isLoop = (funcCall.find("for (") != std::string::npos);

					// Only show arrows if it's not a loop
					if (!isLoop)
					{// Up arrow button 
						ImGui::PushID((idStr + "_up").c_str());
						{
							if (ImGui::ArrowButton("##up", ImGuiDir_Up))
							{
								std::string scriptContent = currentWindow.buffer;

								// Find the current statement boundaries
								size_t currentStart = funcPos;
								size_t currentEnd = scriptContent.find('\n', currentStart);
								if (currentEnd == std::string::npos) currentEnd = scriptContent.length();

								// Find the previous non-empty line
								size_t prevEnd = currentStart;
								while (prevEnd > 0 && isspace(scriptContent[prevEnd - 1])) prevEnd--;

								size_t prevStart = scriptContent.rfind('\n', prevEnd - 1);
								if (prevStart == std::string::npos) prevStart = 0;
								else prevStart++; // Skip the newline

								// Skip whitespace and comments
								while (prevStart < prevEnd &&
									(isspace(scriptContent[prevStart]) ||
										(scriptContent.substr(prevStart, 2) == "//")))
								{
									prevStart = scriptContent.find('\n', prevStart);
									if (prevStart == std::string::npos) break;
									prevStart++;
									prevEnd = scriptContent.find('\n', prevStart);
									if (prevEnd == std::string::npos) prevEnd = scriptContent.length();
								}

								if (prevStart < currentStart && prevEnd <= currentStart)
								{
									// Extract both blocks with their original newlines
									std::string currentBlock = scriptContent.substr(currentStart, currentEnd - currentStart);
									std::string prevBlock = scriptContent.substr(prevStart, prevEnd - prevStart);

									// Remove both blocks
									scriptContent.erase(currentStart, currentEnd - currentStart);
									scriptContent.erase(prevStart, prevEnd - prevStart);

									// Insert them in swapped order
									scriptContent.insert(prevStart, currentBlock);
									scriptContent.insert(prevStart + currentBlock.length(), "\n" + prevBlock);

									// Update the buffer
									strncpy_s(currentWindow.buffer, scriptContent.c_str(), sizeof(currentWindow.buffer));
									currentWindow.buffer[sizeof(currentWindow.buffer) - 1] = '\0';
								}
							}
						}
						ImGui::PopID();
						ImGui::SameLine(0, 4);

						// Down arrow button 
						ImGui::PushID((idStr + "_down").c_str());
						{
							if (ImGui::ArrowButton("##down", ImGuiDir_Down))
							{
								std::string scriptContent = currentWindow.buffer;

								// Find the current statement boundaries
								size_t currentStart = funcPos;
								size_t currentEnd = scriptContent.find('\n', currentStart);
								if (currentEnd == std::string::npos) currentEnd = scriptContent.length();

								// Find the next non-empty line
								size_t nextStart = scriptContent.find_first_not_of(" \t\n", currentEnd);
								if (nextStart != std::string::npos)
								{
									size_t nextEnd = scriptContent.find('\n', nextStart);
									if (nextEnd == std::string::npos) nextEnd = scriptContent.length();

									// Skip whitespace and comments
									while (nextStart < scriptContent.length() &&
										(isspace(scriptContent[nextStart]) ||
											(scriptContent.substr(nextStart, 2) == "//")))
									{
										nextStart = scriptContent.find('\n', nextStart);
										if (nextStart == std::string::npos) break;
										nextStart++;
										nextEnd = scriptContent.find('\n', nextStart);
										if (nextEnd == std::string::npos) nextEnd = scriptContent.length();
									}

									if (nextStart < scriptContent.length() && nextStart > currentEnd)
									{
										// Extract both blocks with their original newlines
										std::string currentBlock = scriptContent.substr(currentStart, currentEnd - currentStart);
										std::string nextBlock = scriptContent.substr(nextStart, nextEnd - nextStart);

										// Remove both blocks
										scriptContent.erase(nextStart, nextEnd - nextStart);
										scriptContent.erase(currentStart, currentEnd - currentStart);

										// Insert them in swapped order
										scriptContent.insert(currentStart, nextBlock + "\n");
										scriptContent.insert(currentStart + nextBlock.length() + 1, currentBlock);

										// Update the buffer
										strncpy_s(currentWindow.buffer, scriptContent.c_str(), sizeof(currentWindow.buffer));
										currentWindow.buffer[sizeof(currentWindow.buffer) - 1] = '\0';
									}
								}
							}
						}
						ImGui::PopID();

						ImGui::SameLine(0, 4);
					}
					else
					{
						ImGui::Dummy(ImVec2(44, 0)); // Approximate width of the arrow buttons
						ImGui::SameLine(0, 4);
					}

					// Remove button (shown for both functions and loops)
					ImGui::PushID((idStr + "_remove").c_str());
					{
						ImGui::PushStyleColor(ImGuiCol_Button, removeButtonColor);
						ImGui::PushStyleColor(ImGuiCol_ButtonHovered, removeButtonHoveredColor);
						ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
						if (ImGui::Button("×", ImVec2(20, 0)))
						{
							// Remove the function/loop from the script
							std::string scriptContent = currentWindow.buffer;
							size_t funcEnd = scriptContent.find(isLoop ? '}' : ';', funcPos) + 1;
							scriptContent.erase(funcPos, funcEnd - funcPos);
							strncpy_s(currentWindow.buffer, scriptContent.c_str(), sizeof(currentWindow.buffer));
						}
						ImGui::PopStyleColor(3);
					}
					ImGui::PopID();

					ImGui::SameLine(0, 4);

					// Function/Loop button
					ImGui::PushID((idStr + "_func").c_str());
					{
						ImGui::PushStyleColor(ImGuiCol_Button, isLoop ? loopHeaderColor : functionButtonColor);
						if (ImGui::Button(funcCall.c_str()))
						{
							if (!isLoop)
							{
								editFunctionPos = funcPos;
								strncpy_s(editFunctionBuffer, funcCall.c_str(), sizeof(editFunctionBuffer));
								droppedFunction = funcCall;
								showParameterPopup = true;
							}
						}

						// Make the loop draggable
						if (isLoop && ImGui::BeginDragDropSource(ImGuiDragDropFlags_None))
						{
							ImGui::SetDragDropPayload("FUNCTION", funcCall.c_str(), funcCall.size() + 1);
							ImGui::Text("Drag to move loop");
							ImGui::EndDragDropSource();
						}

						ImGui::PopStyleColor();
					}
					ImGui::PopID();

					ImGui::EndGroup();
				};

			// Function to render regular text and detect functions
			auto renderTextSegment = [&](const std::string& text, size_t basePos = 0)
				{
					size_t pos = 0;
					while (pos < text.length())
					{
						// Find the next function call
						size_t funcStart = text.find_first_not_of(" \t\n", pos);
						if (funcStart == std::string::npos)
						{
							if (pos < text.length())
							{
								ImGui::Text("%s", text.substr(pos).c_str());
							}
							break;
						}

						size_t funcEnd = text.find(';', funcStart);
						if (funcEnd == std::string::npos)
						{
							ImGui::Text("%s", text.substr(pos).c_str());
							break;
						}

						size_t parenPos = text.find('(', funcStart);
						if (parenPos != std::string::npos && parenPos < funcEnd)
						{
							// Render text before the function
							if (funcStart > pos)
							{
								ImGui::Text("%s", text.substr(pos, funcStart - pos).c_str());
								ImGui::SameLine(0, 0);
							}

							// Extract the function call
							std::string funcCall = text.substr(funcStart, funcEnd - funcStart + 1);

							// Render as button group with arrows
							renderFunctionButton(funcCall, basePos + funcStart);

							// Move position after this function
							pos = funcEnd + 1;
						}
						else
						{
							ImGui::Text("%s", text.substr(pos, funcEnd - pos + 1).c_str());
							pos = funcEnd + 1;
						}
					}
				};
			renderLoopBlock = [&](const std::string& header, const std::string& content, int depth, size_t contentStartPos)
				{
					std::string indent(depth * 4, ' ');
					const float depthAlpha = (0.3f * depth);
					ImVec4 loopBgColor = isDarkTheme ? ImVec4(0.08f * depthAlpha, 0.08f * depthAlpha, 0.12f * depthAlpha, 1.0f) : ImVec4(0.92f * depthAlpha, 0.92f * depthAlpha, 0.96f * depthAlpha, 1.0f);

					ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8, 8));
					ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 4.0f);
					ImGui::PushStyleColor(ImGuiCol_ChildBg, loopBgColor);
					ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.3f, 0.3f, 0.7f, 1.0f));

					ImGui::BeginChild(("##loop_" + std::to_string(contentStartPos)).c_str(), ImVec2(0, 100), true,
						ImGuiWindowFlags_AlwaysUseWindowPadding);

					ImGui::PushStyleColor(ImGuiCol_Header, ImVec4(0.15f, 0.15f, 0.25f, 1.0f));
					ImGui::PushStyleColor(ImGuiCol_HeaderHovered, ImVec4(0.15f, 0.15f, 0.25f, 1.0f));
					ImGui::PushStyleColor(ImGuiCol_HeaderActive, ImVec4(0.15f, 0.15f, 0.25f, 1.0f));

					if (ImGui::CollapsingHeader(header.c_str(), ImGuiTreeNodeFlags_DefaultOpen))
					{
						ImGui::PopStyleColor(3);

						// Make the header draggable
						if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_None))
						{
							std::string cleanLoop = header + " {\n" + content + "\n}";
							ImGui::SetDragDropPayload("FUNCTION", cleanLoop.c_str(), cleanLoop.size() + 1);
							ImGui::Text("Drag to move loop");
							ImGui::EndDragDropSource();
						}

						ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(4, 8));
						ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(4, 4));

						if (ImGui::BeginDragDropTarget())
						{
							if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("FUNCTION"))
							{
								std::string func = (const char*)payload->Data;
								size_t insertPos = contentStartPos + header.length() + content.length();
								handleFunctionDrop(func, insertPos);
							}
							ImGui::EndDragDropTarget();
						}

						std::istringstream contentStream(content);
						std::string line;
						size_t lineStartPos = 0;
						while (std::getline(contentStream, line))
						{
							size_t innerLoopPos = line.find("for (");
							if (innerLoopPos != std::string::npos)
							{
								if (innerLoopPos > 0)
								{
									renderTextSegment(line.substr(0, innerLoopPos), contentStartPos + header.length() + lineStartPos);
								}

								size_t innerLoopEnd = line.find('}', innerLoopPos);
								if (innerLoopEnd == std::string::npos)
								{
									renderTextSegment(line.substr(innerLoopPos), contentStartPos + header.length() + lineStartPos + innerLoopPos);
								}
								else
								{
									std::string innerLoop = line.substr(innerLoopPos, innerLoopEnd - innerLoopPos + 1);
									renderLoopBlock(innerLoop.substr(0, innerLoop.find('{')),
										innerLoop.substr(innerLoop.find('{') + 1,
											innerLoop.rfind('}') - innerLoop.find('{') - 1),
										depth + 1,
										contentStartPos + header.length() + lineStartPos + innerLoopPos);
								}
							}
							else
							{
								renderTextSegment(indent + line, contentStartPos + header.length() + lineStartPos);
							}
							lineStartPos += line.length() + 1;
						}

						ImGui::PopStyleVar(2);
					}
					else
					{
						ImGui::PopStyleColor(3);
					}

					ImGui::EndChild();
					ImGui::PopStyleColor(2);
					ImGui::PopStyleVar(2);
				};

			// Main content parsing and rendering
			while (pos < scriptContent.length())
			{
				size_t loopStart = scriptContent.find("for (", pos);
				if (loopStart != std::string::npos)
				{
					if (loopStart > pos)
					{
						renderTextSegment(scriptContent.substr(pos, loopStart - pos), pos);
					}

					size_t loopEnd = scriptContent.find('}', loopStart);
					if (loopEnd == std::string::npos)
					{
						renderTextSegment(scriptContent.substr(loopStart), loopStart);
						pos = scriptContent.length();
					}
					else
					{
						loopEnd++;
						size_t contentStart = scriptContent.find('{', loopStart) + 1;
						std::string loopHeader = scriptContent.substr(loopStart, contentStart - loopStart);
						std::string loopContent = scriptContent.substr(contentStart, loopEnd - contentStart - 1);
						renderLoopBlock(loopHeader, loopContent, loopDepth, loopStart);
						pos = loopEnd;
					}
				}
				else
				{
					renderTextSegment(scriptContent.substr(pos), pos);
					pos = scriptContent.length();
				}
			}
		}
		ImGui::EndChild();

		if (ImGui::IsWindowFocused() && ImGui::IsKeyDown(ImGuiKey_LeftCtrl) && ImGui::IsKeyPressed(ImGuiKey_S))
		{
			strncpy_s(saveNameBuffer, currentWindow.name.c_str(), sizeof(saveNameBuffer));
			showSavePopup = true;
		}

		if (ImGui::BeginDragDropTarget())
		{
			if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("FUNCTION"))
			{
				std::string func = (const char*)payload->Data;
				if (func.find('(') != std::string::npos)
				{
					Logging::info("drop 3 ");
					droppedFunction = func;
					showParameterPopup = true;
					editFunctionPos = std::string::npos;
				}
				else
				{
					size_t remainingSpace = sizeof(currentWindow.buffer) - strlen(currentWindow.buffer) - 1;
					std::string toAdd = func + ";\n";
					if (toAdd.length() < remainingSpace)
					{
						strncat_s(currentWindow.buffer, toAdd.c_str(), remainingSpace);
					}
				}
			}
			ImGui::EndDragDropTarget();
		}

		ImGui::SetWindowFontScale(1.5f);
		ImGui::TextColored(cyanColor, "Script Related Functions:");
		ImGui::SetWindowFontScale(1.0f);
		ImGui::Separator();

		if (ImGui::Button("Reload Scripts", ImVec2(150, 30)))
		{
			LoadTempScripts(scriptWindows);
			currentWindowIndex = static_cast<int>(scriptWindows.size() - 1);
		}

		ImGui::SameLine();

		if (ImGui::Button("Run on All Devices", ImVec2(150, 30)))
		{
			GenericScriptGUI::RunScript(std::string(currentWindow.buffer), saveDirectory);

		}

		ImGui::SameLine();

		if (ImGui::Button("Import Script", ImVec2(150, 30)))
		{
			showImportPopup = true;
		}

		ImGui::SameLine();

		ImGuiIO& io = ImGui::GetIO();

		// Trigger either on button click or on Ctrl+S press
		bool ctrlS = io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_S, false);

		if (ImGui::Button("Save Script", ImVec2(150, 30)) || ctrlS)
		{
			strncpy_s(saveNameBuffer, currentWindow.name.c_str(), sizeof(saveNameBuffer));
			showSavePopup = true;
		}

		ImGui::SameLine();

		if (ImGui::Button("Clear Script", ImVec2(150, 30)))
		{
			memset(currentWindow.buffer, 0, sizeof(currentWindow.buffer));
		}
		ImGui::SetWindowFontScale(1.6f);
		ImGui::TextColored(cyanColor, "Logs:");
		ImGui::SetWindowFontScale(1.0f);
		ImGui::Separator();

		// Use all remaining vertical space
		ImGui::BeginChild("LogScrolling", ImVec2(0, ImGui::GetContentRegionAvail().y), true, ImGuiWindowFlags_HorizontalScrollbar);
		Logging::renderLogArea();
		ImGui::EndChild();
	}
	ImGui::EndChild();

	// Right Column: Functions Panel
	ImGui::NextColumn();
	ImGui::BeginChild("Right Column", ImVec2(0, 0), true);
	{
		ImGui::SetWindowFontScale(1.8f);
		ImGui::Text("Available Functions");
		ImGui::SetWindowFontScale(1.0f);
		ImGui::Separator();

		// Add case-insensitive filter input at the top
		static char functionFilter[256] = "";
		ImGui::SetNextItemWidth(-1);
		if (ImGui::InputTextWithHint("##FunctionFilter", "Filter functions...", functionFilter, IM_ARRAYSIZE(functionFilter)))
		{
			// Filter updates automatically as we type
		}
		ImGui::Separator();

		// Case-insensitive string comparison helper
		auto caseInsensitiveFind = [](const std::string& str, const std::string& substr) -> bool
			{
				auto it = std::search(
					str.begin(), str.end(),
					substr.begin(), substr.end(),
					[](char ch1, char ch2)
					{ return std::toupper(ch1) == std::toupper(ch2); });
				return it != str.end();
			};

		// Filter function with case-insensitive matching
		auto shouldDisplayFunction = [&](const char* funcName) -> bool
			{
				if (functionFilter[0] == '\0')
					return true;
				return caseInsensitiveFind(std::string(funcName), std::string(functionFilter));
			};

		// BTSRevo Functions
		ImGui::SetWindowFontScale(1.6f);
		if (ImGui::CollapsingHeader("BTSRevo Functions:", ImGuiTreeNodeFlags_DefaultOpen))
		{
			ImGui::Separator();
			ImGui::SetWindowFontScale(1.5f);
			ImGui::Text("Base Functions");
			ImGui::SetWindowFontScale(1.0f);
			ImGui::Separator();
			for (const auto& func : btsRevoBaseFunctions)
			{
				if (!shouldDisplayFunction(func))
					continue;


				if (ImGui::Button(func, ImVec2(-1, 50)))
				{

					droppedFunction = func;
					showParameterPopup = true;
					editFunctionPos = std::string::npos;
				}

				if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_None))
				{
					ImGui::SetDragDropPayload("FUNCTION", func, strlen(func) + 1);
					if (strstr(func, "GetLastReceivedIOMsg") != nullptr)
					{
						ImGui::Text("Returns: {id, channelId, voltage, current, resistance}");
					}
					else
					{
						ImGui::Text("Drop into script editor");
					}
					ImGui::EndDragDropSource();
				}

				if (ImGui::IsItemHovered())
				{
					if (strstr(func, "GetLastReceivedIOMsg") != nullptr)
					{
						ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
						ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
						ImGui::SetTooltip("Returns actual measurements for the specified channel:\n- id: BTSRevo device ID (int)\n- channelId: Channel ID (int)\n- voltage: Actual voltage (V)\n- current: Actual current (A)\n- resistance: Calculated resistance (Ohm)\n\nExample usage:\nvar data = GetLastReceivedIOMsg(1, 5);\nlog('Device ' + data.id + ', Channel ' + data.channelId + ': ' + \ndata.voltage + 'V, ' + data.current + 'A, ' + data.resistance + 'Ohm');");
						ImGui::PopStyleColor(2);
					}
					else
					{
						ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
						ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
						ImGui::SetTooltip("Click to insert or drag into script editor");
						ImGui::PopStyleColor(2);
					}
				}
			}
			ImGui::Separator();
			ImGui::SetWindowFontScale(1.5f);
			ImGui::Text("Blitz Functions");
			ImGui::SetWindowFontScale(1.0f);
			ImGui::Separator();
			for (const auto& func : btsRevoBlitzFunctions)
			{
				if (!shouldDisplayFunction(func))
					continue;


				if (ImGui::Button(func, ImVec2(-1, 50)))
				{

					droppedFunction = func;
					showParameterPopup = true;
					editFunctionPos = std::string::npos;
				}

				if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_None))
				{
					ImGui::SetDragDropPayload("FUNCTION", func, strlen(func) + 1);

					ImGui::Text("Drop into script editor");

					ImGui::EndDragDropSource();
				}

				if (ImGui::IsItemHovered())
				{
					ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
					ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
					ImGui::SetTooltip("Click to insert or drag into script editor");
					ImGui::PopStyleColor(2);
				}
			}
			ImGui::Separator();
			ImGui::SetWindowFontScale(1.5f);
			ImGui::Text("Dagger Functions");
			ImGui::SetWindowFontScale(1.0f);
			ImGui::Separator();
			for (const auto& func : btsRevoDaggerFunctions)
			{
				if (!shouldDisplayFunction(func))
					continue;


				if (ImGui::Button(func, ImVec2(-1, 50)))
				{

					droppedFunction = func;
					showParameterPopup = true;
					editFunctionPos = std::string::npos;
				}

				if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_None))
				{
					ImGui::SetDragDropPayload("FUNCTION", func, strlen(func) + 1);

					ImGui::Text("Drop into script editor");

					ImGui::EndDragDropSource();
				}

				if (ImGui::IsItemHovered())
				{
					ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
					ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
					ImGui::SetTooltip("Click to insert or drag into script editor");
					ImGui::PopStyleColor(2);
				}
			}
		}

		// Capture Module Functions
		ImGui::SetWindowFontScale(1.5f);
		if (ImGui::CollapsingHeader("Capture Module Functions:", ImGuiTreeNodeFlags_DefaultOpen))
		{
			ImGui::SetWindowFontScale(1.0f);
			ImGui::Separator();
			for (const auto& func : captureModuleFunctions)
			{
				if (!shouldDisplayFunction(func))
					continue;

				if (ImGui::Button(func, ImVec2(-1, 50)))
				{
					droppedFunction = func;
					showParameterPopup = true;
					editFunctionPos = std::string::npos;
				}

				if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_None))
				{
					ImGui::SetDragDropPayload("FUNCTION", func, strlen(func) + 1);
					if (strstr(func, "GetLastReceivedCANMsg") != nullptr)
					{
						ImGui::Text("Returns: {id}");
					}
					else if (strstr(func, "GetLastReceivedLINMsg") != nullptr)
					{
						ImGui::Text("Returns: {id}");
					}
					else
					{
						ImGui::Text("Drop into script editor");
					}
					ImGui::EndDragDropSource();
				}

				if (ImGui::IsItemHovered())
				{
					if (strstr(func, "GetLastReceivedCANMsg") != nullptr)
					{
						ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
						ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
						ImGui::SetTooltip("Returns last received CAN message with:\n- id: Module device ID (int)\n- canId: CAN message ID (uint32_t)\n- data: Payload data (vector<uint8_t>)\n- timestamp: Message timestamp in microseconds (uint64_t)\n\nExample usage:\nvar msg = GetLastReceivedCANMsg(1);\nlog('Module ' + msg.id + ': CAN ID ' + msg.canId + ', Data: ' + msg.data);");
						ImGui::PopStyleColor(2);
					}
					else if (strstr(func, "GetLastReceivedLINMsg") != nullptr)
					{
						ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
						ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
						ImGui::SetTooltip("Returns last received LIN message with:\n- id: Module device ID (int)\n- linId: LIN message ID (uint8_t)\n- data: Payload data (vector<uint8_t>)\n- timestamp: Message timestamp in microseconds (uint64_t)\n\nExample usage:\nvar msg = GetLastReceivedLINMsg(1);\nlog('Module ' + msg.id + ': LIN ID ' + msg.linId + ', Data: ' + msg.data);");
						ImGui::PopStyleColor(2);
					}
					else
					{
						ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
						ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
						ImGui::SetTooltip("Click to insert or drag into script editor");
						ImGui::PopStyleColor(2);
					}
				}
			}
		}

		// Utility Functions
		ImGui::SetWindowFontScale(1.5f);
		if (ImGui::CollapsingHeader("Utility Functions:", ImGuiTreeNodeFlags_DefaultOpen))
		{
			ImGui::SetWindowFontScale(1.0f);
			ImGui::Separator();
			if (ImGui::Button("Add For Loop", ImVec2(-1, 50)))
			{
				showForLoopPopup = true;
			}
			if (showForLoopPopup)
			{
				ImGui::OpenPopup("Configure For Loop");
				if (ImGui::BeginPopupModal("Configure For Loop", &showForLoopPopup, ImGuiWindowFlags_AlwaysAutoResize))
				{
					ImGui::Text("Configure your for loop parameters:");
					ImGui::Separator();
					ImGui::InputText("Variable Name", loopVarName, IM_ARRAYSIZE(loopVarName));
					ImGui::InputText("Start Value", loopStart, IM_ARRAYSIZE(loopStart));
					ImGui::InputText("End Value", loopEnd, IM_ARRAYSIZE(loopEnd));
					ImGui::InputText("Step Value", loopStep, IM_ARRAYSIZE(loopStep));

					ImGuiIO& io = ImGui::GetIO();

					bool enterPressed = ImGui::IsKeyPressed(ImGuiKey_Enter) || ImGui::IsKeyPressed(ImGuiKey_KeypadEnter);

					if (ImGui::Button("Insert Loop", ImVec2(120, 0)) || enterPressed)


					{
						std::string forLoop =
							"for (int " + std::string(loopVarName) + " = " + std::string(loopStart) +
							"; " + std::string(loopVarName) + " < " + std::string(loopEnd) +
							"; " + std::string(loopVarName) + " += " + std::string(loopStep) + ") {\n" +
							"    // Your code here\n" +
							"}\n";

						size_t currentLength = strlen(currentWindow.buffer);
						size_t remainingSpace = sizeof(currentWindow.buffer) - currentLength - 1;

						if (forLoop.length() < remainingSpace)
						{
							if (currentLength > 0 && currentWindow.buffer[currentLength - 1] != '\n')
							{
								strncat_s(currentWindow.buffer, "\n", remainingSpace);
								remainingSpace--;
							}

							strncat_s(currentWindow.buffer, forLoop.c_str(), remainingSpace);
						}
						else
						{
							Logging::error("Not enough space in buffer to insert for loop");
						}

						showForLoopPopup = false;
					}
					ImGui::SameLine();
					if (ImGui::Button("Cancel", ImVec2(120, 0)))
					{
						showForLoopPopup = false;
					}
					ImGui::EndPopup();
				}
			}
			const char* utilityFunctions[] = {
				"Sleep(float seconds)" };

			for (const auto& func : utilityFunctions)
			{
				if (!shouldDisplayFunction(func))
					continue;

				if (ImGui::Button(func, ImVec2(-1, 50)))
				{
					droppedFunction = func;
					showParameterPopup = true;
					editFunctionPos = std::string::npos;
				}

				if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_None))
				{
					ImGui::SetDragDropPayload("FUNCTION", func, strlen(func) + 1);
					ImGui::Text("Drop into script editor");
					ImGui::EndDragDropSource();
				}

				if (ImGui::IsItemHovered())
				{
					ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
					ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
					ImGui::SetTooltip("Click to insert or drag into script editor");
					ImGui::PopStyleColor(2);
				}
			}
		}
	}
	ImGui::EndChild();

	ImGui::Columns(1);

	if (showParameterPopup)
	{
		ImGui::OpenPopup("Function Parameters");
		if (ImGui::BeginPopupModal("Function Parameters", &showParameterPopup, ImGuiWindowFlags_AlwaysAutoResize))
		{
			ImGui::Text("Edit parameters for: %s", droppedFunction.c_str());
			ImGui::Separator();
			int selectedCanDeviceId = -1;
			int selectedLinDeviceId = -1;
			size_t paramStart = droppedFunction.find('(');
			size_t paramEnd = droppedFunction.find(')');
			if (paramStart != std::string::npos && paramEnd != std::string::npos)
			{
				std::string params = droppedFunction.substr(paramStart + 1, paramEnd - paramStart - 1);
				std::vector<std::string> paramList;
				size_t pos = 0;

				// Parse parameters
				while ((pos = params.find(',')) != std::string::npos)
				{
					paramList.push_back(params.substr(0, pos));
					params.erase(0, pos + 1);
				}
				if (!params.empty())
					paramList.push_back(params);

				// Initialize parameterInputs if empty
				if (parameterInputs.empty())
				{
					for (const auto& param : paramList)
					{
						size_t spacePos = param.find_last_of(' ');
						if (spacePos != std::string::npos)
						{
							std::string type = param.substr(0, spacePos);
							std::string name = param.substr(spacePos + 1);

							// Trim whitespace
							type.erase(type.find_last_not_of(" \t") + 1);
							name.erase(0, name.find_first_not_of(" \t"));

							// Set default values based on type
							if (type == " bool")
							{
								parameterInputs.push_back({ name, "false" });
							}
							else
							{
								parameterInputs.push_back({ name, "" });
							}
						}
						else
						{
							parameterInputs.push_back({ param, "" });
						}
					}
				}

				// Validate all parameters before allowing submission
				bool allValid = true;
				std::string validationError;

				// Render parameters
				for (size_t i = 0; i < paramList.size(); i++)
				{
					if (i >= parameterInputs.size())
						continue;

					auto& [name, value] = parameterInputs[i];
					ImGui::Text("%s:", name.c_str());
					ImGui::SameLine();

					// Check parameter type (extract from function signature)
					size_t spacePos = paramList[i].find_last_of(' ');
					std::string type = (spacePos != std::string::npos) ? paramList[i].substr(0, spacePos) : "";

					// Boolean parameters - show as checkbox
					if (type == " bool")
					{
						bool checked = (value == "true");
						if (ImGui::Checkbox(("##param_" + std::to_string(i)).c_str(), &checked))
						{
							value = checked ? "true" : "false";
						}
					}
					else if (name == "payload" || name == "canPayload")
					{
						// Buffer for input text (assuming value is std::string)
						char buffer[256] = { 0 };
						strncpy_s(buffer, value.c_str(), sizeof(buffer) - 1);

						// Show the input field with correct signature
						if (ImGui::InputText(("##" + name).c_str(), buffer, sizeof(buffer)))
						{
							value = buffer; // Update the value if changed

							// Optional: Convert to uppercase
							std::transform(value.begin(), value.end(), value.begin(), ::toupper);
						}

						// Then do the validation
						static std::unordered_map<std::string, bool> wasValid;

						if (!value.empty())
						{
							bool isHex = true;
							for (char c : value)
							{
								if (!isxdigit(c))
								{
									isHex = false;
									break;
								}
							}

							if (!isHex)
							{
								ImGui::TextColored(ImVec4(1, 0.5f, 0, 1), "Enter hexadecimal values (0-9, A-F)");
								wasValid[name] = false;
							}
							else
							{
								wasValid[name] = true;
							}
						}

						// Validation for submission
						if (!value.empty() && !wasValid[name])
						{
							allValid = false;
							validationError = "Payload must be in hexadecimal format (0-9, A-F)";
						}
					}
					// Channel ID parameters (1-24)
					else if (name == "channelId")
					{
						int channel = value.empty() ? -1 : std::stoi(value);
						if (ImGui::InputInt(("##param_" + std::to_string(i)).c_str(), &channel, 1, 10, ImGuiInputTextFlags_CharsDecimal))
						{
							// Clamp value between 1 and 24
							channel = std::clamp(channel, 1, 24);
							value = std::to_string(channel);
						}

						// Validate
						if (!value.empty())
						{
							try
							{
								int ch = std::stoi(value);
								if (ch < 1 || ch > 24)
								{
									allValid = false;
									validationError = "Channel ID must be between 1-24";
								}
							}
							catch (...)
							{
								allValid = false;
								validationError = "Invalid Channel ID format";
							}
						}
						else
						{
							allValid = false;
							validationError = "Channel ID is required";
						}

					}
					else if (name == "candeviceID" || name == "canmoduleId")
					{
						// Get available LIN device IDs
						std::vector<int> availableIds;
						for (const auto& device : captureModules)
						{
							if (device->GetType() == "CAN")
							{
								availableIds.push_back(device->getDeviceId());
							}
						}

						// Get current selected ID from value
						int currentId = value.empty() ? -1 : std::stoi(value);

						// Show combo box if there are LIN IDs available
						if (!availableIds.empty())
						{
							if (ImGui::BeginCombo(("##param_" + std::to_string(i)).c_str(),
								currentId == -1 ? "Select CAN Device" : std::to_string(currentId).c_str()))
							{
								for (int id : availableIds)
								{
									bool isSelected = (id == currentId);
									if (ImGui::Selectable(std::to_string(id).c_str(), isSelected))
									{
										value = std::to_string(id);
										currentId = id;
									}
									if (isSelected)
									{
										ImGui::SetItemDefaultFocus();
									}
								}
								ImGui::EndCombo();
							}
						}
						else
						{
							ImGui::TextColored(ImVec4(1, 0, 0, 1), "No CAN devices available.");
							allValid = false;
							validationError = "No CAN devices found.";
						}

						// Validate the selected value
						if (value.empty())
						{
							allValid = false;
							validationError = "CAN Device ID is required.";
						}
						else
						{
							try
							{
								int id = std::stoi(value);
								bool valid = false;
								for (const auto& device : captureModules)
								{
									if (device->GetType() == "CAN" && device->getDeviceId() == id)
									{
										valid = true;
										break;
									}
								}
								if (!valid)
								{
									allValid = false;
									validationError = "Selected CAN Device ID is not available.";
								}
								else
								{
									//Valid ID, assign it to an external variable
									selectedCanDeviceId = id;
								}
							}
							catch (...)
							{
								allValid = false;
								validationError = "Invalid CaN Device ID format.";
							}
						}
					}




					else if (name == "lindeviceID" || name == "linmoduleId")
					{
						// Get available LIN device IDs
						std::vector<int> availableIds;
						for (const auto& device : captureModules)
						{
							if (device->GetType() == "LIN")
							{
								availableIds.push_back(device->getDeviceId());
							}
						}

						// Get current selected ID from value
						int currentId = value.empty() ? -1 : std::stoi(value);

						// Show combo box if there are LIN IDs available
						if (!availableIds.empty())
						{
							if (ImGui::BeginCombo(("##param_" + std::to_string(i)).c_str(),
								currentId == -1 ? "Select LIN Device" : std::to_string(currentId).c_str()))
							{
								for (int id : availableIds)
								{
									bool isSelected = (id == currentId);
									if (ImGui::Selectable(std::to_string(id).c_str(), isSelected))
									{
										value = std::to_string(id);
										currentId = id;
									}
									if (isSelected)
									{
										ImGui::SetItemDefaultFocus();
									}
								}
								ImGui::EndCombo();
							}
						}
						else
						{
							ImGui::TextColored(ImVec4(1, 0, 0, 1), "No LIN devices available.");
							allValid = false;
							validationError = "No LIN devices found.";
						}

						// Validate the selected value
						if (value.empty())
						{
							allValid = false;
							validationError = "LIN Device ID is required.";
						}
						else
						{
							try
							{
								int id = std::stoi(value);
								bool valid = false;
								for (const auto& device : captureModules)
								{
									if (device->GetType() == "LIN" && device->getDeviceId() == id)
									{
										valid = true;
										break;
									}
								}
								if (!valid)
								{
									allValid = false;
									validationError = "Selected LIN Device ID is not available.";
								}
								else
								{
									// Valid ID, assign it to an external variable
									selectedLinDeviceId = id;
								}
							}
							catch (...)
							{
								allValid = false;
								validationError = "Invalid LIN Device ID format.";
							}
						}
					}


					else if ((name == "canChannel" && selectedCanDeviceId != -1) || (name == "linPort" && selectedLinDeviceId != -1))
					{
						std::vector<std::string> availableChannels;
						bool isCAN = (name == "canChannel");

						// Find channels for the selected device
						for (const auto& device : captureModules)
						{
							if (isCAN && device->GetType() == "CAN" && device->getDeviceId() == selectedCanDeviceId)
							{
								availableChannels = device->GetCanChannels(); // std::vector<std::string>
								break;
							}
							else if (!isCAN && device->GetType() == "LIN" && device->getDeviceId() == selectedLinDeviceId)
							{
								availableChannels = device->GetLinChannels(); // std::vector<std::string>
								break;
							}
						}

						std::string currentChannel = value;

						if (!availableChannels.empty())
						{
							const char* label = isCAN ? "##can_channel" : "##lin_port";
							const char* placeholder = isCAN ? "Select CAN Channel" : "Select LIN Port";

							// Show combo box for channel/port selection
							if (ImGui::BeginCombo(label, currentChannel.empty() ? placeholder : currentChannel.c_str()))
							{
								for (const std::string& channel : availableChannels)
								{
									if (channel == "0") continue; // Skip channels equal to "0"

									bool isSelected = (channel == currentChannel);
									if (ImGui::Selectable(channel.c_str(), isSelected))
									{
										value = channel;
										currentChannel = channel;
									}
									if (isSelected)
									{
										ImGui::SetItemDefaultFocus();
									}
								}
								ImGui::EndCombo();
							}
						}
						else
						{
							ImGui::TextColored(ImVec4(1, 0, 0, 1),
								isCAN ? "No CAN channels available for this device."
								: "No LIN ports available for this device.");
							allValid = false;
							validationError = isCAN
								? "No CAN channels found."
								: "No LIN ports found.";
						}

						// Validation
						if (value.empty())
						{
							allValid = false;
							validationError = isCAN
								? "CAN channel is required."
								: "LIN port is required.";
						}
						else if (value == "0" || std::find(availableChannels.begin(), availableChannels.end(), value) == availableChannels.end())
						{
							allValid = false;
							validationError = isCAN
								? "Selected CAN channel is not available."
								: "Selected LIN port is not available.";
						}
					}





					// btsRevoId parameters - dropdown with available devices
					else if (name == "btsRevoId")
					{

						// Get available device IDs
						std::vector<int> availableIds;
						for (const auto& device : btsDevices)
						{
							availableIds.push_back(device->getDeviceId());
						}

						// Current selected ID
						int currentId = value.empty() ? -1 : std::stoi(value);

						// Combo box for device selection
						if (ImGui::BeginCombo(("##param_" + std::to_string(i)).c_str(),
							currentId == -1 ? "Select Device" : std::to_string(currentId).c_str()))
						{
							for (int id : availableIds)
							{
								bool isSelected = (id == currentId);
								if (ImGui::Selectable(std::to_string(id).c_str(), isSelected))
								{
									value = std::to_string(id);
								}
								if (isSelected)
								{
									ImGui::SetItemDefaultFocus();
								}
							}
							ImGui::EndCombo();
						}

						// Validate
						if (value.empty())
						{
							allValid = false;
							validationError = "BTS Revo ID is required";
						}
						else
						{
							try
							{
								int id = std::stoi(value);
								bool valid = false;
								for (const auto& device : btsDevices)
								{
									if (device->getDeviceId() == id)
									{
										// outofloop
										//  Check if this is a Blitz function but device doesn't have Blitz capability
										if (IsBlitzFunction(droppedFunction))
										{
											valid = device->Blitz; // Only valid if device has Blitz
										}
										// Check if this is a Dagger function but device doesn't have Dagger capability
										else if (IsDaggerFunction(droppedFunction))
										{
											valid = device->Dagger; // Only valid if device has Dagger
										}
										else
										{
											// Base functions are always valid
											valid = true;
										}
										if (!valid)
										{
											allValid = false;
											validationError = "Invalid BTS Revo ID";
										}
									}
								}
							}
							catch (...)
							{
								allValid = false;
								validationError = "Invalid BTS Revo ID format";
							}
						}
					}

					// Other numeric parameters
					else if (type == "int" || type == "float")
					{
						char buffer[256] = { 0 };
						strncpy_s(buffer, value.c_str(), sizeof(buffer));

						ImGuiInputTextFlags flags = (type == "int") ? ImGuiInputTextFlags_CharsDecimal : ImGuiInputTextFlags_CharsScientific;

						if (ImGui::InputText(("##param_" + std::to_string(i)).c_str(),
							buffer, sizeof(buffer), flags))
						{
							value = buffer;
						}

						// Validate
						if (!value.empty())
						{
							try
							{
								if (type == "int")
								{
									(void)std::stoi(value);
								}
								else
								{
									(void)std::stof(value);
								}
							}
							catch (...)
							{
								allValid = false;
								validationError = "Invalid " + type + " value for " + name;
							}
						}
						else
						{
							allValid = false;
							validationError = name + " is required";
						}
					}

					// Other parameters
					else
					{
						char buffer[256] = { 0 };
						strncpy_s(buffer, value.c_str(), sizeof(buffer));

						if (ImGui::InputText(("##param_" + std::to_string(i)).c_str(),
							buffer, sizeof(buffer)))
						{
							value = buffer;
						}

						if (value.empty())
						{
							allValid = false;
							validationError = name + " is required";
						}
					}
				}

				// Show validation error if any
				if (!allValid)
				{
					ImGui::TextColored(ImVec4(1, 0, 0, 1), "%s", validationError.c_str());
				}

				// OK/Cancel buttons
				if (!allValid)
				{
					ImGui::BeginDisabled();
				}
				ImGuiIO& io = ImGui::GetIO();

				//bool enterPressed = ImGui::IsKeyPressed(ImGuiKey_Enter) || ImGui::IsKeyPressed(ImGuiKey_KeypadEnter);

				if ((ImGui::Button("OK", ImVec2(120, 0)) ) && !inputError)
				{
					// Reconstruct function call
					std::string newFunction = droppedFunction.substr(0, droppedFunction.find('(') + 1);
					for (size_t i = 0; i < parameterInputs.size(); i++)
					{
						if (i > 0)
							newFunction += ", ";
						newFunction += parameterInputs[i].second;
					}
					newFunction += ")";

					// Insert into script
					if (editFunctionPos != std::string::npos)
					{
						std::string content = currentWindow.buffer;
						size_t funcEnd = content.find(')', editFunctionPos);
						if (funcEnd != std::string::npos)
						{
							content.replace(editFunctionPos, funcEnd - editFunctionPos + 1, newFunction);
							strncpy_s(currentWindow.buffer, content.c_str(), sizeof(currentWindow.buffer));
						}
					}
					else
					{
						size_t remainingSpace = sizeof(currentWindow.buffer) - strlen(currentWindow.buffer) - 1;
						std::string toAdd = newFunction + ";\n";
						if (toAdd.length() < remainingSpace)
						{
							strncat_s(currentWindow.buffer, toAdd.c_str(), remainingSpace);
						}
					}
					showParameterPopup = false;
					parameterInputs.clear();
				}
				if (!allValid)
				{
					ImGui::EndDisabled();
				}
				ImGui::SameLine();
				if (ImGui::Button("Cancel", ImVec2(120, 0)))
				{
					showParameterPopup = false;
					parameterInputs.clear();
				}
			}
			ImGui::EndPopup();
		}
	}

	if (showSavePopup)
	{
		showSavePopup = false; // Close the popup immediately

		OPENFILENAMEA ofn;
		CHAR szFile[260] = { 0 };

		// Initialize with current script name
		strncpy_s(szFile, currentWindow.name.c_str(), sizeof(szFile) - 1);
		strcat_s(szFile, ".txt"); // Default extension

		// Initialize OPENFILENAME
		ZeroMemory(&ofn, sizeof(ofn));
		ofn.lStructSize = sizeof(ofn);
		ofn.hwndOwner = nullptr; // Or your window handle if available
		ofn.lpstrFile = szFile;
		ofn.nMaxFile = sizeof(szFile);
		ofn.lpstrFilter = "Text Files (*.txt)\0*.TXT\0All Files (*.*)\0*.*\0";
		ofn.nFilterIndex = 1;
		ofn.lpstrDefExt = "txt";
		ofn.Flags = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT;

		if (GetSaveFileNameA(&ofn) == TRUE)
		{
			std::string filePath = ofn.lpstrFile;

			// Ensure .txt extension if not already present
			if (filePath.size() < 4 || filePath.substr(filePath.size() - 4) != ".txt")
			{
				filePath += ".txt";
			}

			std::ofstream outFile(filePath);
			if (outFile.is_open())
			{
				outFile << currentWindow.buffer;
				outFile.close();

				// Update window title to match saved filename (without extension)
				std::filesystem::path pathObj(filePath);
				currentWindow.name = pathObj.stem().string();

				Logging::info("Script saved to: {}", filePath);
			}
			else
			{
				Logging::error("Failed to save script to: {}", filePath);
			}
		}
	}
}
