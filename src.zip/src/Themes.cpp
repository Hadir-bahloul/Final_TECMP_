#include "../include/Themes.h"

void Themes::SetDarkTheme() {
    ImGuiStyle& style = ImGui::GetStyle();
    
    // Modern dark theme with blue accents
    style.Colors[ImGuiCol_Text] = GetColor(ColorType::Text);
    style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.08f, 0.08f, 0.10f, 1.00f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0.06f, 0.0f, 0.15f, 1.0f);
    style.Colors[ImGuiCol_PopupBg] = ImVec4(0.08f, 0.08f, 0.10f, 0.94f);
    style.Colors[ImGuiCol_Border] = ImVec4(0.20f, 0.20f, 0.25f, 1.00f);
    style.Colors[ImGuiCol_BorderShadow] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.15f, 0.15f, 0.20f, 1.00f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.20f, 0.20f, 0.25f, 1.00f);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.25f, 0.25f, 0.30f, 1.00f);
    style.Colors[ImGuiCol_TitleBg] = ImVec4(0.06f, 0.06f, 0.08f, 1.00f);
    style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.08f, 0.08f, 0.10f, 1.00f);
    style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.00f, 0.00f, 0.00f, 0.51f);
    style.Colors[ImGuiCol_MenuBarBg] = ImVec4(0.10f, 0.10f, 0.12f, 1.00f);
    style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.10f, 0.10f, 0.12f, 1.00f);
    style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.30f, 0.30f, 0.40f, 1.00f);
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.40f, 0.40f, 0.50f, 1.00f);
    style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.50f, 0.50f, 0.60f, 1.00f);
    style.Colors[ImGuiCol_CheckMark] = GetColor(ColorType::Accent);
    style.Colors[ImGuiCol_SliderGrab] = GetColor(ColorType::Accent);
    style.Colors[ImGuiCol_SliderGrabActive] = GetColor(ColorType::AccentLight);
    style.Colors[ImGuiCol_Button] = GetColor(ColorType::Primary);
    style.Colors[ImGuiCol_ButtonHovered] = GetColor(ColorType::PrimaryLight);
    style.Colors[ImGuiCol_ButtonActive] = GetColor(ColorType::Highlight);
    style.Colors[ImGuiCol_Header] = GetColor(ColorType::Primary);
    style.Colors[ImGuiCol_HeaderHovered] = GetColor(ColorType::PrimaryLight);
    style.Colors[ImGuiCol_HeaderActive] = GetColor(ColorType::Highlight);
    style.Colors[ImGuiCol_Separator] = ImVec4(0.20f, 0.20f, 0.25f, 1.00f);
    style.Colors[ImGuiCol_SeparatorHovered] = GetColor(ColorType::PrimaryLight);
    style.Colors[ImGuiCol_SeparatorActive] = GetColor(ColorType::Highlight);
    style.Colors[ImGuiCol_ResizeGrip] = ImVec4(0.30f, 0.30f, 0.40f, 0.20f);
    style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.40f, 0.40f, 0.50f, 0.67f);
    style.Colors[ImGuiCol_ResizeGripActive] = GetColor(ColorType::Highlight);
    style.Colors[ImGuiCol_Tab] = ImVec4(0.10f, 0.10f, 0.12f, 1.00f);
    style.Colors[ImGuiCol_TabHovered] = GetColor(ColorType::PrimaryLight);
    style.Colors[ImGuiCol_TabActive] = GetColor(ColorType::Primary);
    style.Colors[ImGuiCol_TabUnfocused] = ImVec4(0.10f, 0.10f, 0.12f, 1.00f);
    style.Colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.15f, 0.15f, 0.20f, 1.00f);
    style.Colors[ImGuiCol_PlotLines] = GetColor(ColorType::Accent);
    style.Colors[ImGuiCol_PlotLinesHovered] = GetColor(ColorType::AccentLight);
    style.Colors[ImGuiCol_PlotHistogram] = GetColor(ColorType::Accent);
    style.Colors[ImGuiCol_PlotHistogramHovered] = GetColor(ColorType::AccentLight);
    style.Colors[ImGuiCol_TableHeaderBg] = ImVec4(0.10f, 0.10f, 0.12f, 1.00f);
    style.Colors[ImGuiCol_TableBorderStrong] = ImVec4(0.20f, 0.20f, 0.25f, 1.00f);
    style.Colors[ImGuiCol_TableBorderLight] = ImVec4(0.20f, 0.20f, 0.25f, 0.50f);
    style.Colors[ImGuiCol_TableRowBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    style.Colors[ImGuiCol_TableRowBgAlt] = ImVec4(1.00f, 1.00f, 1.00f, 0.03f);
    style.Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.00f, 0.40f, 0.80f, 0.35f);
    style.Colors[ImGuiCol_DragDropTarget] = GetColor(ColorType::Highlight);
    style.Colors[ImGuiCol_NavHighlight] = GetColor(ColorType::Highlight);
    style.Colors[ImGuiCol_NavWindowingHighlight] = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
    style.Colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
    style.Colors[ImGuiCol_ModalWindowDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.35f);

    // Rounding and spacing
    style.WindowPadding = ImVec2(8.0f, 8.0f);
    style.FramePadding = ImVec2(12.0f, 6.0f);
    style.CellPadding = ImVec2(6.0f, 6.0f);
    style.ItemSpacing = ImVec2(8.0f, 6.0f);
    style.ItemInnerSpacing = ImVec2(6.0f, 6.0f);
    style.TouchExtraPadding = ImVec2(0.0f, 0.0f);
    style.IndentSpacing = 20.0f;
    style.ScrollbarSize = 14.0f;
    style.GrabMinSize = 12.0f;
    
    // Border and rounding
    style.WindowBorderSize = 1.0f;
    style.ChildBorderSize = 1.0f;
    style.PopupBorderSize = 1.0f;
    style.FrameBorderSize = 1.0f;
    style.TabBorderSize = 1.0f;
    
    // Rounding
    style.WindowRounding = 8.0f;
    style.ChildRounding = 8.0f;
    style.FrameRounding = 6.0f;
    style.PopupRounding = 8.0f;
    style.ScrollbarRounding = 6.0f;
    style.GrabRounding = 6.0f;
    style.TabRounding = 8.0f;
    
    // Alignment
    style.WindowTitleAlign = ImVec2(0.5f, 0.5f);
    style.ButtonTextAlign = ImVec2(0.5f, 0.5f);
    
    // Font scaling
    ImGui::GetIO().FontGlobalScale = 1.0f;
}
void Themes::SetLightTheme() {
    ImGuiStyle& style = ImGui::GetStyle();

    // Set font scale to make text larger
    ImGui::GetIO().FontGlobalScale = 1.0f;

    // Base colors (light and professional)
    style.Colors[ImGuiCol_Text] = ImVec4(0.10f, 0.10f, 0.10f, 1.00f); // Dark text for light theme
    style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.60f, 0.60f, 0.60f, 1.00f); // Light gray for disabled text
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.96f, 0.96f, 0.96f, 1.00f); // Soft off-white background
    style.Colors[ImGuiCol_ChildBg] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f); // Pure white for child windows
    style.Colors[ImGuiCol_Border] = ImVec4(0.80f, 0.80f, 0.80f, 1.00f); // Light gray border
    style.Colors[ImGuiCol_FrameBg] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f); // White frame background
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.95f, 0.95f, 0.95f, 1.00f); // Slightly darker on hover
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.90f, 0.90f, 0.90f, 1.00f); // Slightly darker when active
    style.Colors[ImGuiCol_TitleBg] = ImVec4(0.90f, 0.90f, 0.90f, 1.00f); // Light gray title bar
    style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.96f, 0.96f, 0.96f, 1.00f); // Slightly lighter for active title
    style.Colors[ImGuiCol_MenuBarBg] = ImVec4(0.90f, 0.90f, 0.90f, 1.00f); // Light gray background for MenuBar
    style.Colors[ImGuiCol_PopupBg] = ImVec4(0.90f, 0.90f, 0.90f, 1.00f); // Light gray background for popups
    style.Colors[ImGuiCol_Separator] = ImVec4(0.80f, 0.80f, 0.80f, 1.00f); // Light gray separator

    // Accent colors (blue theme)
    style.Colors[ImGuiCol_Button] = ImVec4(0.00f, 0.40f, 0.80f, 1.00f); // Dark blue
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.00f, 0.50f, 0.90f, 1.00f); // Brighter blue on hover
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.00f, 0.30f, 0.70f, 1.00f); // Darker blue when active

    // Additional UI elements
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.00f, 0.40f, 0.80f, 1.00f); // Dark blue checkmark
    style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.00f, 0.40f, 0.80f, 1.00f); // Dark blue slider grab
    style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.00f, 0.50f, 0.90f, 1.00f); // Brighter blue slider grab
    style.Colors[ImGuiCol_ResizeGrip] = ImVec4(0.00f, 0.40f, 0.80f, 0.20f); // Subtle blue resize grip
    style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.00f, 0.50f, 0.90f, 0.60f); // Brighter blue on hover
    style.Colors[ImGuiCol_ResizeGripActive] = ImVec4(0.00f, 0.30f, 0.70f, 1.00f); // Darker blue when active

    // Ensure text in headers and titles is visible
    style.Colors[ImGuiCol_Header] = ImVec4(0.00f, 0.40f, 0.80f, 1.00f); // Dark blue for headers
    style.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.00f, 0.50f, 0.90f, 1.00f); // Brighter blue on hover
    style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.00f, 0.30f, 0.70f, 1.00f); // Darker blue when active

    // Rounding and spacing for a clean look
    style.FrameRounding = 12.0f; // Rounded corners for buttons and other frame elements
    style.GrabRounding = 12.0f; // Rounded corners for sliders and grab elements
    style.WindowRounding = 12.0f; // Rounded corners for windows
    style.ChildRounding = 12.0f; // Rounded corners for child windows
    style.ScrollbarRounding = 12.0f; // Rounded corners for scrollbars
    style.TabRounding = 12.0f; // Rounded corners for tabs
}

ImVec4 Themes::GetColor(ColorType type) {
    switch (type) {
        case ColorType::Primary: return ImVec4(0.00f, 0.40f, 0.80f, 1.0f); // Dark blue
        case ColorType::PrimaryLight: return ImVec4(0.00f, 0.50f, 0.90f, 1.0f); // Brighter blue
        case ColorType::Secondary: return ImVec4(0.10f, 0.10f, 0.10f, 1.0f); // Dark gray
        case ColorType::SecondaryLight: return ImVec4(0.20f, 0.20f, 0.20f, 1.0f); // Lighter gray
        case ColorType::Accent: return ImVec4(0.00f, 0.40f, 0.80f, 1.0f); // Dark blue
        case ColorType::AccentLight: return ImVec4(0.00f, 0.50f, 0.90f, 1.0f); // Brighter blue
        case ColorType::Text: return ImVec4(0.95f, 0.95f, 0.95f, 1.0f); // Bright white text
        case ColorType::TextLight: return ImVec4(0.60f, 0.60f, 0.60f, 1.0f); // Light gray text
        case ColorType::Error: return ImVec4(0.86f, 0.15f, 0.15f, 1.0f); // Red for errors
        case ColorType::Warning: return ImVec4(0.56f, 0.42f, 0.04f, 1.0f); // Orange for warnings
        default: return ImVec4(1.0f, 1.0f, 1.0f, 1.0f); // Default white
    }
}