#include "../include/DeviceFactory.h"
#include "../include/BTSRevoDevice.h"
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include "TE-DriverBase/DriverBaseTypes.hpp"
#include "TE-DriverBase/DriverBaseMain.hpp"
#include "TE-DriverBase/DriverBaseInterface.hpp"
#include "TE-BTS-Driver/InitData.hpp"
#include "TE-BTS-Driver/Interfaces.hpp"
#include "TE-BTS-Driver/Types.hpp"
#include "../include/DeviceFactory.h"
#include "../include/Logging.h"
#include "../include/CaptureModuleDevice.h"
#include <vector>
#include <memory>
#include <chrono>
#include <thread>
#include <map>
#include <mutex>
#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif

using namespace std;
using namespace TE::Driver;
using namespace TE;

static std::mutex canframeMutex;
std::shared_ptr<TE::Driver::ITEDriverIOs> DeviceFactory::iosInterface;
std::vector<uint32_t> DeviceFactory::channels;
std::shared_ptr<TE::Driver::ITEDriver> DeviceFactory::_tecmp_driver_;
std::vector<TE::Driver::Devices> DeviceFactory::_discovered_devices;
std::vector<Message> CaptureModuleDevice::frame;
static std::mutex _mutex;
std::unordered_map<int, std::shared_ptr<BTSRevoDevice>> DeviceFactory::deviceMap;

class Logger : public TE::Driver::ILogger {
public:
    Logger() = default;
    ~Logger() = default;
    void info(const std::string& msg) const override;
    void debug(const std::string& msg) const override;
    void warn(const std::string& msg) const override;
    void error(const std::string& msg) const override;
};

class BusEventProcessor : public TE::Driver::ICanFrameListener,
    public TE::Driver::ICanTxEventListener,
    public TE::Driver::ILinEventListener,
    public TE::Driver::IEventsListener,
    public TE::Driver::IFrEventListener {
public:
    BusEventProcessor() {};
    ~BusEventProcessor() {};
    void receiveCanFrame(TE::Driver::ICanFrameSPtrT frame) override;
    void receiveCanTxEvent(TE::Driver::ICanTxEventSPtrT event) override;
    void receiveLinEvent(TE::Driver::ILinEventSPtrT event) override;
    void receiveFrEvent(TE::Driver::IFrEventSPtrT frame) override;
    std::string name;
};

class BTSRevoEventProcessor : public TE::Driver::ITECMPIOEventListener {
public:
    void receiveIOEvent(const uint8_t BoardNumber,
        const uint16_t btsChannelNumber,
        const TE::Driver::TECMPchannelStatus channel,
        const Base::u64 timestamp,
        const TE::Base::u64 absoluteTimestamp) override;
    void receivePwmEvent(const TE::Base::u8 btsBoardNumber,
        const TE::Base::u8 channelNumber,
        const float dutyCycle,
        const double frequency,
        const TE::Base::u64 timestamp,
        const TE::Base::u64 absoluteTimestamp) override;
    void receiveAnalogIOEvent(const TE::Base::u16 deviceid,
        TE::Base::u32 interfaceId,
        const TE::Driver::TECMPMultipleAnalogEvent& analogEvent) override;
};

auto LoggerHandler = std::make_shared<Logger>();
std::shared_ptr<TE::Driver::BTS::BTSInitData> btsInit;
shared_ptr<TE::Driver::TECMPDeviceInitData> CMInit;

std::shared_ptr<TE::Driver::ITEDriver> createTECMPDriver(std::shared_ptr<BusEventProcessor> busProcessor,
    std::shared_ptr<BTSRevoEventProcessor> RevoProcessor) {
    CMInit = std::make_shared<TE::Driver::TECMPDeviceInitData>();

    auto _device_driver_ = dynamic_pointer_cast<TE::Driver::ITEDriver>(
        TE::Driver::initDriver(
            busProcessor.get(),
            busProcessor.get(),
            busProcessor.get(),
            busProcessor.get(),
            RevoProcessor.get(),
            busProcessor.get(),
            CMInit.get(),
            LoggerHandler.get()
        )
    );
    return _device_driver_;
}

void Logger::info(const std::string& msg) const {
    std::cout << msg << endl;
}

void Logger::debug(const std::string& msg) const {
    std::cout << msg << endl;
}

void Logger::warn(const std::string& msg) const {
    std::cout << msg << endl;
}

void Logger::error(const std::string& msg) const {
    std::cout << msg << endl;
}

void BusEventProcessor::receiveCanFrame(TE::Driver::ICanFrameSPtrT frame) {
    Message msg;
    msg.timestamp = std::to_string(frame->timestamp());
    msg.fieldId = std::to_string(frame->deviceId());
    msg.dataLength = static_cast<int>(frame->canDlc());

    // Convert payload to hex string
    std::stringstream ss;
    for (int i = 0; i < frame->canDlc(); i++) {
        ss << std::hex << std::uppercase << std::setw(2) << std::setfill('0')
            << static_cast<int>(frame->payload()[i]);
    }
    msg.data = ss.str();
    msg.dataFlags = std::to_string(frame->statusFlags().second);

    // Lock to ensure thread safety
    std::lock_guard<std::mutex> lock(canframeMutex);

    // Remove old message with same deviceId if it exists
    auto& messages = CaptureModuleDevice::frame;
    for (auto it = messages.begin(); it != messages.end(); ) {
        if (it->fieldId == msg.fieldId) {
            it = messages.erase(it);
        }
        else {
            ++it;
        }
    }

    // Add the new message
    messages.push_back(msg);
}


void BTSRevoEventProcessor::receiveIOEvent(const uint8_t BoardNumber,
    const uint16_t btsChannelNumber,
    const TE::Driver::TECMPchannelStatus channel,
    const Base::u64 timestamp,
    const TE::Base::u64 absoluteTimestamp) {
    if (DeviceFactory::deviceMap.count(BoardNumber)) {
        DeviceFactory::deviceMap[BoardNumber]->setChannelVoltage(btsChannelNumber, channel.voltage);
        DeviceFactory::deviceMap[BoardNumber]->setChannelCurrent(btsChannelNumber, channel.current);
    }
}

void BusEventProcessor::receiveLinEvent(TE::Driver::ILinEventSPtrT event) {
    Message msg;
    msg.timestamp = std::to_string(event->timestamp());
    msg.fieldId = std::to_string(event->deviceId());
    msg.dataLength = static_cast<int>(event->payloadLength());

    // Convert payload to hex string
    std::stringstream ss;
    for (int i = 0; i < event->payloadLength(); i++) {
        ss << std::hex << std::uppercase << std::setw(2) << std::setfill('0')
            << static_cast<int>(event->payload()[i]);
    }
    msg.data = ss.str();
    msg.dataFlags = std::to_string(event->status());

    // Lock to ensure thread safety
    std::lock_guard<std::mutex> lock(canframeMutex);

    // Remove old message with same deviceId if it exists
    auto& messages = CaptureModuleDevice::frame;
    for (auto it = messages.begin(); it != messages.end(); ) {
        if (it->fieldId == msg.fieldId) {
            it = messages.erase(it);
        }
        else {
            ++it;
        }
    }

    // Add the new message
    messages.push_back(msg);
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
}

void BusEventProcessor::receiveCanTxEvent(TE::Driver::ICanTxEventSPtrT event) {
}

void BusEventProcessor::receiveFrEvent(TE::Driver::IFrEventSPtrT frame) {
}

void BTSRevoEventProcessor::receivePwmEvent(TE::Base::u8 btsBoardNumber,
    TE::Base::u8 channelNumber,
    float dutyCycle,
    double frequency,
    const TE::Base::u64 timestamp,
    const TE::Base::u64 absoluteTimestamp) {
}

void BTSRevoEventProcessor::receiveAnalogIOEvent(const TE::Base::u16 deviceid,
    TE::Base::u32 interfaceId,
    const TE::Driver::TECMPMultipleAnalogEvent& analogEvent) {
}

std::shared_ptr<BusEventProcessor> cm_busProcessor;
std::shared_ptr<BTSRevoEventProcessor> BTS_busRevoproocessor;

void DeviceFactory::initializeDriver() {
    std::lock_guard<std::mutex> lock(_mutex);
    if (!DeviceFactory::_tecmp_driver_) {
        cm_busProcessor = std::make_shared<BusEventProcessor>();
        BTS_busRevoproocessor = std::make_shared<BTSRevoEventProcessor>();

        cm_busProcessor->name = "CM";

        DeviceFactory::_tecmp_driver_ = createTECMPDriver(cm_busProcessor, BTS_busRevoproocessor);

        if (!DeviceFactory::_tecmp_driver_) {
            Logging::error("Failed to initialize TECMP driver");
        }
    }
}

void DeviceFactory::discoverDevices() {
    DeviceFactory::initializeDriver();
    if (DeviceFactory::_tecmp_driver_ && DeviceFactory::_discovered_devices.empty()) {
        DeviceFactory::_discovered_devices = DeviceFactory::_tecmp_driver_->getDevices();
    }
}

std::shared_ptr<TE::Driver::ITEDriverIOs> getDriverIOsInterface() {
    // Cast the driver to ITEDriverIOs interface
    auto iosInterface = std::dynamic_pointer_cast<TE::Driver::ITEDriverIOs>(DeviceFactory::_tecmp_driver_);
    if (!iosInterface) {
        Logging::error("Failed to get IOs interface from driver");
        return nullptr;
    }
    return iosInterface;
}

std::shared_ptr<CaptureModuleDevice> DeviceFactory::CreateCANCaptureModuleDevice(TE::Base::u16 Id) {
    Logging::info("id {}", Id);
    return std::make_shared<CANCaptureModuleDevice>(Id);
}

std::shared_ptr<CaptureModuleDevice> DeviceFactory::CreateLINCaptureModuleDevice(TE::Base::u16 Id) {
    return std::make_shared<LINCaptureModuleDevice>(Id);
}

std::vector<std::shared_ptr<BTSRevoDevice>> DeviceFactory::DiscoverBTSRevoDevices() {
    DeviceFactory::discoverDevices();
    DeviceFactory::iosInterface = std::dynamic_pointer_cast<TE::Driver::ITEDriverIOs>(DeviceFactory::_tecmp_driver_);
    if (DeviceFactory::iosInterface) {
        Logging::warn("IO Functions");
    }
    else {
        Logging::warn("IOs interface not available");
    }

    for (const auto& dev : DeviceFactory::_discovered_devices) {
        Logging::info("dev type {} dev id {}", dev.deviceType, dev.deviceId);
    }
    Logging::info("Device count: {}", DeviceFactory::_discovered_devices.size());


    std::vector<std::shared_ptr<BTSRevoDevice>> result;
    result.reserve(DeviceFactory::_discovered_devices.size());
    for (const auto& dev : DeviceFactory::_discovered_devices) {
        Logging::info("dev type {}", dev.deviceType);
        if (dev.deviceType == 80) {
            auto device = std::make_shared<BTSRevoDevice>(
                dev.deviceType,
                dev.deviceId,
                dev.deviceIp
            );
            result.emplace_back(device);
            DeviceFactory::deviceMap[dev.deviceId] = device;  // Store the shared_ptr
        }
    }

    if (result.empty()) {
        Logging::warn("No BTSRevo devices discovered");
    }

    return result;
}

std::vector<std::shared_ptr<CaptureModuleDevice>> DeviceFactory::DiscoverCaptureModuleDevices() {
    std::vector<std::shared_ptr<CaptureModuleDevice>> dev;

    for (const auto& d : DeviceFactory::_discovered_devices) {
        if (d.deviceType == 4) {
            auto newDevice = CreateCANCaptureModuleDevice(d.deviceId);
            dev.push_back(newDevice);
            for (uint32_t c : d.channels) {
                newDevice->canChannels.push_back(std::to_string(c));
            }
        }
        else if (d.deviceType == 2) {
            auto newDevice = CreateLINCaptureModuleDevice(d.deviceId);
            dev.push_back(newDevice);
            for (uint32_t c : d.channels) {
                newDevice->linChannels.push_back(std::to_string(c));
            }
        }
    }
    return dev;
}