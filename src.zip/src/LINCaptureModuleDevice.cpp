#include "../include/LINCaptureModuleDevice.h"
#include "../include/CaptureModuleDevice.h"
#include <TE-DriverBase/DriverBaseInitData.hpp>
#include "../include/Logging.h"
LINCaptureModuleDevice::LINCaptureModuleDevice(uint16_t index)
    : CaptureModuleDevice(static_cast<TE::Base::u16>(2), index,"10.104.3." + std::to_string(index)) {
}

std::string LINCaptureModuleDevice::GetType() const {  
    return "LIN";
}