#include "../include/Logging.h"

std::shared_ptr<spdlog::logger> Logging::logger;
std::vector<std::pair<std::string, ImVec4>> Logging::logs;

void Logging::init(const std::string& loggerName, const std::string& filePath) {
    try {
        std::vector<spdlog::sink_ptr> sinks;
        
        // Always add console sink
        sinks.push_back(std::make_shared<spdlog::sinks::stdout_color_sink_mt>());
        
        // Add file sink if path is provided
        if (!filePath.empty()) {
            // true parameter enables append mode
            sinks.push_back(std::make_shared<spdlog::sinks::basic_file_sink_mt>(filePath, true));
        }
        
        logger = std::make_shared<spdlog::logger>(loggerName, begin(sinks), end(sinks));
        logger->set_level(spdlog::level::trace);  // Capture all log levels
        logger->flush_on(spdlog::level::err);     // Auto-flush on errors
        
        // Set log pattern
        logger->set_pattern("[%Y-%m-%d %H:%M:%S] [%l] %v");
        
        spdlog::register_logger(logger);
        info("Logger initialized");
    } catch (const spdlog::spdlog_ex& ex) {
        printf("Log initialization failed: %s\n", ex.what());
    }
}

const std::vector<std::pair<std::string, ImVec4>>& Logging::getLogs() {
    return logs;
}

void Logging::renderLogArea() {
    if (ImGui::BeginChild("LogArea", ImVec2(0, 0), true, ImGuiWindowFlags_HorizontalScrollbar)) {
        for (const auto& log : logs) {
            ImGui::PushStyleColor(ImGuiCol_Text, log.second);
            ImGui::TextWrapped("%s", log.first.c_str());
            ImGui::PopStyleColor();
        }
        
        // Auto-scroll to bottom
        if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY()) {
            ImGui::SetScrollHereY(1.0f);
        }
    }
    ImGui::EndChild();
}

std::string Logging::getCurrentTimestamp() {
    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);

    std::tm tm_struct;
    if (localtime_s(&tm_struct, &in_time_t) != 0) {
        // handle error if needed, for now just return empty or some fallback
        return {};
    }

    std::stringstream ss;
    ss << std::put_time(&tm_struct, "[%Y-%m-%d %H:%M:%S]");
    return ss.str();
}


ImVec4 Logging::getColorForLevel(spdlog::level::level_enum level) {
    switch (level) {
        case spdlog::level::info:    return ImVec4(0.0f, 0.50f, 0.0f, 1.0f);  // Green
        case spdlog::level::debug:   return ImVec4(0.5f, 0.5f, 0.5f, 1.0f);  // Gray
        case spdlog::level::warn:    return ImVec4(0.86f, 0.62f, 0.04f, 1.0f);  // Yellow
        case spdlog::level::err:     return ImVec4(1.0f, 0.0f, 0.0f, 1.0f);  // Red
        default:                     return ImVec4(1.0f, 1.0f, 1.0f, 1.0f);  // White
    }
}
void Logging::clean() {
    logs.clear();
}
