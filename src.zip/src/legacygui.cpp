#include "../include/legacygui.h"
#include "../include/DeviceFactory.h"
#include "../include/BTSRevoGUI.h"
#include "../include/Logging.h"
#include "../include/CaptureModuleDevice.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <cctype>
#include <chrono>
#include <thread>

static std::mutex dataMutex;
static std::mutex frameMutex;

void LegacyGUI::RenderCaptureModuleControl(std::shared_ptr<CaptureModuleDevice> device, int selectedCaptureModuleIndex, const std::string& directoryPath, bool& isDarkTheme) {
    ImVec4 primaryColor = Themes::GetColor(isDarkTheme ? ColorType::Primary : ColorType::PrimaryLight);
    ImVec4 secondaryColor = Themes::GetColor(isDarkTheme ? ColorType::Secondary : ColorType::SecondaryLight);
    ImVec4 accentColor = Themes::GetColor(isDarkTheme ? ColorType::Accent : ColorType::AccentLight);
    ImVec4 errorColor = Themes::GetColor(ColorType::Error);
    ImVec4 warningColor = Themes::GetColor(ColorType::Warning);
    ImVec4 successColor = isDarkTheme ? ImVec4(0.0f, 0.8f, 0.0f, 1.0f) : ImVec4(0.0f, 0.6f, 0.0f, 1.0f);
    ImVec4 darkColor = isDarkTheme ? ImVec4(0.90f, 0.80f, 0.10f, 1.0f) : ImVec4(0.85f, 0.65f, 0.05f, 1.0f);
    ImVec4 titlesColor = isDarkTheme ? ImVec4(0.90f, 0.80f, 0.90f, 1.0f) : ImVec4(0.20f, 0.0f, 0.10f, 1.0f);
    ImVec4 textColor = isDarkTheme ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : ImVec4(0.0f, 0.0f, 0.0f, 1.0f);

    auto linChannels = device->GetLinChannels();
    auto canChannels = device->GetCanChannels();
    auto Channels = (device->GetType() == "CAN") ? canChannels : linChannels;

    ImGui::SetWindowFontScale(2.8f);

    if (selectedCaptureModuleIndex != -1) {
        ImGui::TextColored(darkColor, ("Capture Module Controller - Device " + std::to_string(selectedCaptureModuleIndex) + " (" + device->GetType() + ")").c_str());
    }
    else {
        ImGui::TextColored(darkColor, "Capture Module Controller");
    }

    ImGui::Separator();
    ImGui::SetWindowFontScale(1.5f);

    // Header
    ImVec2 rectSize = ImVec2(ImGui::GetContentRegionAvail().x, 50);
    ImVec2 rectPos = ImGui::GetCursorScreenPos();
    ImDrawList* drawList = ImGui::GetWindowDrawList();

    drawList->AddRectFilled(rectPos, ImVec2(rectPos.x + rectSize.x, rectPos.y + rectSize.y), ImGui::ColorConvertFloat4ToU32(primaryColor));
    drawList->AddRect(rectPos, ImVec2(rectPos.x + rectSize.x, rectPos.y + rectSize.y), ImGui::ColorConvertFloat4ToU32(accentColor));

    ImVec2 textSize = ImGui::CalcTextSize("Capture Module");
    ImVec2 textPos = ImVec2(rectPos.x + (rectSize.x - textSize.x) / 2, rectPos.y + (rectSize.y - textSize.y) / 2);
    drawList->AddText(textPos, ImGui::ColorConvertFloat4ToU32(ImVec4(0.95f, 0.96f, 0.98f, 1.0f)), "Capture Module");
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + rectSize.y + 10);

    std::string text = " (" + device->GetType() + ") Channels";
    ImGui::TextColored(darkColor, "%s", text.c_str());
    ImGui::Separator();
    ImGui::TextColored(textColor, "Channel Controls:");
    ImGui::Spacing();

    float buttonWidth = (ImGui::GetContentRegionAvail().x - (ImGui::GetStyle().ItemSpacing.x * (Channels.size() - 1))) / Channels.size();

    for (size_t i = 0; i < Channels.size(); ++i) {
        const auto& channel = Channels[i];
        bool isChannelZero = (channel == "0");

        std::string buttonId = channel + "##" + std::to_string(i);
        ImGui::PushID(buttonId.c_str());

        ImVec4 buttonColor = isChannelZero
            ? ImVec4(0.3f, 0.3f, 0.3f, 1.0f)
            : ImVec4(0.3f, 0.5f, 0.8f, 1.0f);

        ImGui::PushStyleColor(ImGuiCol_Button, buttonColor);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(buttonColor.x + 0.1f, buttonColor.y + 0.1f, buttonColor.z + 0.1f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(buttonColor.x - 0.1f, buttonColor.y - 0.1f, buttonColor.z - 0.1f, 1.0f));

        if (isChannelZero) {
            ImGui::BeginDisabled();
        }

        if (ImGui::Button(channel.c_str(), ImVec2(buttonWidth, 40))) {
            ImGui::OpenPopup("Send Message");
        }

        if (isChannelZero) {
            ImGui::EndDisabled();
        }

        if (!isChannelZero) {
            RenderSendMessagePopup(device, isDarkTheme, channel.c_str());
        }

        ImGui::PopStyleColor(3);

        if (ImGui::IsItemHovered()) {
            ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
            ImGui::BeginTooltip();
            ImGui::Text("Channel %s Status:", channel.c_str());
            ImGui::Text("Active: %s", isChannelZero ? "No" : "Yes");
            ImGui::Text("Messages: %d", isChannelZero ? 0 : 42);
            ImGui::Text("Errors: 0");
            ImGui::EndTooltip();
            ImGui::PopStyleColor(2);
        }

        ImGui::PopID();
        ImGui::SameLine();
    }

    ImGui::NewLine();
    ImGui::Separator();
    ImGui::Spacing();

    ImGui::Columns(2, "LINMainColumns", false);

    ImGui::BeginChild("LeftColumn", ImVec2(0, 0), true);

    // LOGS SECTION
    ImGui::BeginChild("LogsSection", ImVec2(0, 200), true);
    ImGui::Separator();
    ImGui::SetWindowFontScale(1.9f);
    ImGui::TextColored(titlesColor, "System Logs:");

    static char logFilter[256] = "";
    static bool needFilterUpdate = true;
    static std::vector<std::pair<std::string, ImVec4>> filteredLogs;

    ImGui::SetWindowFontScale(1.25f);
    ImGui::TextColored(textColor, "Filter Log Messages");

    ImGui::SetWindowFontScale(1.2f);
    ImGui::PushStyleColor(ImGuiCol_FrameBg, primaryColor);
    ImGui::PushStyleColor(ImGuiCol_Text, textColor);
    if (ImGui::InputTextWithHint("##FilterLogs", "Search logs...", logFilter, IM_ARRAYSIZE(logFilter))) {
        needFilterUpdate = true;
    }

    if (logFilter[0] != '\0') {
        ImGui::SameLine();
        if (ImGui::SmallButton("X")) {
            logFilter[0] = '\0';
            needFilterUpdate = true;
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Clear filter");
    }
    ImGui::PopStyleColor(2);

    ImGui::BeginChild("LogScrollingRegion", ImVec2(0, ImGui::GetContentRegionAvail().y), false, ImGuiWindowFlags_HorizontalScrollbar);

    if (logFilter[0] != '\0') {
        if (needFilterUpdate) {
            filteredLogs.clear();
            std::string filterLower = logFilter;
            std::transform(filterLower.begin(), filterLower.end(), filterLower.begin(), ::tolower);

            const auto& allLogs = Logging::getLogs();
            for (const auto& log : allLogs) {
                std::string logLower = log.first;
                std::transform(logLower.begin(), logLower.end(), logLower.begin(), ::tolower);

                if (logLower.find(filterLower) != std::string::npos) {
                    filteredLogs.push_back(log);
                }
            }
            needFilterUpdate = false;
        }

        for (const auto& log : filteredLogs) {
            ImGui::PushStyleColor(ImGuiCol_Text, log.second);
            ImGui::TextWrapped("%s", log.first.c_str());
            ImGui::PopStyleColor();
        }

        if (!needFilterUpdate && ImGui::GetScrollY() >= ImGui::GetScrollMaxY()) {
            ImGui::SetScrollHereY(1.0f);
        }
    }
    else {
        Logging::renderLogArea();
    }
    ImGui::EndChild();

    ImGui::EndChild();

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Spacing();

    // MESSAGES SECTION
    ImGui::BeginChild("MessagesSection", ImVec2(0, 0), true);
    ImGui::TextColored(textColor, "Received Messages:");
    ImGui::Separator();

    if (ImGui::BeginTable("Messages", 5, ImGuiTableFlags_ScrollY | ImGuiTableFlags_RowBg |
        ImGuiTableFlags_Borders | ImGuiTableFlags_Resizable,
        ImVec2(0, ImGui::GetContentRegionAvail().y - ImGui::GetFrameHeightWithSpacing()))) {
        ImGui::TableSetupColumn("Timestamp", ImGuiTableColumnFlags_WidthFixed, 100.0f);
        ImGui::TableSetupColumn("Field ID", ImGuiTableColumnFlags_WidthFixed, 80.0f);
        ImGui::TableSetupColumn("Length", ImGuiTableColumnFlags_WidthFixed, 60.0f);
        ImGui::TableSetupColumn("Data", ImGuiTableColumnFlags_WidthStretch);
        ImGui::TableSetupColumn("Flags", ImGuiTableColumnFlags_WidthFixed, 80.0f);
        ImGui::TableHeadersRow();
        if (device->isCapturing) {
            RenderMessagesTable(CaptureModuleDevice::frame, isDarkTheme);
        }
        ImGui::EndTable();
    }

    ImGui::EndChild();
    ImGui::EndChild();

    ImGui::NextColumn();

    ImGui::TextColored(titlesColor, "Data Export");
    ImGui::Separator();

    if (ImGui::Button("Export Captured Data", ImVec2(-1, 30))) {
        ExportCaptureData(*device, directoryPath, selectedCaptureModuleIndex);
    }
    if (ImGui::IsItemHovered()) {
        ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
        ImGui::SetTooltip("Export all captured message data to a CSV file");
        ImGui::PopStyleColor(2);
    }

    ImGui::TextColored(titlesColor, "Capture Control");
    ImGui::Separator();

    ImGui::BeginChild("MessageOperations", ImVec2(0, 0), true);
    {
        ImGui::TextColored(textColor, "Message Operations:");
        ImGui::Spacing();

        if (ImGui::Button("Send Message", ImVec2(-1, 40))) {
            ImGui::OpenPopup("Send Message");
        }
        RenderSendMessagePopup(device, isDarkTheme, "");

        ImGui::TextColored(titlesColor, "Capture Control");
        ImGui::Separator();

        if (ImGui::Button(device->isCapturing ? "Stop Capture Session" : "Start Capture Session", ImVec2(-1, 40))) {
            device->isCapturing = !device->isCapturing;

            if (device->isCapturing) {
                Logging::info("Capture session started");
            }
            else {
                Logging::info("Capture session terminated");
            }
        }
    }
    ImGui::EndChild();

    ImGui::Columns(1);
}

void LegacyGUI::RenderSendMessagePopup(std::shared_ptr<CaptureModuleDevice> device, bool& isDarkTheme, std::string channel) {
    static char channelBuffer[256] = "";
    static uint32_t messageId = 0;
    static bool invalidId = false;
    static unsigned char canData[8] = { 0 };
    static bool invalidData[8] = { false };
    static bool anyInvalidData = false;
    static int dataLength = 8;
    static bool isExtendedId = false;
    static bool firstTimeOpen = true;

    auto linChannels = device->GetLinChannels();
    auto canChannels = device->GetCanChannels();
    auto Channels = (device->GetType() == "CAN") ? canChannels : linChannels;
    ImVec4 textColor = isDarkTheme ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
    ImGui::PushStyleColor(ImGuiCol_Text, textColor);

    if (ImGui::BeginPopupModal("Send Message", NULL, ImGuiWindowFlags_AlwaysAutoResize)) {
        // Set the default channel if this is the first time opening the popup
        if (firstTimeOpen) {
            if (!channel.empty()) {
                strncpy_s(channelBuffer, channel.c_str(), sizeof(channelBuffer));
                channelBuffer[sizeof(channelBuffer) - 1] = '\0';
            }
            firstTimeOpen = false;
        }

        // Channel selection dropdown with all available channels (except channel 0)
        if (ImGui::BeginCombo("##ChannelSelect", channelBuffer[0] ? channelBuffer : "Select Channel")) {
            for (const auto& ch : Channels) {
                if (ch == "0" || ch.empty()) continue;

                bool isSelected = (strcmp(channelBuffer, ch.c_str()) == 0);
                if (ImGui::Selectable(ch.c_str(), isSelected)) {
                    strncpy_s(channelBuffer, ch.c_str(), sizeof(channelBuffer));
                    channelBuffer[sizeof(channelBuffer) - 1] = '\0';
                }
                if (isSelected) {
                    ImGui::SetItemDefaultFocus();
                }
            }
            ImGui::EndCombo();
        }

        // Rest of the popup content remains the same...
        ImGui::TextColored(textColor, "Message ID Type:");
        if (ImGui::RadioButton("Standard (11-bit)", !isExtendedId)) {
            isExtendedId = false;
        }
        ImGui::SameLine();
        if (ImGui::RadioButton("Extended (29-bit)", isExtendedId)) {
            isExtendedId = true;
        }

        ImGui::TextColored(textColor, "Message ID:");
        if (ImGui::InputScalar("##MessageId", ImGuiDataType_U32, &messageId, NULL, NULL, "%X",
            ImGuiInputTextFlags_CharsHexadecimal | ImGuiInputTextFlags_CharsUppercase)) {
            invalidId = isExtendedId ? (messageId > 0x1FFFFFFF) : (messageId > 0x7FF);
        }
        if (invalidId) {
            ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f),
                "Invalid ID for %s frame", isExtendedId ? "extended" : "standard");
        }

        ImGui::TextColored(textColor, "Data Length (1-8 bytes):");
        ImGui::InputInt("##DataLength", &dataLength);
        dataLength = std::clamp(dataLength, 1, 8);
        ImGui::Separator();

        ImGui::TextColored(textColor, "Data Payload (hex values 00-FF):");
        static char hexInput[256] = { 0 };

        if (!ImGui::IsItemActive()) {
            for (int i = 0; i < dataLength; ++i) {
                snprintf(&hexInput[i * 2], 3, "%02X", canData[i]);
            }
            hexInput[dataLength * 2] = '\0';
        }

        bool isEdited = ImGui::InputText("##hexInput", hexInput, sizeof(hexInput),
            ImGuiInputTextFlags_CharsHexadecimal | ImGuiInputTextFlags_CharsUppercase);

        anyInvalidData = false;
        bool tooMuchInput = false;

        if (isEdited) {
            int inputLen = static_cast<int>(strlen(hexInput));

            if (inputLen > dataLength * 2) {
                tooMuchInput = true;
                inputLen = dataLength * 2;
            }

            for (int i = 0; i < dataLength; ++i) {
                if (i * 2 + 1 < inputLen) {
                    char byteStr[3] = { hexInput[i * 2], hexInput[i * 2 + 1], '\0' };
                    unsigned int byteVal;
                    if (sscanf_s(byteStr, "%02X", &byteVal) == 1) {
                        canData[i] = static_cast<unsigned char>(byteVal);
                        invalidData[i] = false;
                    }
                    else {
                        invalidData[i] = true;
                        anyInvalidData = true;
                    }
                }
                else {
                    invalidData[i] = true;
                    anyInvalidData = true;
                }
            }
        }

        if (anyInvalidData) {
            ImGui::SameLine();
            ImGui::TextColored(ImVec4(1, 0, 0, 1), "Invalid input!");
        }
        else if (tooMuchInput) {
            ImGui::SameLine();
            ImGui::TextColored(ImVec4(1, 0.5f, 0, 1), "Input truncated to %d bytes.", dataLength);
        }

        ImGui::Separator();

        bool canSend = !invalidId && !anyInvalidData && (channelBuffer[0] != '\0');
        if (!canSend) {
            ImGui::BeginDisabled();
        }
        ImGuiIO& io = ImGui::GetIO();

        bool enterPressed = ImGui::IsKeyPressed(ImGuiKey_Enter) || ImGui::IsKeyPressed(ImGuiKey_KeypadEnter);

        if (ImGui::Button("Send", ImVec2(120, 0)) || enterPressed) {
            int channelNum = 0;
            try {
                channelNum = static_cast<TE::Base::u32>(std::stoul(channelBuffer));
            }
            catch (...) {
                Logging::error("Invalid channel format: %s", channelBuffer);
                ImGui::CloseCurrentPopup();
                ImGui::EndPopup();
                return;
            }

            std::vector<TE::Base::u8> dataVector(canData, canData + dataLength);
            
            if (device->GetType() == "CAN") {
                CaptureModuleDevice::sendCanMessage(static_cast<TE::Base::u16>(device->deviceId), channelNum, messageId, isExtendedId, dataLength, dataVector);
            }
            else if (device->GetType() == "LIN") {
                CaptureModuleDevice::sendLinMessage(static_cast<TE::Base::u16>(device->deviceId), channelNum, messageId, dataVector);
            }

            memset(canData, 0, sizeof(canData));
            messageId = 0;
            invalidId = false;
            anyInvalidData = false;
            memset(invalidData, 0, sizeof(invalidData));
            ImGui::CloseCurrentPopup();
            firstTimeOpen = true; // Reset for next time
        }

        if (!canSend) {
            ImGui::EndDisabled();
            if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) {
                ImGui::SetTooltip("Please select a channel and fix validation errors");
            }
        }

        ImGui::SameLine();
        if (ImGui::Button("Cancel", ImVec2(120, 0))) {
            invalidId = false;
            anyInvalidData = false;
            memset(invalidData, 0, sizeof(invalidData));
            ImGui::CloseCurrentPopup();
            firstTimeOpen = true; // Reset for next time
        }

        ImGui::EndPopup();
    }
    ImGui::PopStyleColor();
}
void LegacyGUI::RenderMessagesTable(const std::vector<Message>& msgs, bool& isDarkTheme) {
    ImVec4 textColor = isDarkTheme ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
    std::unordered_map<std::string, const Message*> latestMessages;

    for (const auto& msg : msgs) {
        std::lock_guard<std::mutex> lock(frameMutex);
        auto it = latestMessages.find(msg.fieldId);
        if (it == latestMessages.end()) {
            latestMessages[msg.fieldId] = &msg;
        }
        else {
            if (std::stoull(msg.timestamp) > std::stoull(it->second->timestamp)) {
                latestMessages[msg.fieldId] = &msg;
            }
        }
    }

    for (const auto& [fieldId, msgPtr] : latestMessages) {
        const auto& msg = *msgPtr;

        ImGui::TableNextRow();

        ImGui::TableSetColumnIndex(0);
        ImGui::TextColored(textColor, "%s", msg.timestamp.c_str());

        ImGui::TableSetColumnIndex(1);
        ImGui::TextColored(textColor, "%s", msg.fieldId.c_str());

        ImGui::TableSetColumnIndex(2);
        ImGui::TextColored(textColor, "%d", msg.dataLength);

        ImGui::TableSetColumnIndex(3);
        ImGui::TextColored(textColor, "%s", msg.data.c_str());

        ImGui::TableSetColumnIndex(4);
        if (msg.dataFlags == "OK") {
            ImGui::TextColored(ImVec4(0.0f, 0.70f, 0.0f, 1.0f), "%s", msg.dataFlags.c_str());
        }
        else if (msg.dataFlags == "Error") {
            ImGui::TextColored(ImVec4(0.70f, 0.0f, 0.0f, 1.0f), "%s", msg.dataFlags.c_str());
        }
        else {
            ImGui::TextColored(ImVec4(0.70f, 0.70f, 0.0f, 1.0f), "%s", msg.dataFlags.c_str());
        }
    }
}

void LegacyGUI::ExportCaptureData(CaptureModuleDevice& device, const std::string& directoryPath, int selectedCaptureModuleIndex) {
    if (directoryPath.empty()) {
        Logging::error("Export failed: No save directory specified");
        return;
    }

    std::string filePath = directoryPath + "/capture_data_"+".csv";
    std::ofstream file(filePath);

    if (!file.is_open()) {
        Logging::error("Export failed: Unable to create file at ");
        return;
    }

    file << "Timestamp,Field ID,Data Length,Data,Data Flags\n";

    {
        std::lock_guard<std::mutex> lock(dataMutex);
        for (const auto& msg : CaptureModuleDevice::frame) {
            file << msg.timestamp << ","
                << msg.fieldId << ","
                << msg.dataLength << ","
                << msg.data << ","
                << msg.dataFlags << "\n";
        }
    }

    file.close();
    Logging::info("Capture data successfully exported to:", filePath);
}

std::string CaptureModuleDevice::getDeviceIP() const {
    return deviceIp;
}