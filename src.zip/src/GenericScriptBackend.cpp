
#include "GenericScriptBackend.h"
#include "DeviceFactory.h"

static std::mutex canframeMutex;

static std::vector<std::string> parseParameters(const std::string& params)
{
    std::vector<std::string> result;
    std::string current;
    bool inQuotes = false;

    for (char c : params) {
        if (c == '"') {
            inQuotes = !inQuotes;
        }
        else if (c == ',' && !inQuotes) {
            // Trim whitespace
            auto start = current.find_first_not_of(" \t");
            auto end = current.find_last_not_of(" \t");
            if (start != std::string::npos && end != std::string::npos) {
                result.push_back(current.substr(start, end - start + 1));
            }
            else {
                result.push_back("");
            }
            current.clear();
        }
        else {
            current += c;
        }
    }

    // Add last parameter
    if (!current.empty()) {
        auto start = current.find_first_not_of(" \t");
        auto end = current.find_last_not_of(" \t");
        if (start != std::string::npos && end != std::string::npos) {
            result.push_back(current.substr(start, end - start + 1));
        }
        else {
            result.push_back("");
        }
    }

    return result;
}

void GenericScriptBackend::executeFunction(const std::string& funcName, const std::string& params)
{
    // Parse parameters (comma-separated values)
    std::vector<std::string> parsedParams = parseParameters(params);

    try {
        // Execute the appropriate function
        if (funcName == "OpenLoad" || funcName == "ShortVbat" || funcName == "ShortGND") {
            // These functions need exactly 3 parameters
            if (parsedParams.size() < 3) {
                Logging::error("Not enough parameters for %s (needs 3)", funcName.c_str());
                return;
            }

            Base::u8 btsBoardNumber = static_cast<Base::u8>(std::stoul(parsedParams[0]));
            Base::u8 channelNumber = static_cast<Base::u8>(std::stoul(parsedParams[1]));
            bool enable = (parsedParams[2] == "true" || parsedParams[2] == "1");

            if (funcName == "OpenLoad") {
                DeviceFactory::iosInterface->openCircuit(btsBoardNumber, channelNumber, enable);
            }
            else if (funcName == "ShortVbat") {
                DeviceFactory::iosInterface->shortVBat(btsBoardNumber, channelNumber, enable);
            }
            else if (funcName == "ShortGND") {
                DeviceFactory::iosInterface->shortGnd(btsBoardNumber, channelNumber, enable);
            }
        }
        else if (funcName == "PWMGeneration") {
            // Needs 5 parameters
            if (parsedParams.size() < 5) {
                Logging::error("Not enough parameters for PWMGeneration (needs 5)");
                return;
            }

            Base::u8 btsBoardNumber = static_cast<Base::u8>(std::stoul(parsedParams[0]));
            Base::u8 channelNumber = static_cast<Base::u8>(std::stoul(parsedParams[1]));
            bool enable = (parsedParams[2] == "true" || parsedParams[2] == "1");
            Base::u16 onTime = static_cast<Base::u16>(std::stoul(parsedParams[3]));
            Base::u16 offTime = static_cast<Base::u16>(std::stoul(parsedParams[4]));

            DeviceFactory::iosInterface->generatePWM(btsBoardNumber, channelNumber, enable, onTime, offTime);
        }
        else if (funcName == "VoltageMeasurement") {
            Base::u8 btsBoardNumber = static_cast<Base::u8>(std::stoul(parsedParams[0]));
            Base::u8 channelNumber = static_cast<Base::u8>(std::stoul(parsedParams[1]));
            Logging::info("Voltage on Board {}, channel {} = {}", btsBoardNumber, channelNumber,
                DeviceFactory::deviceMap[btsBoardNumber]->measureVoltage(channelNumber));
        }
        else if (funcName == "CurrentMeasurementLowCurrent") {
            Base::u8 btsBoardNumber = static_cast<Base::u8>(std::stoul(parsedParams[0]));
            Base::u8 channelNumber = static_cast<Base::u8>(std::stoul(parsedParams[1]));
            Logging::info("Current on Board {}, channel {} = {}", btsBoardNumber, channelNumber,
                DeviceFactory::deviceMap[btsBoardNumber]->measureCurrent(channelNumber));
        }
        else if (funcName == "GetLastReceivedIOMsg") {
            Base::u8 btsBoardNumber = static_cast<Base::u8>(std::stoul(parsedParams[0]));
            Base::u8 channelNumber = static_cast<Base::u8>(std::stoul(parsedParams[1]));
            Logging::info("Board {}, channel {} :: Current = {} :: voltage = {}",
                btsBoardNumber, channelNumber,
                DeviceFactory::deviceMap[btsBoardNumber]->measureCurrent(channelNumber),
                DeviceFactory::deviceMap[btsBoardNumber]->measureVoltage(channelNumber));
        }
        else if (funcName == "SendCANFrame") {
            // Needs at least 6 parameters
            if (parsedParams.size() < 6) {
                Logging::error("Not enough parameters for SendCANFrame (needs 6)");
                return;
            }

            Base::u8 boardNumber = static_cast<Base::u8>(std::stoul(parsedParams[0]));
            int channelNumber = std::stoi(parsedParams[1]);
            bool isExtendedId = (parsedParams[2] == "true" || parsedParams[2] == "1");
            Base::u32 msgId = static_cast<Base::u32>(std::stoul(parsedParams[3]));
            Base::u8 length = static_cast<Base::u8>(std::stoul(parsedParams[4]));
            std::string strData = parsedParams[5];

            // Convert string to byte vector
            std::vector<Base::u8> data;
            std::stringstream ss(strData);
            std::string byteStr;

           // Ensure the string has even length (each byte is 2 hex digits)

try {
    for (size_t i = 0; i < strData.length(); i += 2) {
        std::string byteStr = strData.substr(i, 2);
        Base::u8 byte = static_cast<Base::u8>(std::stoul(byteStr, nullptr, 16));
        data.push_back(byte);
    }
}
catch (...) {
    std::cerr << "Invalid byte in data string" << std::endl;
    return;
}

// Verify length matches the actual data size
if (length != data.size()) {
    std::cerr << "Warning: Specified length (" << static_cast<int>(length) 
              << ") doesn't match actual data size (" << data.size() << ")" << std::endl;
    // You might want to update length here or handle the mismatch differently
    length = static_cast<Base::u8>(data.size());
}
            DeviceFactory::_tecmp_driver_->sendCanMessage(
                boardNumber,
                channelNumber,
                msgId,
                isExtendedId ? TE::Driver::CanIDType::EXTENDED_ID
                : TE::Driver::CanIDType::STANDARD_ID,
                TE::Driver::CanFrameType::DATA_FRAME,
                length,
                data,
                0
            );           

        }
        else if (funcName == "SendLINFrame") {
            // Needs at least 4 parameters
            if (parsedParams.size() < 4) {
                Logging::error("Not enough parameters for SendLINFrame (needs at least 4)");
                return;
            }

            int boardNumber = std::stoi(parsedParams[0]);
            int channelNumber = std::stoi(parsedParams[1]);
            Base::u8 msgId = static_cast<Base::u8>(std::stoul(parsedParams[2]));
            std::string strData = parsedParams[3];

            // Convert string to byte vector
            std::vector<Base::u8> data;
            std::stringstream ss(strData);
            std::string byteStr;

            if (strData.length() % 2 != 0) {
    std::cerr << "Invalid data string - odd number of hex digits" << std::endl;
    return;
}

try {
    for (size_t i = 0; i < strData.length(); i += 2) {
        std::string byteStr = strData.substr(i, 2);
        Base::u8 byte = static_cast<Base::u8>(std::stoul(byteStr, nullptr, 16));
        data.push_back(byte);
    }
}
catch (...) {
    std::cerr << "Invalid byte in data string" << std::endl;
    return;
}



            DeviceFactory::_tecmp_driver_->sendLinMessage(
                boardNumber,
                channelNumber,
                msgId,
                data
            );
        }
        else if ((funcName == "GetLastReceivedCANMsg") || (funcName == "GetLastReceivedLINMsg")) {
            // Ensure parsedParams has at least 1 argument (fieldId)
            if (parsedParams.empty()) {
                Logging::error("Missing fieldId parameter in {}", funcName);
            }

            std::string targetFieldId = parsedParams[0];
            Message lastMsg;
            bool found = false;

            // Lock for thread safety
            std::lock_guard<std::mutex> lock(canframeMutex);

            // Find the latest message with matching fieldId
            for (const auto& msg : CaptureModuleDevice::frame) {
                if (msg.fieldId == targetFieldId) {
                    lastMsg = msg;
                    found = true;
                }
            }

            if (!found) {
                Logging::warn("No message found with fieldId {}", targetFieldId);
                Logging::info("There's no captured data on this device for fieldId: {}", targetFieldId);
            }
            else {
                // Only log the message details if we found one
                Logging::info(
                    "Last received CAN message - Timestamp: {}, FieldID: {}, Data: {}, Flags: {}",
                    lastMsg.timestamp.c_str(),
                    lastMsg.fieldId.c_str(),
                    lastMsg.data.c_str(),
                    lastMsg.dataFlags.c_str()
                );
            }
        }
        else if (funcName == "Sleep") {
            if (parsedParams.empty()) {
                Logging::error("Sleep requires a duration parameter");
                return;
            }

            try {
                unsigned long sleepTime = std::stoul(parsedParams[0]);
                Logging::info("Sleeping for {}ms", sleepTime);
                std::this_thread::sleep_for(std::chrono::milliseconds(sleepTime));
                Logging::info("Finished sleeping");
            }
            catch (const std::exception& e) {
                Logging::error("Invalid sleep duration: {}", e.what());
            }
        }
        else {
            Logging::error("Unknown function: {}", funcName.c_str());
            return;
        }

        Logging::info("Executed {} with parameters: {}",
            funcName.c_str(),
            params.c_str());
    }
    catch (const std::invalid_argument& e) {
        Logging::error("Invalid number format in parameters for {}: {}",
            funcName.c_str(), e.what());
    }
    catch (const std::out_of_range& e) {
        Logging::error("Number out of range in parameters for {}: {}",
            funcName.c_str(), e.what());
    }
    catch (const std::exception& e) {
        Logging::error("Failed to execute {}: {}",
            funcName.c_str(), e.what());
    }
}