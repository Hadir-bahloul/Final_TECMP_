#include "../include/BTSRevoGUI.h"
#include "../include/Logging.h"
#include "../include/GUI.h"
#include "../include/Themes.h"
#include <algorithm>
#include <iostream>
#include <random>
#include <chrono>
#include <vector>
#include <string>
#include <map>
#include "implot.h"
#include <yaml-cpp/yaml.h>
#include "BTSRevoGUI.h"
#include <stdexcept>
#include <fstream>
#include <filesystem>
#include <windows.h>
#include <commdlg.h>

namespace fs = std::filesystem;
static std::string currentSavePath = "";
static bool showFileDialog = false;
static bool exportRequested = false;
static char fileNameBuffer[256] = "BTSRevo_Config.yaml";
static std::vector<std::string> directoryEntries;
static std::string currentDirectory = fs::current_path().string();
ImVec4 activeChannelColor = ImVec4(0.2f, 0.607f, 1.0f, 1.0f);
ImVec4 inactiveChannelColor =  ImVec4(0.267f, 0.357f, 0.549f, 1.0f);
void BTSRevoGUI::ExportChannelMeasurements(BTSRevoDevice &device, const std::string &directoryPath)
{
    std::string filePath = directoryPath + "/channel_measurements.txt";
    std::ofstream measurementFile(filePath);
    if (!measurementFile.is_open())
    {
        std::cerr << "Failed to open measurement file for writing: " << filePath << std::endl;
        return;
    }
    measurementFile << "Channel ID, Voltage (V), Current (A)\n";
    for (int i = 1; i < TOTAL_CHANNELS+1; i++)
    {
        if (device.channelMeasurements[i].isActive)
        {
            measurementFile << i  << ", "
                            << device.channelMeasurements[i].voltage << ", "
                            << device.channelMeasurements[i].current << "\n";
        }
    }
    measurementFile.close();
    Logging::info("Channel measurements exported to {}", filePath);
}
static void ApplyBTSRevoConfig(BTSRevoDevice &device, const std::string &yamlContent)
{
    try
    {
        YAML::Node config = YAML::Load(yamlContent);

        // Check if the config has BTS-Revo section
        if (!config["BTS-Revo"])
        {
            Logging::error("Invalid configuration file - missing BTS-Revo section");
            return;
        }

        YAML::Node btsRevoNode = config["BTS-Revo"];

        // Apply Daggers configuration
        if (btsRevoNode["Daggers"])
        {
            // Reset all daggers first
            for (int i = 0; i < NUM_DAGGERS; i++)
            {
                device.hasDagger[i] = false;
            }

            // Set active daggers from config
            for (const auto &dagger : btsRevoNode["Daggers"])
            {
                int daggerNum = dagger.as<int>() - 1; // Convert to 0-based index
                if (daggerNum >= 0 && daggerNum < NUM_DAGGERS)
                {
                    device.hasDagger[daggerNum] = true;
                }
            }
        }

        // Apply Blitzes configuration
        if (btsRevoNode["Blitzes"])
        {
            // Reset all blitzes first
            for (int i = 0; i < NUM_BLITZES; i++)
            {
                device.hasBlitz[i] = false;
            }

            // Set active blitzes from config
            for (const auto &blitz : btsRevoNode["Blitzes"])
            {
                int blitzNum = blitz.as<int>() - 1; // Convert to 0-based index
                if (blitzNum >= 0 && blitzNum < NUM_BLITZES)
                {
                    device.hasBlitz[blitzNum] = true;
                }
            }
        }

        // Apply Active Channels configuration (if present)
        if (btsRevoNode["ActiveChannels"])
        {
            // Reset all channels first
            for (int i = 0; i < TOTAL_CHANNELS; i++)
            {
                device.channelMeasurements[i].isActive = false;
            }

            // Set active channels from config
            for (const auto &channel : btsRevoNode["ActiveChannels"])
            {
                int channelNum = channel.as<int>() - 1; // Convert to 0-based index
                if (channelNum >= 0 && channelNum < TOTAL_CHANNELS)
                {
                    device.channelMeasurements[channelNum].isActive = true;
                }
            }
        }

        // Update channel activation based on daggers/blitzes
        device.UpdateChannelActivation();

        Logging::info("BTS Revo configuration applied successfully");
    }
    catch (const YAML::Exception &e)
    {
        Logging::error("Error parsing YAML configuration: %s", e.what());
    }
    catch (const std::exception &e)
    {
        Logging::error("Error applying configuration: %s", e.what());
    }
}

static void RefreshDirectoryEntries()
{
    directoryEntries.clear();
    try
    {
        for (const auto &entry : fs::directory_iterator(currentDirectory))
        {
            directoryEntries.push_back(entry.path().filename().string());
        }
    }
    catch (...)
    {
        Logging::error("Could not read directory contents");
    }
}

static void RenderFileDialog()
{
    if (!showFileDialog)
        return;

    ImGui::OpenPopup("Save Configuration");
    if (ImGui::BeginPopupModal("Save Configuration", &showFileDialog, ImGuiWindowFlags_AlwaysAutoResize))
    {
        // Current directory path
        ImGui::Text("Directory: %s", currentDirectory.c_str());
        ImGui::Separator();

        // Directory contents
        ImGui::BeginChild("DirectoryContents", ImVec2(400, 200), true);
        for (const auto &entry : directoryEntries)
        {
            if (ImGui::Selectable(entry.c_str()))
            {
                fs::path newPath = fs::path(currentDirectory) / entry;
                if (fs::is_directory(newPath))
                {
                    currentDirectory = newPath.string();
                    RefreshDirectoryEntries();
                }
            }
        }
        ImGui::EndChild();

        // File name input
        ImGui::InputText("File Name", fileNameBuffer, sizeof(fileNameBuffer));

        // Buttons
        if (ImGui::Button("Save"))
        {
            currentSavePath = (fs::path(currentDirectory) / fileNameBuffer).string();
            showFileDialog = false;
            ImGui::CloseCurrentPopup();
        }
        ImGui::SameLine();
        if (ImGui::Button("Cancel"))
        {
            showFileDialog = false;
            ImGui::CloseCurrentPopup();
        }

        ImGui::EndPopup();
    }
}

static void ExportBTSRevoConfig(const BTSRevoDevice &device, const std::string &defaultPath)
{
    if (exportRequested)
    {
        // Initialize OPENFILENAME structure
        OPENFILENAMEA ofn;
        char szFile[260] = {0};

        // Initialize the buffer with the default filename
        strncpy(szFile, ("BTSRevo_Device" + std::to_string(device.deviceId) + "_config.yaml").c_str(), sizeof(szFile));

        ZeroMemory(&ofn, sizeof(ofn));
        ofn.lStructSize = sizeof(ofn);
        ofn.hwndOwner = NULL;
        ofn.lpstrFile = szFile;
        ofn.nMaxFile = sizeof(szFile);
        ofn.lpstrFilter = "YAML Files (*.yaml)\0*.yaml\0All Files (*.*)\0*.*\0";
        ofn.nFilterIndex = 1;
        ofn.lpstrFileTitle = NULL;
        ofn.nMaxFileTitle = 0;
        ofn.lpstrInitialDir = defaultPath.empty() ? NULL : defaultPath.c_str();
        ofn.Flags = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

        // Set default extension
        ofn.lpstrDefExt = "yaml";

        // Show the Save dialog
        if (GetSaveFileNameA(&ofn) == TRUE)
        {
            currentSavePath = szFile;
            Logging::info("Selected file path: %s", currentSavePath.c_str());
        }
        else
        {
            // User cancelled the dialog
            currentSavePath.clear();
            Logging::info("Export cancelled by user");
        }

        exportRequested = false;
        return;
    }

    // Rest of your existing file saving logic
    if (!currentSavePath.empty())
    {
        try
        {
            YAML::Emitter out;
            out << YAML::BeginMap;
            out << YAML::Key << "BTS-Revo";
            out << YAML::Value << YAML::BeginMap;
            out << YAML::Key << "DeviceIndex" << YAML::Value << device.deviceId;

            // Save active daggers
            out << YAML::Key << "Daggers";
            out << YAML::Value << YAML::Flow << YAML::BeginSeq;
            for (int i = 0; i < NUM_DAGGERS; i++) {
                if (device.hasDagger[i]) {
                    out << (i + 1);
                }
            }
            out << YAML::EndSeq;

            // Save active blitzes
            out << YAML::Key << "Blitzes";
            out << YAML::Value << YAML::Flow << YAML::BeginSeq;
            for (int i = 0; i < NUM_BLITZES; i++) {
                if (device.hasBlitz[i]) {
                    out << (i + 1);
                }
            }
            out << YAML::EndSeq;

            out << YAML::EndMap;
            out << YAML::EndMap;

            std::ofstream fout(currentSavePath);
            fout << out.c_str();
            fout.close();

            Logging::info("Configuration saved to: %s", currentSavePath.c_str());
        }
        catch (const std::exception &e)
        {
            Logging::error("Failed to save configuration: %s", e.what());
        }
        currentSavePath.clear();
    }
}
std::map<int, std::string> BTSRevoGUI::mapHwChannelsToSignals(int boardId, const std::string &yamlContent) noexcept
{
        std::map<int, std::string> channelMap;

    // Initialize all channels 1-24 with "None"
    for (int i = 1; i <= TOTAL_CHANNELS; ++i)
    {
        channelMap[i] = "None";
    }

    try
    {
        // Check for empty content
        if (yamlContent.empty())
        {
            return channelMap;
        }

        YAML::Node config;
        try
        {
            config = YAML::Load(yamlContent);
        }
        catch (const YAML::Exception &e)
        {
            return channelMap;
        }

        // Safely check YAML structure
        if (!config.IsMap() || !config["BTS-Revo"] || !config["BTS-Revo"]["Boards"])
        {
            return channelMap;
        }

        YAML::Node boards = config["BTS-Revo"]["Boards"];
        if (!boards.IsMap())
        {
            return channelMap;
        }

        // Iterate through all boards
        for (const auto &boardPair : boards)
        {
            try
            {
                YAML::Node boardNode = boardPair.second;
                if (!boardNode.IsMap())
                    continue;

                // Check board ID
                if (boardNode["Id"] && boardNode["Id"].as<int>() == boardId)
                {
                    // Check IOs
                    if (boardNode["IOs"] && boardNode["IOs"].IsMap())
                    {
                        YAML::Node ios = boardNode["IOs"];

                        for (const auto &ioPair : ios)
                        {
                            try
                            {
                                std::string signalName = ioPair.first.as<std::string>();
                                YAML::Node ioData = ioPair.second;

                                if (ioData["HWChannel"])
                                {
                                    int hwChannel = ioData["HWChannel"].as<int>();
                                    if (hwChannel >= 1 && hwChannel <= 24)
                                    {
                                        channelMap[hwChannel] = signalName;
                                    }
                                }
                            }
                            catch (...)
                            {
                                // Skip this IO if there's any error
                                continue;
                            }
                        }
                    }
                    return channelMap; // Found our board, return now
                }
            }
            catch (...)
            {
                // Skip this board if there's any error
                continue;
            }
        }
    }
    catch (...)
    {
        // Catch-all for any unexpected errors
        return channelMap;
    }
    return channelMap;
}
void BTSRevoGUI::RenderDaggers(BTSRevoDevice &device, bool &isDarkTheme){

        for (int daggerIndex = 0; daggerIndex < NUM_DAGGERS; daggerIndex++)
        {

            if (device.hasDagger[daggerIndex])
            {
                ImGui::PushStyleColor(ImGuiCol_Button, activeChannelColor);
            }
            else
            {
                ImGui::PushStyleColor(ImGuiCol_Button, inactiveChannelColor);
            }
            float offsetX = 30.0f + (daggerIndex / 2) * 15.0f + (daggerIndex % 2) * 10.0f;
            ImGui::SetCursorPosX(ImGui::GetCursorPosX() + offsetX);
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.6f, 0.6f, 0.9f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.4f, 0.4f, 0.4f, 1.0f));
            if (ImGui::Button(("DAGGER " + std::to_string(daggerIndex + 1)).c_str(), ImVec2(100, 50)))
            {
                device.hasDagger[daggerIndex] = !device.hasDagger[daggerIndex];
                device.UpdateChannelActivation();
            }
            ImGui::PopStyleColor(3);
            if (daggerIndex < NUM_DAGGERS - 1)
                ImGui::SameLine();
        }

        ImGui::NewLine();
        ImGui::Separator();
}
void BTSRevoGUI::RenderBlitzes(BTSRevoDevice &device, bool &isDarkTheme){
        for (int blitzIndex = 0; blitzIndex < NUM_BLITZES; blitzIndex++)
        {
            if (device.hasBlitz[blitzIndex])
            {
                ImGui::PushStyleColor(ImGuiCol_Button, activeChannelColor);
            }
            else
            {
                ImGui::PushStyleColor(ImGuiCol_Button, inactiveChannelColor);
            }
            float offsetX = 70.0f + blitzIndex * (45.0f);
            ImGui::SetCursorPosX(ImGui::GetCursorPosX() + offsetX + 20);
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.6f, 0.6f, 0.9f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.4f, 0.4f, 0.4f, 1.0f));
            if (ImGui::Button(("BLITZ " + std::to_string(blitzIndex + 1)).c_str(), ImVec2(155, 50)))
            {
                device.hasBlitz[blitzIndex] = !device.hasBlitz[blitzIndex];
                device.UpdateChannelActivation();
            }
            ImGui::PopStyleColor(3);
            if (blitzIndex < NUM_BLITZES - 1)
                ImGui::SameLine();
        }

}
void BTSRevoGUI::RenderChannels(BTSRevoDevice &device, bool &isDarkTheme){

    ImVec4 textColor = isDarkTheme ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
    ImVec4 bgColor = isDarkTheme ? ImVec4(0.2f, 0.2f, 0.4f, 0.90f) : ImVec4(0.8f, 0.8f, 0.8f, 0.90f);
    
 

        // Add filter input
        static char filterText[128] = "";
        ImGui::InputTextWithHint("##Filter", "Filter signals...", filterText, IM_ARRAYSIZE(filterText));

        // Display channel numbers (unchanged)
        for (int blitzIndex = 0; blitzIndex < NUM_BLITZES; blitzIndex++)
        {
            for (int i = blitzIndex * CHANNELS_PER_BLITZ; i < (blitzIndex + 1) * CHANNELS_PER_BLITZ; i++)
            {
                ImGui::PushID(i);
                if (device.channelMeasurements[i].isActive)
                {
                    ImGui::PushStyleColor(ImGuiCol_Button, activeChannelColor);
                    
                }
                else
                {
                    ImGui::PushStyleColor(ImGuiCol_Button, inactiveChannelColor);
                }

                if (ImGui::Button(std::to_string(i + 1).c_str(), ImVec2(30, 30)))
                {
                    device.channelMeasurements[i].isActive = !device.channelMeasurements[i].isActive;
                    
                    BTSRevoDevice::wasUserActivated[i]=!BTSRevoDevice::wasUserActivated[i];
                    Logging::info("was user activated de {}: {}",i, BTSRevoDevice::wasUserActivated[i]);
                    device.defaultChannelId = i + 1;
                }
                ImGui::PopStyleColor();
                ImGui::PopID();

                if (i < (blitzIndex + 1) * CHANNELS_PER_BLITZ - 1)
                {
                    ImGui::SameLine();
                }
            }

            if (blitzIndex < NUM_BLITZES - 1)
            {
                ImGui::SameLine();
                ImGui::TextColored(textColor, " | ");
                ImGui::SameLine();
            }
        }
        // Signal names lines -4 lines Below channel numbers
        ImGui::Spacing();

        // Only show signal buttons if YAML file is loaded
        if (!GUI::yaml_file.empty()) // Check if the yaml_file is not empty
        {
            std::map<int, std::string> channelSignals = BTSRevoGUI::mapHwChannelsToSignals(device.deviceId, GUI::yaml_file);

            // Calculate button width based on longest signal name
            float maxWidth = 0.0f;
            for (const auto &pair : channelSignals)
            {
                // Only consider names that match the filter
                if (filterText[0] == '\0' ||
                    std::search(pair.second.begin(), pair.second.end(),
                                filterText, filterText + strlen(filterText),
                                [](char ch1, char ch2)
                                {
                                    return std::tolower(ch1) == std::tolower(ch2);
                                }) != pair.second.end())
                {
                    float width = ImGui::CalcTextSize(pair.second.c_str()).x + ImGui::GetStyle().FramePadding.x * 2.0f;
                    maxWidth = std::max(maxWidth, width);
                }
            }
            const float buttonWidth = std::clamp(maxWidth, 60.0f, 150.0f); // Min 60, Max 150

            // Display signal names with new lines after each blitz (8 channels)
            for (int blitzIndex = 0; blitzIndex < NUM_BLITZES; blitzIndex++)
            {
                bool lineHasVisibleItems = false;

                // First line of signals (channels 1-8, 17-24, etc.)
                for (int i = blitzIndex * CHANNELS_PER_BLITZ; i < (blitzIndex + 1) * CHANNELS_PER_BLITZ; i++)
                {
                    int channelNumber = i + 1;
                    auto it = channelSignals.find(channelNumber);
                    if (it == channelSignals.end())
                        continue;

                    std::string signalName = it->second;

                    // Skip if filter is active and name doesn't match
                    if (filterText[0] != '\0')
                    {
                        bool matches = std::search(signalName.begin(), signalName.end(),
                                                   filterText, filterText + strlen(filterText),
                                                   [](char ch1, char ch2)
                                                   {
                                                       return std::tolower(ch1) == std::tolower(ch2);
                                                   }) != signalName.end();
                        if (!matches)
                            continue;
                    }

                    lineHasVisibleItems = true;

                    ImGui::PushID(i + 1000);
                    if (device.channelMeasurements[i].isActive)
                    {
                        ImGui::PushStyleColor(ImGuiCol_Button, activeChannelColor);
                    }
                    else
                    {
                        ImGui::PushStyleColor(ImGuiCol_Button, inactiveChannelColor);
                    }

                    if (ImGui::Button(signalName.c_str(), ImVec2(buttonWidth, 30)))
                    {
                        device.channelMeasurements[i].isActive = !device.channelMeasurements[i].isActive;
                        device.defaultChannelId = channelNumber;
                    }

                    if (ImGui::IsItemHovered() && ImGui::CalcTextSize(signalName.c_str()).x > buttonWidth - ImGui::GetStyle().FramePadding.x * 2.0f)
                    {
                        ImGui::PushStyleColor(ImGuiCol_PopupBg, bgColor);
                        ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                        ImGui::SetTooltip("%s", signalName.c_str());
                        ImGui::PopStyleColor(2);
                    }

                    ImGui::PopStyleColor();
                    ImGui::PopID();

                    // Add separator between channels, but not after the last one in the group
                    if (i < (blitzIndex + 1) * CHANNELS_PER_BLITZ - 1)
                    {
                        ImGui::SameLine();
                        ImGui::TextColored(textColor, "|");
                        ImGui::SameLine();
                    }
                }

                // Only add newline if this line had visible items
                if (lineHasVisibleItems && blitzIndex < NUM_BLITZES - 1)
                {
                    ImGui::NewLine();
                }
            }
        }
        else
        {
            ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.5f, 1.0f), "Signal mapping not active");    
        }
}

void BTSRevoGUI::RenderLogs(BTSRevoDevice &device, bool &isDarkTheme){
// Define split ratio 
float totalHeight = ImGui::GetContentRegionAvail().y;
float logAreaHeight = totalHeight * 0.2f;
float tableAreaHeight = totalHeight - logAreaHeight;

static char logFilter[256] = "";
static bool needFilterUpdate = true;
static std::vector<std::pair<std::string, ImVec4>> filteredLogs;

// Input field
if (ImGui::InputTextWithHint("##FilterLogs", "Search logs...", logFilter, IM_ARRAYSIZE(logFilter))) {
    needFilterUpdate = true;
}

// Clear 'X' button
if (logFilter[0] != '\0') {
    ImGui::SameLine();
    if (ImGui::SmallButton("X")) {
        logFilter[0] = '\0';
        needFilterUpdate = true;
    }
    if (ImGui::IsItemHovered()) {
        ImGui::SetTooltip("Clear filter");
    }
}
// Log display area
ImGui::BeginChild("LogScrollingRegion", ImVec2(0, logAreaHeight), true, ImGuiWindowFlags_HorizontalScrollbar);

if (logFilter[0] != '\0') {
    if (needFilterUpdate) {
        filteredLogs.clear();
        std::string filterLower = logFilter;
        std::transform(filterLower.begin(), filterLower.end(), filterLower.begin(), ::tolower);

        const auto& allLogs = Logging::getLogs();
        for (const auto& log : allLogs) {
            std::string logLower = log.first;
            std::transform(logLower.begin(), logLower.end(), logLower.begin(), ::tolower);
            if (logLower.find(filterLower) != std::string::npos) {
                filteredLogs.push_back(log);
            }
        }
        needFilterUpdate = false;
    }

    for (const auto& log : filteredLogs) {
        ImGui::PushStyleColor(ImGuiCol_Text, log.second);
        ImGui::TextWrapped("%s", log.first.c_str());
        ImGui::PopStyleColor();
    }

    if (!needFilterUpdate && ImGui::GetScrollY() >= ImGui::GetScrollMaxY()) {
        ImGui::SetScrollHereY(1.0f);
    }
} else {
    Logging::renderLogArea();
}

ImGui::EndChild();

}
void BTSRevoGUI::RenderIOTable(BTSRevoDevice &device, bool &isDarkTheme){
    if (ImGui::BeginTable("ActiveChannelsTable", 4, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY)) {
    
    ImGui::TableSetupColumn("Interface ID", ImGuiTableColumnFlags_WidthFixed, 100.0f);
    ImGui::TableSetupColumn("Channel ID", ImGuiTableColumnFlags_WidthFixed, 80.0f);
    ImGui::TableSetupColumn("Voltage (V)", ImGuiTableColumnFlags_WidthFixed, 100.0f);
    ImGui::TableSetupColumn("Current (A)", ImGuiTableColumnFlags_WidthFixed, 100.0f);
    ImGui::TableHeadersRow();

    for (int i = 0; i < TOTAL_CHANNELS; ++i) {
           
        if (device.channelMeasurements[i].isActive) {
            ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0);
            ImGui::Text("%d", device.deviceId);
            ImGui::TableSetColumnIndex(1);
            ImGui::Text("%d", i + 1);
            ImGui::TableSetColumnIndex(2);
            ImGui::Text("%.2f", device.channelMeasurements[i].voltage);
            ImGui::TableSetColumnIndex(3);
            ImGui::Text("%.2f", device.channelMeasurements[i].current);
        }
    }

    ImGui::EndTable();
}

}
void BTSRevoGUI::RenderPopup(BTSRevoDevice &device, bool &isDarkTheme, int i, const char *base_functions[]){
    ImVec4 textColor = isDarkTheme ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
    
                        ImGui::TextColored(textColor, "BTS Revo ID: %d", device.deviceId);
                        // Get current signal name
                        std::string currentSignal = "N/A";
                        std::map<int, std::string> channelSignals = BTSRevoGUI::mapHwChannelsToSignals(device.deviceId, GUI::yaml_file);
                        if (channelSignals.count(device.defaultChannelId))
                        {
                            currentSignal = channelSignals[device.defaultChannelId];
                        }

                        // Display current selection
                        ImGui::TextColored(textColor, "Default: Channel %d - %s",
                                           device.defaultChannelId, currentSignal.c_str());

                        // Signal selection combo box
                        ImGui::PushID("signal_combo");
                        if (ImGui::BeginCombo("##SignalSelect", currentSignal.c_str()))
                        {
                            for (const auto &[channel, signal] : channelSignals)
                            {
                                ImGui::PushID(channel); // Unique ID per channel

                                bool isSelected = (channel == device.defaultChannelId);
                                if (ImGui::Selectable(signal.c_str(), isSelected))
                                {
                                    device.defaultChannelId = channel;
                                    Logging::warn("Default changed to Channel %d - %s",
                                                  channel, signal.c_str());
                                }

                                if (isSelected)
                                {
                                    ImGui::SetItemDefaultFocus();
                                }

                                ImGui::PopID();
                            }

                            // Handle case when no signals are available
                            if (channelSignals.empty())
                            {
                                ImGui::TextDisabled("No signals available - No YAML File uploaded");
                            }

                            ImGui::EndCombo();
                        }
                        ImGui::PopID();

                        // Channel ID direct input (fallback)
                        ImGui::Spacing();
                        ImGui::TextColored(textColor,"Or specify channel directly:");
                        static int prevDefaultChannelId = device.defaultChannelId;

                        ImGui::PushID("channel_input");
                        if (ImGui::InputInt("##ChannelInput", &device.defaultChannelId))
                        {
                            device.defaultChannelId = std::clamp(device.defaultChannelId, 1, 24);
                            if (channelSignals.count(device.defaultChannelId))
                            {
                                currentSignal = channelSignals[device.defaultChannelId];
                            }
                            else
                            {
                                currentSignal = "N/A";
                            }
                        }

                        if (ImGui::IsItemFocused() && (ImGui::IsKeyPressed(ImGuiKey_Enter) || ImGui::IsKeyPressed(ImGuiKey_KeypadEnter)))
                        {
                            if (device.defaultChannelId != prevDefaultChannelId)
                            {
                                Logging::warn("Default Channel ID changed to %d (%s)",
                                              device.defaultChannelId, currentSignal.c_str());
                                prevDefaultChannelId = device.defaultChannelId;
                            }
                        }
                        ImGui::PopID();

                        // Help marker explaining the options
                        ImGui::SameLine();
                        ImGui::TextDisabled("(help)");
                        if (ImGui::IsItemHovered())
                        {
                            ImGui::BeginTooltip();
                            ImGui::TextColored(textColor,"Select from signal names above or enter channel number directly");
                            ImGui::EndTooltip();
                        }
                        // Function-specific parameters
                        static bool boolValue = false;
                        static Base::u16 onTime = 0;
                        static Base::u16 offTime = 0;
                        static float currentInMa = 0.0f;
                        static int property = 0;
                        static int channelMask = 0;
                        static int btsChannelId = 0;

                        switch (i)
                        {
                        case 0: //open load
                        ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                        ImGui::Checkbox("Boolean Value", &boolValue);
                        ImGui::PopStyleColor();
                        break;
                        case 1: // shotvbat
                        ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                        ImGui::Checkbox("Boolean Value", &boolValue);
                        ImGui::PopStyleColor();
                        break;
                        case 2: // shortgnd
                        ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                        ImGui::Checkbox("Boolean Value", &boolValue);
                        ImGui::PopStyleColor();
                        break;
                        case 3: // generatePWM
                        ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                        ImGui::Checkbox("Boolean Value", &boolValue);
                            // onTime - offTime fields
                       ImGui::InputScalar("On Time", ImGuiDataType_U16, &onTime);
                        ImGui::InputScalar("Off Time", ImGuiDataType_U16, &offTime);
                        ImGui::PopStyleColor();
                        break;
                        case 4: // Low Current Generation
                          
                            break;
                        case 5: // Voltage Measurement
                        break;
                        case 6: // Voltage Measurement
                        break;
                        case 7: // PWM Measurement
                            ImGui::InputInt("BTS Channel ID", &btsChannelId);
                            if (ImGui::IsItemFocused() && (ImGui::IsKeyPressed(ImGuiKey_Enter) || ImGui::IsKeyPressed(ImGuiKey_KeypadEnter)))
                            {
                                Logging::warn("BTS Channel ID changed to {}", btsChannelId);
                            }
                            break;
                        }

                        // Execute on Enter (when popup is focused)
                        if ((ImGui::IsKeyPressed(ImGuiKey_Enter) || ImGui::IsKeyPressed(ImGuiKey_KeypadEnter)) && ImGui::IsWindowFocused())
                        {
                            Logging::info("Executed {}", base_functions[i]);
                            ImGui::CloseCurrentPopup();
                        }

                        if (ImGui::Button("Execute"))
{
    Logging::info("Executed  {}", base_functions[i]);
    
    int btsRevoId = device.deviceId;
    int channelId = device.defaultChannelId;

    switch (i)
    {
    case 0: // OpenLoad
    device.OpenLoad(device.deviceId, prevDefaultChannelId, &boolValue);
    Logging::info("openload");
        break;
    case 1: // ShortVbat
    device.shortVBat(device.deviceId, prevDefaultChannelId, &boolValue);
        break;
    case 2: // ShortGND
    device.shortGnd(device.deviceId, prevDefaultChannelId, &boolValue);
        break;
    case 3: // PWMGeneration
    device.generatePWM(device.deviceId, prevDefaultChannelId, &boolValue,onTime,offTime );
        break;
    case 4: // LowCurrentGeneration
     break;
    case 5: 
    device.channelMeasurements[channelId-1].isActive= true;
    device.measureVoltage(channelId);
    Logging::info("voltage on channel {} is {}.",channelId,device.channelMeasurements[channelId-1].voltage);
    break;
    case 6: // CurrentMeasurement
    device.channelMeasurements[channelId-1].isActive= true;
    device.measureCurrent(channelId);
    Logging::info("current on channel {} is {} .",channelId,device.channelMeasurements[channelId-1].current);
        

        break;
     
    case 7: // PWMMeasurement
        break;
    case 8: // GetLastReceivedIOMsg=
    
        break;
    }

    ImGui::CloseCurrentPopup();
}

                        ImGui::SameLine();
                        if (ImGui::Button("Cancel"))
                        {
                            ImGui::CloseCurrentPopup();
                        }

}
void BTSRevoGUI::RenderControlPanel(BTSRevoDevice &device, bool &isDarkTheme, const std::string &directoryPath)
{
    // Blitz functions
    const char *blitz_functions[] = {
        "Current Measurement (High Current)",
        "Quiescent Current Measurement",
        "Short to GND (High Current)",
        "Load Simulation (High Current)"};

    // Base functions
    const char *base_functions[] = {
        "Open Load", "Short Vbat", "Short GND", "PWM Generation", "Low Current Generation",
        "Voltage Measurement", "Current Measurement (Low Current)", "PWM Measurement"};

    // Use theme colors
    ImVec4 primaryColor = Themes::GetColor(isDarkTheme ? ColorType::Primary : ColorType::PrimaryLight);
    ImVec4 accentColor = Themes::GetColor(isDarkTheme ? ColorType::Accent : ColorType::AccentLight);
    ImVec4 textColor = isDarkTheme ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
    ImVec4 errorColor = Themes::GetColor(ColorType::Error);
    ImVec4 warningColor = Themes::GetColor(ColorType::Warning);
    ImVec4 bgColor = isDarkTheme ? ImVec4(0.2f, 0.2f, 0.4f, 0.90f) : ImVec4(0.8f, 0.8f, 0.8f, 0.90f);
    ImVec4 darkColor =  isDarkTheme ? ImVec4(0.90f, 0.80f, 0.10f, 1.0f) : ImVec4(0.85f, 0.65f, 0.05f, 1.0f) ;
    ImVec4 titlesColor = isDarkTheme ? ImVec4(0.90f, 0.90f, 0.90f, 1.0f) : ImVec4(0.20f, 0.0f, 0.10f, 1.0f);
    ImVec4 hoverColor = ImVec4(0.9f, 0.3f, 0.6f, 1.0f);
    // Static variable to track if right panel is collapsed
    static bool rightPanelCollapsed = false;
    const float rightPanelWidth = 500.0f;
    const float collapsedPanelWidth = 150.0f;
    //Static variable to show export dialog
    static bool showExportDialog = false;

    ImGui::SetWindowFontScale(2.8f);
        ImGui::BeginGroup();
        ImGui::TextColored(darkColor, "BTS_Revo Controller - Device %d", device.deviceId);
        ImGui::SameLine();

        ImGui::SetWindowFontScale(1.8f);
        if (ImGui::Button(" Export Config"))
        {
            exportRequested = true;
        }
        if (ImGui::IsItemHovered())
        {
            
            ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
            ImGui::SetTooltip("Export current BTS Revo configuration to YAML file");
            ImGui::PopStyleColor(2);
        }
        ImGui::EndGroup();

        // This will handle the file dialog
        ExportBTSRevoConfig(device, directoryPath);
        ImGui::SameLine();
        if (ImGui::Button("Load BTS Revo Configuration", ImVec2(250, 35)))
        {
            GUI::ImportConf();
            ApplyBTSRevoConfig(device, GUI::Conf_file);
        }
        ImGui::SetWindowFontScale(2.8f);
    
    ImGui::Separator();
    ImGui::SetWindowFontScale(1.25f);

    // Set up columns based on collapse state
    if (!rightPanelCollapsed)
    {
        ImGui::Columns(2, "MainColumns", false);
        ImGui::SetColumnWidth(0, ImGui::GetWindowWidth() - rightPanelWidth);
        ImGui::SetColumnWidth(1, rightPanelWidth);
    }
    else
    {
        ImGui::Columns(2, "MainColumnsCollapsed", false);
        ImGui::SetColumnWidth(0, ImGui::GetWindowWidth() - collapsedPanelWidth);
        ImGui::SetColumnWidth(1, collapsedPanelWidth);
    }

    // Left column: Main content (always visible)
    ImGui::BeginChild("LeftColumn", ImVec2(0, 0), true, ImGuiWindowFlags_NoResize);
    {
        // Header rectangle
        ImVec2 rectSize = ImVec2(ImGui::GetContentRegionAvail().x, 50);
        ImVec2 rectPos = ImGui::GetCursorScreenPos();
        ImDrawList *drawList = ImGui::GetWindowDrawList();
        drawList->AddRectFilled(rectPos, ImVec2(rectPos.x + rectSize.x, rectPos.y + rectSize.y), ImGui::ColorConvertFloat4ToU32(primaryColor));
        drawList->AddRect(rectPos, ImVec2(rectPos.x + rectSize.x, rectPos.y + rectSize.y), ImGui::ColorConvertFloat4ToU32(accentColor));
        ImVec2 textSize = ImGui::CalcTextSize("BTS_Revo");
        ImVec2 textPos = ImVec2(rectPos.x + (rectSize.x - textSize.x) / 2, rectPos.y + (rectSize.y - textSize.y) / 2);
        drawList->AddText(textPos, ImGui::ColorConvertFloat4ToU32(ImVec4(0.95f, 0.96f, 0.98f, 1.0f)), "BTS_Revo");
        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + rectSize.y + 10);
        ImGui::Separator();

        // Daggers
        ImGui::SetWindowFontScale(1.9f);
        ImGui::TextColored(titlesColor, "Daggers:");
        ImGui::SetWindowFontScale(1.0f);
        BTSRevoGUI::RenderDaggers(device, isDarkTheme);

         // Blitzes
        ImGui::SetWindowFontScale(1.9f);
        ImGui::TextColored(titlesColor, "Blitzes:");
        ImGui::SetWindowFontScale(1.0f);
        BTSRevoGUI::RenderBlitzes(device, isDarkTheme);
        
        // Channels line - Numbers
        ImGui::SetWindowFontScale(1.9f);
        ImGui::TextColored(titlesColor, "Channels:");
        ImGui::SetWindowFontScale(1.0f);
        BTSRevoGUI::RenderChannels(device, isDarkTheme);


// -----------------------
// Logs Section
// -----------------------
ImGui::NewLine();
ImGui::Separator();
ImGui::SetWindowFontScale(1.5f);
ImGui::TextColored(titlesColor, "Logs:");
ImGui::SetWindowFontScale(1.0f);
ImGui::TextColored(textColor, "Filter Logs");
ImGui::PushStyleColor(ImGuiCol_FrameBg, bgColor);
ImGui::PushStyleColor(ImGuiCol_Text, textColor);
BTSRevoGUI::RenderLogs(device, isDarkTheme);
ImGui::PopStyleColor(2);
// -----------------------
// Active Channels Section
// -----------------------

ImGui::SetWindowFontScale(1.7f);
ImGui::TextColored(titlesColor, "Active Channels:");
ImGui::SetWindowFontScale(1.0f);

ImGui::PushStyleColor(ImGuiCol_TableHeaderBg, ImVec4(0.0f, 0.0f, 0.0f, 0.70f));
ImGui::PushStyleColor(ImGuiCol_Text, textColor);

BTSRevoGUI::RenderIOTable(device, isDarkTheme);

ImGui::PopStyleColor(2);}
ImGui::EndChild();

    // Right column: Functions panel (collapsible)
    ImGui::NextColumn();
    if (!rightPanelCollapsed)
    {
        // Expanded state
        ImGui::BeginChild("RightColumn", ImVec2(0, 0), true, ImGuiWindowFlags_NoResize);
        {
            ImGui::SetWindowFontScale(1.5f);

            // Collapse button with accent color
            ImGui::PushStyleColor(ImGuiCol_Button, accentColor);
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(accentColor.x * 0.8f, accentColor.y * 0.8f, accentColor.z * 0.8f, 1.0f));
            if (ImGui::Button(">>", ImVec2(50, 30)))
            {
                rightPanelCollapsed = true;
            }
            ImGui::PopStyleColor(2);
            if (ImGui::IsItemHovered())
            {
                ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
                ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
                ImGui::SetTooltip("Collapse the functions panel to get more space");
                ImGui::PopStyleColor(2);
            }

            ImGui::TextColored(titlesColor, "Functions:");
            ImGui::Separator();



            if (ImGui::Button("Export Channels Measurements", ImVec2(-1, 30)))
            {
                ExportChannelMeasurements(device, directoryPath);
            }
            if (ImGui::IsItemHovered())
            {
                ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
                ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
                ImGui::SetTooltip("Export channel measurements to a file in the selected directory.");
                ImGui::PopStyleColor(2);
            }

            float functionsAreaHeight = ImGui::GetContentRegionAvail().y * 0.4f;
            ImGui::BeginChild("FunctionsArea", ImVec2(-1, functionsAreaHeight), true);
            {
                // Base functions
                ImGui::TextColored(titlesColor, "Base Functions:");
                for (int i = 0; i < IM_ARRAYSIZE(base_functions); i++)
                {
                    ImGui::PushStyleColor(ImGuiCol_Button, accentColor);
                    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.6f, 0.6f, 0.6f, 1.0f));
                    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.4f, 0.4f, 0.4f, 1.0f));
                    if (ImGui::Button(base_functions[i]))
                    {
                        
                        ImGui::OpenPopup(base_functions[i]);
                        
                    }
                    ImGui::PopStyleColor(3);
                    ImGui::PushStyleColor(ImGuiCol_Text, textColor);

                    if (ImGui::BeginPopupModal(base_functions[i], nullptr, ImGuiWindowFlags_AlwaysAutoResize))
                    {
                        RenderPopup(device, isDarkTheme, i, base_functions);

                        ImGui::EndPopup();
                    }
                      ImGui::PopStyleColor();
                }

                // Blitz functions (if any Blitz is active)
                bool isAnyBlitzActive = false;
                for (int blitzIndex = 0; blitzIndex < NUM_BLITZES; blitzIndex++)
                {
                    if (device.hasBlitz[blitzIndex])
                    {
                        isAnyBlitzActive = true;
                        break;
                    }
                }

                if (isAnyBlitzActive)
                {
                    ImGui::NewLine();
                    ImGui::Separator();
                    ImGui::TextColored(titlesColor, "Blitz Functions:");
                    for (const auto &func : blitz_functions)
                    {
                        ImGui::PushStyleColor(ImGuiCol_Button, accentColor);
                        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.6f, 0.6f, 0.6f, 1.0f));
                        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.4f, 0.4f, 0.4f, 1.0f));
                        if (ImGui::Button(func))
                        {
                            // Handle Blitz function execution
                        }
                        ImGui::PopStyleColor(3);
                    }
                }

                // Dagger functions (if any Dagger is active)
                bool isAnyDaggerActive = false;
                for (int daggerIndex = 0; daggerIndex < NUM_DAGGERS; daggerIndex++)
                {
                    if (device.hasDagger[daggerIndex])
                    {
                        isAnyDaggerActive = true;
                        break;
                    }
                }

                if (isAnyDaggerActive)
                {
                    ImGui::NewLine();
                    ImGui::Separator();
                    ImGui::TextColored(titlesColor, "Dagger Functions:");
                    ImGui::PushStyleColor(ImGuiCol_Button, accentColor);
                    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.6f, 0.6f, 0.6f, 1.0f));
                    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.4f, 0.4f, 0.4f, 1.0f));
                    if (ImGui::Button("Load Simulation (Resistor)"))
                    {
                        // Handle Dagger function execution
                    }
                    ImGui::PopStyleColor(3);
                }
            }
            ImGui::EndChild();

            // Plots
            ImPlot::CreateContext();
            ImGui::TextColored(titlesColor, "Channel Measurements:");
            ImGui::Separator();

            ImGui::SetWindowFontScale(1.8f);
            ImGui::TextColored(textColor, "Voltage (V)");
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.6f, 0.0f, 1.0f)); 
            if (ImPlot::BeginPlot("##Voltage (V)", ImVec2(-1, 200)))
            {

                ImGui::SetWindowFontScale(1.1f);
                ImPlot::PushStyleColor(ImPlotCol_AxisText, textColor);
                ImPlot::SetupAxes("Channel ID", "Voltage (V)");
                ImPlot::SetupLegend(ImPlotLocation_SouthEast, ImPlotLegendFlags_Outside);
                ImPlot::SetupAxisLimits(ImAxis_X1, 0, TOTAL_CHANNELS+1, ImGuiCond_Always);
                ImPlot::SetupAxisLimits(ImAxis_Y1, 0, 50);
                for (int i = 0; i < TOTAL_CHANNELS; i++)
                {
                    if (device.channelMeasurements[i].isActive)
                    {
                        float value = device.channelMeasurements[i].voltage;
                        ImPlot::PlotBars(
                            ("Channel " + std::to_string(i + 1)).c_str(), // Label
                            &value, // Pointer to the value (1 element)
                            1, // Number of values (just 1)
                            0.3f, // Bar width
                            i + 1.0f // Center position (1.0, 2.0, 3.0, ...)
                        );
                    }
                }

                ImPlot::PopStyleColor();

                ImPlot::EndPlot();
            }
            ImGui::PopStyleColor();
            ImGui::Separator();
            ImGui::SetWindowFontScale(1.8f);
            ImGui::TextColored(textColor, "Current (A)");
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.6f, 0.0f, 1.0f));
            if (ImPlot::BeginPlot("##Current (A)", ImVec2(-1, 200)))
            {

                ImGui::SetWindowFontScale(1.1f);
                ImPlot::PushStyleColor(ImPlotCol_AxisText, textColor);
                ImPlot::SetupAxes("Channel ID", "Current (A)");
                ImPlot::SetupLegend(ImPlotLocation_SouthEast, ImPlotLegendFlags_Outside);
                ImPlot::SetupAxisLimits(ImAxis_X1, 1, TOTAL_CHANNELS+1, ImGuiCond_Always);
                ImPlot::SetupAxisLimits(ImAxis_Y1, 0, 10);
                for (int i = 0; i < TOTAL_CHANNELS; i++)
                {
                    if (device.channelMeasurements[i].isActive)
                    {
                        float value = device.channelMeasurements[i].current;
                        ImPlot::PlotBars(
                            ("Channel " + std::to_string(i + 1)).c_str(), // Label
                            &value, // Pointer to the value (1 element)
                            1, // Number of values (just 1)
                            0.3f, // Bar width
                            i + 1.0f // Center position (1.0, 2.0, 3.0, ...)
                        );
                    }
                }

                ImPlot::PopStyleColor();

                ImPlot::EndPlot();
            }
            ImGui::PopStyleColor();
      
        }
        ImGui::EndChild();
    }
    else
    {
        // Collapsed state - show expand button
        ImGui::BeginChild("RightColumnCollapsed", ImVec2(0, 0), true, ImGuiWindowFlags_NoResize);
        {
            ImGui::SetWindowFontScale(1.5f);

            // Expand button with accent color
            ImGui::PushStyleColor(ImGuiCol_Button, accentColor);
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(accentColor.x * 0.8f, accentColor.y * 0.8f, accentColor.z * 0.8f, 1.0f));
            if (ImGui::Button("<<", ImVec2(50, 30)))
            {
                rightPanelCollapsed = false;
            }
            ImGui::PopStyleColor(2);
            if (ImGui::IsItemHovered())
            {
                ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.15f, 0.15f, 0.15f, 0.9f));
                ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.9f, 0.9f, 0.9f, 1.0f));
                ImGui::SetTooltip("Expand the functions panel");
                ImGui::PopStyleColor(2);
            }

            // Mini status display
            ImGui::SetWindowFontScale(1.0f);
            ImGui::Separator();
            ImGui::TextColored(textColor, "Panel collapsed");
            ImGui::TextColored(textColor, "Available functions:");
            ImGui::BulletText("%d base functions", IM_ARRAYSIZE(base_functions));

            // Count active Blitzes
            int activeBlitzes = 0;
            for (int i = 0; i < NUM_BLITZES; i++)
            {
                if (device.hasBlitz[i])
                    activeBlitzes++;
            }
            if (activeBlitzes > 0)
            {
                ImGui::BulletText("%d Blitz functions", activeBlitzes * IM_ARRAYSIZE(blitz_functions));
            }

            // Count active Daggers
            int activeDaggers = 0;
            for (int i = 0; i < NUM_DAGGERS; i++)
            {
                if (device.hasDagger[i])
                    activeDaggers++;
            }
            if (activeDaggers > 0)
            {
                ImGui::BulletText("%d Dagger functions", activeDaggers);
            }
        }
        ImGui::EndChild();
    }
}

